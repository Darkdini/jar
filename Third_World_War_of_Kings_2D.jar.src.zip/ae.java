import com.fenix.main.f;
import com.fenix.main.h;
import javax.microedition.lcdui.Graphics;

public final class ae extends f {
  private int c;
  
  private int d;
  
  private boolean e = false;
  
  String a = "Set Caption";
  
  public int b = 0;
  
  public final void a(int paramInt1, int paramInt2) {
    this.c = paramInt1;
    this.d = paramInt2;
  }
  
  public final void a(boolean paramBoolean) {
    this.e = paramBoolean;
  }
  
  public final void a(Graphics paramGraphics) {
    Graphics graphics;
    String str2;
    ae ae1;
    int j = (ae1 = this).c;
    int k = (ae1 = this).d;
    if ((ae1 = this).e) {
      k = k;
      j = j;
      str2 = this.a;
      graphics = paramGraphics;
      if ((ae1 = this).b == 0)
        o.a(this, (b.a()).a, k - 2, (b.a()).c + 1, (b.a()).d + 3); 
      if (ae1.b == 1)
        o.a(this, (w.a()).a, k - 2, (w.a()).b, (w.a()).c + 3); 
      if (ae1.b == 2)
        o.a(this, (ad.a()).a, k - 2, (ad.a()).b, (ad.a()).c + 3); 
      setColor(h.a);
      drawString(str2, j, k, 0);
      return;
    } 
    j = k;
    int i = j;
    String str1 = ((ae)super).a;
    String str3;
    (str3 = str2).setColor(h.a);
    str3.drawString(this, i, j, 0);
  }
}


/* Location:              C:\Users\sora\Desktop\Third_World_War_of_Kings_2D.jar!\ae.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */