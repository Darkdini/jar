import com.fenix.main.a;
import com.fenix.main.b;
import com.fenix.main.f;
import com.fenix.main.h;
import com.fenix.main.i;
import javax.microedition.lcdui.Graphics;

public final class i extends f implements a {
  private String[] a = null;
  
  private int b;
  
  private int c;
  
  private int d;
  
  private int e;
  
  private int f;
  
  private int g;
  
  private int h;
  
  private int i = 0;
  
  private int j = 0;
  
  private f k = null;
  
  private static i l = null;
  
  private n[] m;
  
  public static i a() {
    if (l == null)
      l = new i(); 
    return l;
  }
  
  public final void a(f paramf) {
    this.k = paramf;
  }
  
  public i() {
    a(this);
    this.h = 0;
    this.b = 10;
    this.c = 20;
    this.d = 128;
    this.e = 70;
    this.f = 3;
    this.g = 3;
    c();
  }
  
  private void c() {
    this.d = i.a - i.a / 4 + (this.g << 1);
    this.b = i.a / 2 - this.d / 2 - this.g;
    this.c = i.b / 2 - this.e / 2 - 5;
  }
  
  public final void a(String paramString, int paramInt) {
    if (b.a().b() == this)
      return; 
    int j = paramInt;
    i i1;
    (i1 = this).i = j;
    this.a = null;
    this.a = l.a().a(paramString, h.d, this.d - 10, true);
  }
  
  public final void b() {
    if (b.a().b() == this)
      return; 
    this.e = this.a.length * h.d.getHeight() + 30;
    c();
    this = this;
    byte b = 1;
    i i1;
    if ((i1 = this).i == 1)
      b++; 
    this.m = new n[b];
    this.m[0] = new h();
    ((h)this.m[0]).f(21);
    ((h)this.m[0]).b("Ok");
    if ((i1 = this).i == 0) {
      this.m[0].a(this.b + this.d / 8, this.c + this.e - 20, this.d / 2 + this.d / 4, 15);
      this.j = 0;
    } else {
      this.m[0].a(this.b + this.d / 8, this.c + this.e - 20, this.d / 3, 15);
      this.m[1] = new h();
      ((h)this.m[1]).f(0);
      this.m[1].a(this.b + this.d - this.d / 8 - this.d / 3, this.c + this.e - 20, this.d / 3, 15);
      this.j = 1;
    } 
    this.m[this.j].a(true);
    b.a().a(l);
  }
  
  public final void a(int paramInt) {
    switch (paramInt) {
      case 32:
      case 524288:
        System.out.println("Cancel");
        b.a().a(this.k);
        return;
    } 
    System.out.println("***Knopka Ne obrabotana***");
  }
  
  public final void a(Graphics paramGraphics) {
    paramGraphics.setColor(10053171);
    paramGraphics.fillRect(this.b, this.c, this.d, this.e);
    paramGraphics.setColor(0);
    paramGraphics.setColor(9735534);
    paramGraphics.fillRect(this.b, this.c, this.d, this.f);
    paramGraphics.setColor(0);
    paramGraphics.setFont(h.d);
    paramGraphics.setColor(16777215);
    int j = paramGraphics.getFont().getHeight();
    byte b;
    for (b = 0; b < this.a.length; b++)
      paramGraphics.drawString(this.a[b], this.b + this.g, this.c + j * b + 5, 0); 
    if (this.m != null)
      for (b = 0; b < this.m.length; b++)
        this.m[b].a(paramGraphics);  
  }
}


/* Location:              C:\Users\sora\Desktop\Third_World_War_of_Kings_2D.jar!\i.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */