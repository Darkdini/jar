import java.util.Vector;

final class u {
  private static Vector m = new Vector();
  
  int a;
  
  int b;
  
  int c;
  
  int d;
  
  int e;
  
  String f;
  
  String g;
  
  String h;
  
  String i;
  
  int j;
  
  int k;
  
  int l;
  
  public static void a() {
    m.removeAllElements();
  }
  
  public static void a(u paramu) {
    m.addElement(paramu);
  }
  
  public static u a(int paramInt1, int paramInt2) {
    if (m == null)
      return null; 
    for (byte b = 0; b < m.size(); b++) {
      u u1;
      if ((u1 = m.elementAt(b)).b == paramInt1 && u1.c == paramInt2)
        return u1; 
    } 
    return null;
  }
}


/* Location:              C:\Users\sora\Desktop\Third_World_War_of_Kings_2D.jar\\u.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */