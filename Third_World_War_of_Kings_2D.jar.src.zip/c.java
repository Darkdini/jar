final class c extends Thread {
  private final ag a;
  
  c(ag paramag) {
    this.a = paramag;
  }
  
  public final void run() {
    try {
      this.a.c();
      return;
    } catch (Exception exception) {
      System.err.println(this);
      return;
    } 
  }
}


/* Location:              C:\Users\sora\Desktop\Third_World_War_of_Kings_2D.jar!\c.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */