import com.fenix.main.a;
import com.fenix.main.f;
import javax.microedition.lcdui.Graphics;

public final class y extends f implements a {
  private static y a;
  
  public static y a() {
    if (a == null)
      a = new y(); 
    return a;
  }
  
  y() {
    System.out.println("Login screen is set");
  }
  
  public final void a(Graphics paramGraphics) {}
  
  public final void a(int paramInt) {}
}


/* Location:              C:\Users\sora\Desktop\Third_World_War_of_Kings_2D.jar!\y.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */