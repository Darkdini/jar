import com.fenix.main.a;
import com.fenix.main.b;
import com.fenix.main.c;
import com.fenix.main.h;
import com.fenix.main.i;
import javax.microedition.lcdui.Graphics;

public final class ad extends ah implements a {
  private static ad d;
  
  public int a = 1;
  
  private int f = 1;
  
  public int b = 1;
  
  private int g = 1;
  
  public int c = 1;
  
  public static ad a() {
    if (d == null)
      d = new ad(); 
    return d;
  }
  
  private ad() {
    this.c = h.d.getHeight();
    this.b = h.d.stringWidth(r.a().a(r.c[1])) + 15;
    this.g = 3 * (this.c + 2) + 10;
    this.a = (b.a()).a - this.b - 5;
    this.f = (b.a()).b + 2 + 3 * ((b.a()).d + 2);
    ad ad1 = this;
    for (byte b = 0; b < 3; b++) {
      byte b1 = b;
      String str = r.a().a(r.c[b1]);
      ae ae1;
      ae ae2;
      (ae1 = ae2 = new ae()).a = str;
      (ae1 = ae2).a(ad1.a + ad1.b - h.d.stringWidth(r.a().a(r.c[b])) - 5, ad1.f + 2 + b * (ad1.c + 2));
      ae1.b = 2;
      ad1.a(ae1);
    } 
    ad1.b(0);
    a(this);
  }
  
  public final void a(Graphics paramGraphics) {
    int i = paramGraphics.getClipX();
    int j = paramGraphics.getClipY();
    int k = paramGraphics.getClipWidth();
    int m = paramGraphics.getClipHeight();
    int n = c.k.getHeight();
    int i1 = c.k.getWidth();
    int i2 = (this.g + 8 - 5) / n + 1;
    int i3 = (this.b + 8 - 6) / i1 + 1;
    paramGraphics.setClip(this.a - 4, this.f - 4, this.b + 8, this.g + 8);
    for (byte b = 0; b < i2; b++) {
      for (byte b1 = 0; b1 < i3; b1++)
        paramGraphics.drawImage(c.k, this.a - 4 + b1 * i1, this.f - 4 + b * n, 0); 
    } 
    paramGraphics.setClip(i, j, k, m);
    paramGraphics.setColor(11642239);
    paramGraphics.drawRect(this.a + 1 - 4, this.f + 1 - 4, this.b + 5, this.g + 5);
    paramGraphics.setColor(14793067);
    paramGraphics.drawRect(this.a + 3 - 4, this.f + 3 - 4, this.b + 1, this.g + 1);
    paramGraphics.setColor(0);
    paramGraphics.drawRect(this.a + 4 - 4, this.f + 4 - 4, this.b - 1, this.g - 1);
    super.a(paramGraphics);
  }
  
  public final void a(int paramInt) {
    int i;
    switch (paramInt) {
      case 8:
      case 65536:
        c();
        return;
      case 16:
      case 131072:
        d();
        return;
      case 4:
      case 32768:
        b.a().a(k.a());
        i.a().repaint();
        i.a().serviceRepaints();
        b.a().a(b.a());
        return;
      case 32:
      case 8192:
      case 524288:
        switch (i = b()) {
          case 0:
            k.a();
            k.b(0);
            b.a().a(k.a());
            break;
          case 1:
            k.a();
            k.b(1);
            b.a().a(k.a());
            break;
          case 2:
            k.a();
            k.b(2);
            b.a().a(k.a());
            break;
        } 
        return;
      case 4096:
        b.a().a(k.a());
        break;
    } 
  }
}


/* Location:              C:\Users\sora\Desktop\Third_World_War_of_Kings_2D.jar!\ad.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */