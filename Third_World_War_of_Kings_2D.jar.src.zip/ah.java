import com.fenix.main.f;
import java.util.Vector;
import javax.microedition.lcdui.Graphics;

public class ah extends f {
  public Vector e = new Vector();
  
  private int a = -1;
  
  public final void a(ae paramae) {
    this.e.addElement(paramae);
  }
  
  public final int b() {
    return this.a;
  }
  
  public final void b(int paramInt) {
    if (paramInt < 0 || paramInt >= this.e.size())
      throw new IllegalArgumentException(); 
    if (this.a != -1)
      ((ae)this.e.elementAt(this.a)).a(false); 
    ((ae)this.e.elementAt(paramInt)).a(true);
    this.a = paramInt;
  }
  
  public final void c() {
    if (this.a == -1)
      throw new IllegalStateException("not exist focused item"); 
    if (this.a - 1 < 0) {
      b(this.e.size() - 1);
      return;
    } 
    b(this.a - 1);
  }
  
  public final void d() {
    if (this.a == -1)
      throw new IllegalStateException("not exist focused item"); 
    if (this.a + 1 >= this.e.size()) {
      b(0);
      return;
    } 
    b(this.a + 1);
  }
  
  public void a(Graphics paramGraphics) {
    for (byte b = 0; b < this.e.size(); b++)
      ((ae)this.e.elementAt(b)).a(paramGraphics); 
  }
}


/* Location:              C:\Users\sora\Desktop\Third_World_War_of_Kings_2D.jar!\ah.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */