import javax.microedition.lcdui.Graphics;

public abstract class n {
  private int a;
  
  private int b;
  
  private int c;
  
  private int d;
  
  private String e;
  
  private boolean f;
  
  private boolean g = true;
  
  private int h = 0;
  
  private int i = 0;
  
  private boolean j = true;
  
  private boolean k = true;
  
  private int l = -1;
  
  public final boolean f() {
    return this.g;
  }
  
  public final void c(boolean paramBoolean) {
    this.g = paramBoolean;
  }
  
  public final void d(boolean paramBoolean) {
    this.j = paramBoolean;
  }
  
  public final boolean g() {
    return this.j;
  }
  
  public final void e(boolean paramBoolean) {
    this.k = paramBoolean;
  }
  
  public final boolean h() {
    return this.k;
  }
  
  public final boolean i() {
    return this.f;
  }
  
  public void a(boolean paramBoolean) {
    this.f = paramBoolean;
  }
  
  public final void b(String paramString) {
    this.e = paramString;
  }
  
  public final String j() {
    return this.e;
  }
  
  public void a(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this.a = paramInt1;
    this.b = paramInt2;
    this.c = paramInt3;
    this.d = paramInt4;
  }
  
  public void a(int paramInt) {
    this.a = paramInt;
  }
  
  public void b(int paramInt) {
    this.b = paramInt;
  }
  
  public void c(int paramInt) {
    this.c = paramInt;
  }
  
  public void d(int paramInt) {
    this.d = paramInt;
  }
  
  public final int k() {
    return this.a;
  }
  
  public final int l() {
    return this.b;
  }
  
  public final int m() {
    return this.c;
  }
  
  public final int n() {
    return this.d;
  }
  
  public final void g(int paramInt) {
    this.h = paramInt;
  }
  
  public final void h(int paramInt) {
    this.i = paramInt;
  }
  
  public final int o() {
    return this.h;
  }
  
  public final int p() {
    return this.i;
  }
  
  public final void b(int paramInt1, int paramInt2) {
    this.a += paramInt1;
    this.b += paramInt2;
  }
  
  public abstract void a(Graphics paramGraphics);
  
  public void i(int paramInt) {
    this.l = paramInt;
  }
  
  public final int q() {
    return this.l;
  }
}


/* Location:              C:\Users\sora\Desktop\Third_World_War_of_Kings_2D.jar!\n.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */