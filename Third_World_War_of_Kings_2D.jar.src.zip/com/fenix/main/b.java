package com.fenix.main;

public final class b {
  private static b a;
  
  private f b = null;
  
  public static b a() {
    if (a == null)
      a = new b(); 
    return a;
  }
  
  public final void a(f paramf) {
    this.b = paramf;
  }
  
  public final f b() {
    return this.b;
  }
}


/* Location:              C:\Users\sora\Desktop\Third_World_War_of_Kings_2D.jar!\com\fenix\main\b.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */