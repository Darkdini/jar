package com.fenix.main;

import ag;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import javax.microedition.io.Connector;
import javax.microedition.io.SocketConnection;
import x;

public final class d implements Runnable {
  private Thread a;
  
  private boolean b = false;
  
  private int c = 0;
  
  private int d = 0;
  
  private byte[] e = new byte[256];
  
  private SocketConnection f;
  
  private InputStream g;
  
  private OutputStream h;
  
  public final void a(String paramString, int paramInt, boolean paramBoolean) {
    String str = "socket";
    this.f = (SocketConnection)Connector.open(str + "://" + paramString + ":" + paramInt, 3);
    this.g = this.f.openInputStream();
    this.h = this.f.openOutputStream();
    this.a = new Thread(this);
    this.a.start();
  }
  
  public final void a() {
    this.b = true;
    try {
      if (this.g != null) {
        this.g.close();
        System.out.println("Input closed");
      } 
      this.g = null;
    } catch (Exception exception) {}
    try {
      if (this.h != null) {
        this.h.close();
        System.out.println("Output closed");
      } 
      this.h = null;
    } catch (Exception exception) {}
    try {
      if (this.f != null) {
        this.f.close();
        System.out.println("Socket closed");
      } 
      this.f = null;
    } catch (Exception exception) {}
    System.out.println("!!!!!!!!!!!!!!!!Connection CLOSSED!!!!!!!!!!!!!");
    System.out.println("RETRY!!!! IN Connection");
    if (i.c == true) {
      ag.a();
      ag.a(2);
    } 
  }
  
  public final int b() {
    return (this.d < this.c) ? (this.c - this.d) : 0;
  }
  
  public final int a(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
    while (this.d >= this.c) {
      if (this.b)
        throw new IOException("Connection closed"); 
      try {
        Thread.sleep(50L);
      } catch (Exception exception) {}
    } 
    int i = paramInt2;
    if (paramInt2 > this.c - this.d)
      i = this.c - this.d; 
    if (paramInt1 + i > paramArrayOfbyte.length)
      i = paramArrayOfbyte.length - paramInt1; 
    System.arraycopy(this.e, this.d, paramArrayOfbyte, paramInt1, i);
    this.d += i;
    return i;
  }
  
  public final void a(x paramx) {
    if (paramx instanceof f)
      System.out.println("Connect packet to send"); 
    byte[] arrayOfByte = paramx.d();
    try {
      d d1;
      OutputStream outputStream;
      int i = arrayOfByte.length;
      boolean bool = false;
      arrayOfByte = arrayOfByte;
    } catch (Exception exception) {
      System.err.println(this);
    } 
  }
  
  public final boolean c() {
    return !this.b;
  }
  
  public static d d() {
    return new d();
  }
  
  public final void run() {
    try {
      while (!this.b && i.c) {
        if (this.c < this.e.length) {
          int i;
          try {
            i = this.g.available();
          } catch (IOException iOException) {
            System.out.println("Conn exception 1");
            this.b = true;
            continue;
          } 
          if (i > 0) {
            i = i;
            if (this.e.length - this.c < i)
              i = this.e.length - this.c; 
            try {
              i = this.g.read(this.e, this.c, i);
            } catch (IOException iOException) {
              System.out.println("Conn exception 2");
              this.b = true;
              continue;
            } 
            this.c += i;
          } else {
            try {
              if ((i = this.g.read()) == -1) {
                System.out.println("Conn exception 3");
                this.b = true;
                continue;
              } 
              this.e[this.c] = (byte)i;
              this.c++;
            } catch (IOException iOException) {
              System.out.println("Conn exception 4 " + iOException);
              if (iOException.toString().indexOf("timed out") == -1)
                this.b = true; 
              continue;
            } 
          } 
        } else if (this.d == this.e.length) {
          this.c = 0;
          this.d = 0;
          continue;
        } 
        try {
          Thread.sleep(20L);
        } catch (Exception exception) {}
      } 
    } catch (Exception exception2) {
      Exception exception1;
      if (exception1 = null instanceof InterruptedException) {
        System.out.println("Interrupted");
      } else {
        exception1.printStackTrace();
      } 
    } 
    if (i.c == true)
      a(); 
  }
  
  static {
    (new byte[2])[0] = 13;
    (new byte[2])[1] = 10;
  }
}


/* Location:              C:\Users\sora\Desktop\Third_World_War_of_Kings_2D.jar!\com\fenix\main\d.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */