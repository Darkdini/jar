package com.fenix.main;

public final class e {
  public static final String[] a = new String[] { 
      "Инфо", "Построить", "Тренировать", "Торговля", "Отправка", "Тренировать", "О замке", "Cообщение", "Сообщения", "Производство", 
      "_SPLIT", "_CONSTRUCT", "Аукцион", "Список армий" };
  
  public static int b = 4;
  
  public static int c = 1;
  
  public static int d = 4344121;
  
  public static int e = 5177088;
  
  public static int f = 16711680;
  
  public static int g = 36095;
  
  static {
    (new String[27])[0] = "Отмена";
    (new String[27])[1] = "Развить";
    (new String[27])[2] = "Разрушить";
    (new String[27])[3] = "?";
    (new String[27])[4] = "Тренировать";
    (new String[27])[5] = "Сообщение";
    (new String[27])[6] = "Нападение";
    (new String[27])[7] = "Торговля";
    (new String[27])[8] = "Построить";
    (new String[27])[9] = "Вход";
    (new String[27])[10] = "Регистрация";
    (new String[27])[11] = "+";
    (new String[27])[12] = "-";
    (new String[27])[13] = "MAX";
    (new String[27])[14] = "Тренировать";
    (new String[27])[15] = "Отправить";
    (new String[27])[16] = "Ответить";
    (new String[27])[17] = "Прочитать";
    (new String[27])[18] = "Удалить";
    (new String[27])[19] = "<-";
    (new String[27])[20] = "->";
    (new String[27])[21] = "OK";
    (new String[27])[22] = "_CONSTRUCT";
    (new String[27])[23] = "Купить";
    (new String[27])[24] = "Далее";
    (new String[27])[25] = "Назад";
    (new String[27])[26] = "Инфо";
  }
  
  static {
    (new int[3])[0] = 0;
    (new int[3])[1] = 1;
    (new int[3])[2] = 2;
    (new String[27])[0] = "Ратуша";
    (new String[27])[1] = "Склад";
    (new String[27])[2] = "Военный штаб";
    (new String[27])[3] = "Казарма";
    (new String[27])[4] = "Рынок";
    (new String[27])[5] = "Огород";
    (new String[27])[6] = "Хибара";
    (new String[27])[7] = "Дровосек";
    (new String[27])[8] = "Каменьщик";
    (new String[27])[9] = "Рудник";
    (new String[27])[10] = " ";
    (new String[27])[11] = "Кузнец";
    (new String[27])[12] = "Конюшня";
    (new String[27])[13] = "Посольство";
    (new String[27])[14] = "Дом мудрецов";
    (new String[27])[15] = "Университет";
    (new String[27])[16] = "Лагерь археологов";
    (new String[27])[17] = "Экспидиция";
    (new String[27])[18] = "Башня артефактов";
    (new String[27])[19] = "Торговая палата";
    (new String[27])[20] = "Академия магов";
    (new String[27])[21] = "Караульная башня";
    (new String[27])[22] = "";
    (new String[27])[23] = "Мастерская";
    (new String[27])[24] = "Дом путешественника";
    (new String[27])[25] = "Храм";
    (new String[27])[26] = "Тайник";
  }
}


/* Location:              C:\Users\sora\Desktop\Third_World_War_of_Kings_2D.jar!\com\fenix\main\e.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */