package com.fenix.main;

import ag;
import h;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;
import n;
import q;
import r;
import v;
import z;

public final class g extends f implements a, Runnable {
  public static String a;
  
  public static String b;
  
  private static g c = null;
  
  public static g a() {
    if (c == null)
      c = new g(); 
    return c;
  }
  
  private g() {
    a(this);
    c = this;
  }
  
  public final void b() {
    Thread thread;
    (thread = new Thread(this)).start();
  }
  
  public final void a(int paramInt) {}
  
  public final void a(Graphics paramGraphics) {
    paramGraphics.setColor(16777215);
    paramGraphics.fillRect(0, 0, i.a, i.b);
    Image image = c.a(15);
    paramGraphics.drawImage(this, i.a / 2 - getWidth() / 2, i.b / 2 - getHeight() / 2, 20);
  }
  
  public final void run() {
    try {
      Thread.sleep(1L);
      return;
    } catch (InterruptedException interruptedException) {
      return;
    } 
  }
  
  public static void c() {
    (ag.a()).a++;
    String[] arrayOfString = r.c();
    n[][] arrayOfN;
    (arrayOfN = new n[6][])[0] = new n[1];
    arrayOfN[1] = new n[1];
    arrayOfN[2] = new n[1];
    arrayOfN[3] = new n[1];
    arrayOfN[4] = new n[1];
    arrayOfN[5] = new n[1];
    arrayOfN[0][0] = (n)new z();
    ((z)arrayOfN[0][0]).e(10);
    arrayOfN[0][0].g(1);
    arrayOfN[0][0].h(0);
    arrayOfN[1][0] = (n)new v(5, 10);
    arrayOfN[1][0].i(1);
    arrayOfN[1][0].g(1);
    arrayOfN[1][0].h(1);
    arrayOfN[2][0] = (n)new v(2, 10);
    arrayOfN[2][0].i(2);
    arrayOfN[2][0].g(1);
    arrayOfN[2][0].h(1);
    if (arrayOfString != null) {
      ((v)arrayOfN[1][0]).a(arrayOfString[0].toUpperCase());
      ((v)arrayOfN[2][0]).a(arrayOfString[1].toUpperCase());
    } else {
      ((v)arrayOfN[1][0]).a("Login");
      ((v)arrayOfN[2][0]).a("Password");
      ((v)arrayOfN[2][0]).b = 0;
    } 
    arrayOfN[3][0] = (n)new h();
    ((h)arrayOfN[3][0]).f(9);
    ((h)arrayOfN[3][0]).b("Вход");
    ((h)arrayOfN[3][0]).g(1);
    ((h)arrayOfN[3][0]).h(1);
    arrayOfN[4][0] = (n)new h();
    ((h)arrayOfN[4][0]).f(10);
    ((h)arrayOfN[4][0]).g(1);
    ((h)arrayOfN[4][0]).b("Регистрация");
    ((h)arrayOfN[4][0]).h(1);
    int[] arrayOfInt = { 5, 0, 0 };
    arrayOfN[5][0] = (n)new h();
    ((h)arrayOfN[5][0]).f(22);
    ((h)arrayOfN[5][0]).b("Забыли пароль?");
    ((h)arrayOfN[5][0]).a(arrayOfInt, 1);
    ((h)arrayOfN[5][0]).g(1);
    ((h)arrayOfN[5][0]).h(1);
    q q;
    (q = new q()).a(100, 100);
    q.a(null, arrayOfN);
    q.b(5);
    b.a().a((f)q);
    c = null;
  }
}


/* Location:              C:\Users\sora\Desktop\Third_World_War_of_Kings_2D.jar!\com\fenix\main\g.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */