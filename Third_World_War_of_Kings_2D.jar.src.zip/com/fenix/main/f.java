package com.fenix.main;

import javax.microedition.lcdui.Graphics;

public abstract class f {
  private a a;
  
  public abstract void a(Graphics paramGraphics);
  
  public final void a(a parama) {
    this.a = parama;
  }
  
  public final void e(int paramInt) {
    if (this.a != null)
      this.a.a(paramInt); 
  }
}


/* Location:              C:\Users\sora\Desktop\Third_World_War_of_Kings_2D.jar!\com\fenix\main\f.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */