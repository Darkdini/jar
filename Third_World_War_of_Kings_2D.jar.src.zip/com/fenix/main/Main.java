package com.fenix.main;

import af;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Screen;
import javax.microedition.lcdui.TextBox;
import javax.microedition.midlet.MIDlet;
import n;
import v;

public class Main extends MIDlet implements CommandListener {
  private static Main a = null;
  
  private static Display b = null;
  
  private Command c = null;
  
  private Command d = null;
  
  private TextBox e = null;
  
  private Screen f;
  
  private static String g = null;
  
  private static n h;
  
  public static Main a() {
    return a;
  }
  
  public Main() {
    a = this;
    b = Display.getDisplay(this);
  }
  
  public static void a(String paramString) {
    g = paramString;
  }
  
  protected void startApp() {
    h.a();
    i i = new i();
    b.setCurrent((Displayable)this);
  }
  
  protected void pauseApp() {}
  
  public static void a(n paramn) {
    h = paramn;
  }
  
  public void commandAction(Command paramCommand, Displayable paramDisplayable) {
    String str;
    if (paramCommand == this.c) {
      i.c();
      g = str = this.e.getString();
      if (h != null) {
        if (h instanceof af)
          ((af)h).a(g); 
        if (h instanceof v)
          ((v)h).a(g); 
      } 
      b.setCurrent((Displayable)i.a());
      this.f = null;
      return;
    } 
    if (str == this.d) {
      i.c();
      if (h != null) {
        if (h instanceof af) {
          g = str = ((af)h).b();
          ((af)h).a(((af)h).b());
        } 
        if (h instanceof v) {
          g = str = ((v)h).b();
          ((v)h).a(((v)h).b());
        } 
      } 
      b.setCurrent((Displayable)i.a());
      this.f = null;
    } 
  }
  
  private Command d() {
    if (this.d == null)
      this.d = new Command("Cancel", 3, 20); 
    return this.d;
  }
  
  private Command e() {
    if (this.c == null)
      this.c = new Command("Ok", 4, 30); 
    return this.c;
  }
  
  public final void a(int paramInt) {
    this.f = null;
    this.e = new TextBox("Enter text:", g, paramInt, 0);
    Main main;
    this.f = (Screen)(main = this).e;
    this.f.addCommand(e());
    this.f.addCommand(d());
    this.f.setCommandListener(this);
    b.setCurrent((Displayable)this.f);
  }
  
  public final void b() {
    this.f = null;
    this.e = new TextBox("Enter text:", g, 2000, 0);
    Main main;
    this.f = (Screen)(main = this).e;
    this.f.addCommand(e());
    this.f.addCommand(d());
    this.f.setCommandListener(this);
    b.setCurrent((Displayable)this.f);
  }
  
  public final void b(int paramInt) {
    this.f = null;
    this.e = new TextBox("Enter text:", g, paramInt, 0);
    Main main;
    this.f = (Screen)(main = this).e;
    this.f.addCommand(e());
    this.f.addCommand(d());
    this.f.setCommandListener(this);
    b.setCurrent((Displayable)this.f);
  }
  
  public final void c(int paramInt) {
    this.f = null;
    this.e = new TextBox("Enter text:", g, paramInt, 2);
    Main main;
    this.f = (Screen)(main = this).e;
    this.f.addCommand(e());
    this.f.addCommand(d());
    this.f.setCommandListener(this);
    b.setCurrent((Displayable)this.f);
  }
  
  protected void destroyApp(boolean paramBoolean) {
    i.a().b();
    h.a();
    b.setCurrent(null);
  }
  
  public final void c() {
    destroyApp(true);
    notifyDestroyed();
  }
}


/* Location:              C:\Users\sora\Desktop\Third_World_War_of_Kings_2D.jar!\com\fenix\main\Main.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */