package com.fenix.main;

import javax.microedition.lcdui.Font;

public final class h {
  private static h h;
  
  public static int a = 16777215;
  
  public static int b = 2500;
  
  public static String c = "mmog1.com";
  
  public static Font d = Font.getFont(0, 0, 8);
  
  public static Font e = Font.getFont(0, 4, 8);
  
  public static Font f = Font.getFont(0, 2, 8);
  
  public static Font g = Font.getFont(0, 1, 8);
  
  public static h a() {
    if (h == null)
      h = new h(); 
    return h;
  }
  
  private h() {
    h = this;
  }
  
  static {
    Font.getFont(0, 2, 8);
  }
  
  static {
    Font.getFont(0, 1, 16);
    Font.getFont(0, 1, 0);
    Font.getFont(0, 3, 0);
    Font.getFont(0, 0, 0);
  }
}


/* Location:              C:\Users\sora\Desktop\Third_World_War_of_Kings_2D.jar!\com\fenix\main\h.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */