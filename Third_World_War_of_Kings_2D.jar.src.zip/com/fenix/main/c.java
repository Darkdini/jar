package com.fenix.main;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.Hashtable;
import javax.microedition.lcdui.Image;
import javax.microedition.rms.RecordStore;

public final class c {
  private static String s = "Images";
  
  private static Hashtable t = new Hashtable();
  
  private static int u = 0;
  
  public static Image[] a;
  
  public static Image[] b;
  
  public static Image[] c;
  
  public static Image[] d;
  
  public static Image[] e;
  
  public static Image[] f;
  
  public static Image[] g;
  
  public static Image h;
  
  public static Image i;
  
  public static Image j;
  
  private static Image v;
  
  private static Image[] w;
  
  private static Image[] x;
  
  private static Image[] y;
  
  private static Image[] z;
  
  private static Image[] A;
  
  private static Image[] B;
  
  public static Image k;
  
  public static Image l;
  
  public static Image m;
  
  public static Image n;
  
  public static Image o;
  
  public static Image p;
  
  public static Image q;
  
  public static int[] r;
  
  private static int[] C = new int[0];
  
  private static Image[] D = new Image[0];
  
  private static long[] E = new long[0];
  
  private static Image[] F;
  
  private static Image[] G;
  
  private static Image[] H;
  
  private static Image[] I;
  
  public static void a() {
    d();
    l = Image.createImage("/smallicon/button.png");
    m = Image.createImage("/smallicon/button2.png");
    n = Image.createImage("/smallicon/theme.png");
    o = Image.createImage("/smallicon/scroll.png");
    p = Image.createImage("/smallicon/scroll_bg.png");
    (B = new Image[7])[0] = Image.createImage("/smallicon/softback.png");
    B[1] = Image.createImage("/smallicon/softclose.png");
    B[2] = Image.createImage("/smallicon/softedit.png");
    B[3] = Image.createImage("/smallicon/softmenu.png");
    B[4] = Image.createImage("/smallicon/soft_help.png");
    k = Image.createImage("/smallicon/background.png");
    B[5] = Image.createImage("/smallicon/softkey_left.png");
    B[6] = Image.createImage("/smallicon/softkey_right.png");
    q = Image.createImage("/smallicon/softback.png");
  }
  
  public static void b() {
    Image.createImage("/smallicon/border.png");
    v = Image.createImage("/user_search.png");
    (a = new Image[30])[0] = Image.createImage("/ground/grass.png");
    a[1] = Image.createImage("/ground/stone.png");
    a[2] = Image.createImage("/ground/roadS0.png");
    a[3] = Image.createImage("/ground/roadS1.png");
    a[4] = Image.createImage("/ground/roadS2.png");
    a[5] = Image.createImage("/ground/roadG0.png");
    a[6] = Image.createImage("/ground/roadG1.png");
    a[7] = Image.createImage("/ground/ground.png");
    a[8] = Image.createImage("/ground/stone1.png");
    a[9] = Image.createImage("/ground/water.png");
    a[10] = Image.createImage("/ground/castle.png");
    a[11] = Image.createImage("/ground/grass1.png");
    a[12] = Image.createImage("/ground/arrowup.png");
    a[13] = Image.createImage("/ground/arrowright.png");
    a[14] = Image.createImage("/ground/arrowdown.png");
    a[15] = Image.createImage("/ground/arrowleft.png");
    a[16] = Image.createImage("/ground/rov0.png");
    try {
      a[17] = Image.createImage("/ground/rov5.png");
      a[18] = Image.createImage("/ground/rov4.png");
      a[19] = Image.createImage("/ground/rov1.png");
      a[20] = Image.createImage("/ground/rov7.png");
      a[21] = Image.createImage("/ground/rov3.png");
      a[22] = Image.createImage("/ground/rov2.png");
      a[23] = Image.createImage("/ground/rov6.png");
      a[24] = Image.createImage("/ground/castle_old.png");
      a[25] = Image.createImage("/ground/dikari.png");
      a[26] = Image.createImage("/ground/lumber.png");
      a[27] = Image.createImage("/ground/troll_rudnik.png");
      a[28] = Image.createImage("/ground/castle_small.png");
      a[29] = Image.createImage("/ground/castle_big.png");
    } catch (IOException iOException2) {
      IOException iOException1;
      (iOException1 = null).printStackTrace();
    } 
    (d = new Image[3])[0] = Image.createImage("/ground/wood.png");
    d[1] = Image.createImage("/ground/walun.png");
    d[2] = Image.createImage("/ground/mount.png");
    (e = new Image[24])[0] = Image.createImage("/gborder/ground/0.png");
    e[1] = Image.createImage("/gborder/ground/1.png");
    e[2] = Image.createImage("/gborder/ground/2.png");
    e[3] = Image.createImage("/gborder/ground/3.png");
    e[4] = Image.createImage("/gborder/ground/40.png");
    e[5] = Image.createImage("/gborder/ground/41.png");
    e[6] = Image.createImage("/gborder/ground/50.png");
    e[7] = Image.createImage("/gborder/ground/51.png");
    e[8] = Image.createImage("/gborder/ground/60.png");
    e[9] = Image.createImage("/gborder/ground/61.png");
    e[10] = Image.createImage("/gborder/ground/70.png");
    e[11] = Image.createImage("/gborder/ground/71.png");
    e[12] = Image.createImage("/gborder/water/0.png");
    e[13] = Image.createImage("/gborder/water/1.png");
    e[14] = Image.createImage("/gborder/water/2.png");
    e[15] = Image.createImage("/gborder/water/3.png");
    e[16] = Image.createImage("/gborder/water/40.png");
    e[17] = Image.createImage("/gborder/water/41.png");
    e[18] = Image.createImage("/gborder/water/50.png");
    e[19] = Image.createImage("/gborder/water/51.png");
    e[20] = Image.createImage("/gborder/water/60.png");
    e[21] = Image.createImage("/gborder/water/61.png");
    e[22] = Image.createImage("/gborder/water/70.png");
    e[23] = Image.createImage("/gborder/water/71.png");
    (c = new Image[47])[0] = Image.createImage("/build/castle.png");
    c[1] = Image.createImage("/build/storage.png");
    c[2] = Image.createImage("/build/mbases.png");
    c[3] = Image.createImage("/build/baraks.png");
    c[4] = Image.createImage("/build/market.png");
    c[5] = Image.createImage("/build/farm_small.png");
    c[6] = Image.createImage("/build/house_small.png");
    c[7] = Image.createImage("/build/sawmill_small.png");
    c[8] = Image.createImage("/build/stone_small.png");
    c[9] = Image.createImage("/build/iron_small.png");
    c[10] = Image.createImage("/build/build.png");
    c[11] = Image.createImage("/build/smith.png");
    c[12] = Image.createImage("/build/stables.png");
    c[13] = Image.createImage("/build/diplomat.png");
    c[14] = Image.createImage("/build/wisdom_house.png");
    c[15] = Image.createImage("/build/university.png");
    c[16] = Image.createImage("/build/arhcamp.png");
    c[17] = Image.createImage("/build/expedition.png");
    c[18] = Image.createImage("/build/art_tower.png");
    c[19] = Image.createImage("/build/commerce.png");
    c[20] = Image.createImage("/build/magtower.png");
    c[21] = Image.createImage("/build/guard_tower.png");
    c[22] = null;
    c[23] = Image.createImage("/build/workshop.png");
    c[24] = Image.createImage("/build/traveler.png");
    c[25] = Image.createImage("/build/temple.png");
    c[26] = Image.createImage("/build/secret.png");
    c[27] = Image.createImage("/build/sawmill_avg.png");
    c[28] = Image.createImage("/build/stone_avg.png");
    c[29] = Image.createImage("/build/iron_avg.png");
    c[30] = Image.createImage("/build/farm_avg.png");
    c[31] = Image.createImage("/build/house_avg.png");
    c[32] = Image.createImage("/build/sawmill_big.png");
    c[33] = Image.createImage("/build/stone_big.png");
    c[34] = Image.createImage("/build/iron_big.png");
    c[35] = Image.createImage("/build/farm_big.png");
    c[36] = Image.createImage("/build/house_big.png");
    c[37] = Image.createImage("/build/chip.png");
    c[38] = Image.createImage("/build/portal.png");
    c[39] = Image.createImage("/build/magscool.png");
    c[40] = Image.createImage("/build/builder.png");
    c[41] = Image.createImage("/build/beer.png");
    c[42] = Image.createImage("/build/gendel.png");
    c[43] = Image.createImage("/build/alchimia.png");
    c[44] = Image.createImage("/build/reasury.png");
    c[45] = Image.createImage("/build/spycentr.png");
    c[46] = Image.createImage("/build/resident.png");
    (f = new Image[5])[0] = Image.createImage("/fence/fence0.png");
    f[1] = Image.createImage("/fence/fence1.png");
    f[2] = Image.createImage("/fence/fence2.png");
    f[3] = Image.createImage("/fence/fence3.png");
    f[4] = Image.createImage("/fence/fence4.png");
    h = Image.createImage("/cursor.png");
    i = Image.createImage("/cursor_wait.png");
    j = Image.createImage("/cursor_web.png");
    (g = new Image[6])[0] = Image.createImage("/res/wood.png");
    g[1] = Image.createImage("/res/stone.png");
    g[2] = Image.createImage("/res/iron.png");
    g[3] = Image.createImage("/res/food.png");
    g[4] = Image.createImage("/res/people.png");
    g[5] = Image.createImage("/res/time.png");
    (w = new Image[45])[21] = Image.createImage("/units/human/torg.png");
    w[22] = Image.createImage("/units/elf/torg.png");
    w[23] = Image.createImage("/units/dwarv/torg.png");
    w[24] = Image.createImage("/units/human/traveler.png");
    w[25] = Image.createImage("/units/elf/traveler.png");
    w[26] = Image.createImage("/units/dwarv/traveler.png");
    w[27] = Image.createImage("/units/human/wisdom.png");
    w[28] = Image.createImage("/units/elf/wisdom.png");
    w[29] = Image.createImage("/units/dwarv/wisdom.png");
    w[33] = Image.createImage("/units/human/buntar.png");
    w[34] = Image.createImage("/units/elf/buntar.png");
    w[35] = Image.createImage("/units/dwarv/buntar.png");
    w[36] = Image.createImage("/units/human/general.png");
    w[37] = Image.createImage("/units/elf/general.png");
    w[38] = Image.createImage("/units/dwarv/general.png");
    (x = new Image[45])[0] = Image.createImage("/smallunits/human/swordman.png");
    x[1] = Image.createImage("/smallunits/human/javelineer.png");
    x[2] = Image.createImage("/smallunits/human/scout.png");
    x[3] = Image.createImage("/smallunits/human/mage.png");
    x[4] = Image.createImage("/smallunits/human/knight.png");
    x[5] = Image.createImage("/smallunits/human/paladin.png");
    x[6] = Image.createImage("/smallunits/human/jin.png");
    x[7] = Image.createImage("/smallunits/elf/archer.png");
    x[8] = Image.createImage("/smallunits/elf/fighter.png");
    x[9] = Image.createImage("/smallunits/elf/scout.png");
    x[10] = Image.createImage("/smallunits/elf/create.png");
    x[11] = Image.createImage("/smallunits/elf/kenaur.png");
    x[12] = Image.createImage("/smallunits/elf/edinorog.png");
    x[13] = Image.createImage("/smallunits/elf/ent.png");
    x[14] = Image.createImage("/smallunits/dwarv/fighter.png");
    x[15] = Image.createImage("/smallunits/dwarv/arbalet.png");
    x[16] = Image.createImage("/smallunits/dwarv/elder.png");
    x[17] = Image.createImage("/smallunits/dwarv/gryphon.png");
    x[18] = Image.createImage("/smallunits/dwarv/defender.png");
    x[19] = Image.createImage("/smallunits/dwarv/revolver.png");
    x[20] = Image.createImage("/smallunits/dwarv/yeti.png");
    x[14] = Image.createImage("/smallunits/dwarv/fighter.png");
    x[15] = Image.createImage("/smallunits/dwarv/arbalet.png");
    x[16] = Image.createImage("/smallunits/dwarv/elder.png");
    x[17] = Image.createImage("/smallunits/dwarv/gryphon.png");
    x[18] = Image.createImage("/smallunits/dwarv/defender.png");
    x[19] = Image.createImage("/smallunits/dwarv/revolver.png");
    x[20] = Image.createImage("/smallunits/dwarv/yeti.png");
    x[21] = Image.createImage("/smallunits/human/torg.png");
    x[22] = Image.createImage("/smallunits/elf/torg.png");
    x[23] = Image.createImage("/smallunits/dwarv/torg.png");
    x[24] = Image.createImage("/smallunits/human/traveler.png");
    x[25] = Image.createImage("/smallunits/elf/traveler.png");
    x[26] = Image.createImage("/smallunits/dwarv/traveler.png");
    x[27] = Image.createImage("/smallunits/human/wisdom.png");
    x[28] = Image.createImage("/smallunits/elf/wisdom.png");
    x[29] = Image.createImage("/smallunits/dwarv/wisdom.png");
    x[30] = Image.createImage("/smallunits/human/arheolog.png");
    x[31] = Image.createImage("/smallunits/elf/arheolog.png");
    x[32] = Image.createImage("/smallunits/dwarv/arheolog.png");
    x[33] = Image.createImage("/smallunits/human/buntar.png");
    x[34] = Image.createImage("/smallunits/elf/buntar.png");
    x[35] = Image.createImage("/smallunits/dwarv/buntar.png");
    x[36] = Image.createImage("/smallunits/human/general.png");
    x[37] = Image.createImage("/smallunits/elf/general.png");
    x[38] = Image.createImage("/smallunits/dwarv/general.png");
    x[39] = Image.createImage("/smallunits/unical/giant.png");
    x[40] = Image.createImage("/smallunits/unical/katapulta.png");
    x[41] = Image.createImage("/smallunits/unical/oko.png");
    x[42] = Image.createImage("/smallunits/unical/shadow.png");
    x[43] = Image.createImage("/smallunits/unical/taran.png");
    x[44] = Image.createImage("/smallunits/unical/valkiriya.png");
    (I = new Image[8])[0] = Image.createImage("/smallicon/smiles/smile.png");
    I[1] = Image.createImage("/smallicon/smiles/Uvula.png");
    I[2] = Image.createImage("/smallicon/smiles/wok.png");
    I[3] = Image.createImage("/smallicon/smiles/sad.png");
    I[4] = Image.createImage("/smallicon/smiles/notund.png");
    I[5] = Image.createImage("/smallicon/smiles/angry.png");
    I[6] = Image.createImage("/smallicon/smiles/kiss.png");
    I[7] = Image.createImage("/smallicon/smiles/heart.png");
    (y = new Image[26])[0] = Image.createImage("/smallicon/blueball.png");
    y[1] = Image.createImage("/smallicon/greenball.png");
    y[2] = Image.createImage("/smallicon/grayball.png");
    y[3] = Image.createImage("/smallicon/swordred.png");
    y[4] = Image.createImage("/smallicon/swordgreen.png");
    y[5] = Image.createImage("/smallicon/shieldblue.png");
    y[6] = Image.createImage("/smallicon/shieldgreen.png");
    y[7] = Image.createImage("/smallicon/health.png");
    y[8] = Image.createImage("/smallicon/phiattack.png");
    y[9] = Image.createImage("/smallicon/magattack.png");
    y[10] = Image.createImage("/smallicon/phidef.png");
    y[11] = Image.createImage("/smallicon/magdef.png");
    y[12] = Image.createImage("/smallicon/phiblock.png");
    y[13] = Image.createImage("/smallicon/magblock.png");
    y[14] = Image.createImage("/smallicon/maxupgrade.png");
    y[15] = Image.createImage("/smallicon/upgrade.png");
    y[16] = Image.createImage("/smallicon/destroy.png");
    y[17] = Image.createImage("/smallicon/plus.png");
    y[18] = Image.createImage("/smallicon/fencebonus.png");
    y[21] = Image.createImage("/smallicon/speed.png");
    y[22] = Image.createImage("/smallicon/carry.png");
    y[23] = Image.createImage("/smallicon/coin_gold.png");
    y[24] = Image.createImage("/smallicon/wall_icon.png");
    y[25] = Image.createImage("/smallicon/surprize.png");
    (z = new Image[12])[0] = Image.createImage("/smallicon/status/online.png");
    z[1] = Image.createImage("/smallicon/status/1day.png");
    z[2] = Image.createImage("/smallicon/status/3day.png");
    z[3] = Image.createImage("/smallicon/status/5day.png");
    z[4] = Image.createImage("/smallicon/status/7day.png");
    z[5] = Image.createImage("/smallicon/status/l7day.png");
    z[6] = Image.createImage("/smallicon/status/gold.png");
    z[7] = Image.createImage("/smallicon/status/silver.png");
    z[8] = Image.createImage("/smallicon/status/bronze.png");
    z[11] = Image.createImage("/smallicon/status/f_gold.png");
    z[10] = Image.createImage("/smallicon/status/f_silver.png");
    z[9] = Image.createImage("/smallicon/status/f_bronze.png");
    A = new Image[1];
    (F = new Image[4])[0] = Image.createImage("/smallicon/Ekoscience.png");
    F[1] = Image.createImage("/smallicon/Engscience.png");
    F[2] = Image.createImage("/smallicon/Warscience.png");
    F[3] = Image.createImage("/smallicon/Fhiscience.png");
    (G = new Image[4])[0] = Image.createImage("/smallicon/artefacts/artefakt_bat.png");
    G[1] = Image.createImage("/smallicon/artefacts/artefakt_dragon.png");
    G[2] = Image.createImage("/smallicon/artefacts/artefakt_spider.png");
    G[3] = Image.createImage("/smallicon/artefacts/artefakt_wampire_blood.png");
    (H = new Image[19])[0] = Image.createImage("/smallicon/bonus_status/coronalherb.png");
    H[1] = Image.createImage("/smallicon/bonus_status/coronalbronze.png");
    H[2] = Image.createImage("/smallicon/bonus_status/coronalsilver.png");
    H[3] = Image.createImage("/smallicon/bonus_status/coronalgold.png");
    H[4] = Image.createImage("/smallicon/bonus_status/Crossbronze.png");
    H[5] = Image.createImage("/smallicon/bonus_status/Crosssilver.png");
    H[6] = Image.createImage("/smallicon/bonus_status/Crossgold.png");
    H[7] = Image.createImage("/smallicon/bonus_status/medalbronze.png");
    H[8] = Image.createImage("/smallicon/bonus_status/medalsiver.png");
    H[9] = Image.createImage("/smallicon/bonus_status/medalgold.png");
    H[10] = Image.createImage("/smallicon/bonus_status/torbabronze.png");
    H[11] = Image.createImage("/smallicon/bonus_status/torbasilver.png");
    H[12] = Image.createImage("/smallicon/bonus_status/torbagold.png");
    H[13] = Image.createImage("/smallicon/bonus_status/vesibronze.png");
    H[14] = Image.createImage("/smallicon/bonus_status/vesisilver.png");
    H[15] = Image.createImage("/smallicon/bonus_status/vesigold.png");
    H[16] = Image.createImage("/smallicon/bonus_status/rangbronze.png");
    H[17] = Image.createImage("/smallicon/bonus_status/rangsilver.png");
    H[18] = Image.createImage("/smallicon/bonus_status/ranggold.png");
    (b = new Image[12])[0] = Image.createImage("/border/angle_top_left.png");
    b[1] = Image.createImage("/border/angle_top_right.png");
    b[2] = Image.createImage("/border/angle_bottom_left.png");
    b[3] = Image.createImage("/border/angle_bottom_right.png");
    b[4] = Image.createImage("/border/border_top.png");
    b[5] = Image.createImage("/border/border_bottom.png");
    b[6] = Image.createImage("/border/border_left.png");
    b[7] = Image.createImage("/border/border_right.png");
    b[8] = Image.createImage("/border/info_bg1.png");
    b[9] = Image.createImage("/border/info_bg2.png");
    b[10] = Image.createImage("/border/info_bg3.png");
    b[11] = Image.createImage("/border/bgtop.png");
  }
  
  public static Image a(int paramInt) {
    try {
      Image image2;
      if (C != null && C.length > 0)
        for (byte b = 0; b < C.length; b++) {
          if (C[b] == paramInt) {
            if (D[b] != null) {
              c(b);
              return D[b];
            } 
            c();
          } 
        }  
      switch (paramInt) {
        case 0:
          return g[0];
        case 1:
          return g[1];
        case 2:
          return g[2];
        case 3:
          return g[3];
        case 4:
          return g[4];
        case 5:
          return g[5];
        case 15:
          image2 = Image.createImage("/logo.png");
          a(15, image2);
          return image2;
        case 100:
          return c[0];
        case 101:
          return c[1];
        case 102:
          return c[2];
        case 103:
          return c[3];
        case 104:
          return c[4];
        case 105:
          return c[5];
        case 106:
          return c[6];
        case 107:
          return c[7];
        case 108:
          return c[8];
        case 109:
          return c[9];
        case 110:
          return c[10];
        case 111:
          return c[11];
        case 112:
          return c[12];
        case 113:
          return c[13];
        case 114:
          return c[14];
        case 115:
          return c[15];
        case 116:
          return c[16];
        case 117:
          return c[17];
        case 118:
          return c[18];
        case 119:
          return c[19];
        case 120:
          return c[20];
        case 121:
          return c[21];
        case 122:
          return c[22];
        case 123:
          return c[23];
        case 124:
          return c[24];
        case 125:
          return c[25];
        case 126:
          return c[26];
        case 127:
          return c[27];
        case 128:
          return c[28];
        case 129:
          return c[29];
        case 130:
          return c[30];
        case 131:
          return c[31];
        case 132:
          return c[32];
        case 133:
          return c[33];
        case 134:
          return c[34];
        case 135:
          return c[35];
        case 136:
          return c[36];
        case 137:
          return c[37];
        case 138:
          return c[38];
        case 139:
          return c[39];
        case 140:
          return c[40];
        case 141:
          return c[41];
        case 142:
          return c[42];
        case 143:
          return c[43];
        case 144:
          return c[44];
        case 145:
          return c[45];
        case 146:
          return c[46];
        case 200:
          image2 = Image.createImage("/units/human/swordman.png");
          a(200, image2);
          return image2;
        case 201:
          image2 = Image.createImage("/units/human/javelineer.png");
          a(201, image2);
          return image2;
        case 202:
          image2 = Image.createImage("/units/human/scout.png");
          a(202, image2);
          return image2;
        case 203:
          image2 = Image.createImage("/units/human/mage.png");
          a(203, image2);
          return image2;
        case 204:
          image2 = Image.createImage("/units/human/knight.png");
          a(204, image2);
          return image2;
        case 205:
          image2 = Image.createImage("/units/human/paladin.png");
          a(205, image2);
          return image2;
        case 206:
          image2 = Image.createImage("/units/human/jin.png");
          a(206, image2);
          return image2;
        case 207:
          image2 = Image.createImage("/units/elf/archer.png");
          a(207, image2);
          return image2;
        case 208:
          image2 = Image.createImage("/units/elf/fighter.png");
          a(208, image2);
          return image2;
        case 209:
          image2 = Image.createImage("/units/elf/scout.png");
          a(209, image2);
          return image2;
        case 210:
          image2 = Image.createImage("/units/elf/create.png");
          a(210, image2);
          return image2;
        case 211:
          image2 = Image.createImage("/units/elf/kenaur.png");
          a(211, image2);
          return image2;
        case 212:
          image2 = Image.createImage("/units/elf/edinorog.png");
          a(212, image2);
          return image2;
        case 213:
          image2 = Image.createImage("/units/elf/ent.png");
          a(213, image2);
          return image2;
        case 214:
          image2 = Image.createImage("/units/dwarv/fighter.png");
          a(214, image2);
          return image2;
        case 215:
          image2 = Image.createImage("/units/dwarv/arbalet.png");
          a(215, image2);
          return image2;
        case 216:
          image2 = Image.createImage("/units/dwarv/elder.png");
          a(216, image2);
          return image2;
        case 217:
          image2 = Image.createImage("/units/dwarv/gryphon.png");
          a(217, image2);
          return image2;
        case 218:
          image2 = Image.createImage("/units/dwarv/defender.png");
          a(218, image2);
          return image2;
        case 219:
          image2 = Image.createImage("/units/dwarv/revolver.png");
          a(219, image2);
          return image2;
        case 220:
          image2 = Image.createImage("/units/dwarv/yeti.png");
          a(220, image2);
          return image2;
        case 221:
          return w[21];
        case 222:
          return w[22];
        case 223:
          return w[23];
        case 224:
          return w[24];
        case 225:
          return w[25];
        case 226:
          return w[26];
        case 227:
          return w[27];
        case 228:
          return w[28];
        case 229:
          return w[29];
        case 230:
          image2 = Image.createImage("/units/human/arheolog.png");
          a(230, image2);
          return image2;
        case 231:
          image2 = Image.createImage("/units/elf/arheolog.png");
          a(231, image2);
          return image2;
        case 232:
          image2 = Image.createImage("/units/dwarv/arheolog.png");
          a(232, image2);
          return image2;
        case 233:
          return w[33];
        case 234:
          return w[34];
        case 235:
          return w[35];
        case 236:
          return w[36];
        case 237:
          return w[37];
        case 238:
          return w[38];
        case 239:
          image2 = Image.createImage("/units/unical/giant.png");
          a(239, image2);
          return image2;
        case 240:
          image2 = Image.createImage("/units/unical/katapulta.png");
          a(240, image2);
          return image2;
        case 241:
          image2 = Image.createImage("/units/unical/oko.png");
          a(241, image2);
          return image2;
        case 242:
          image2 = Image.createImage("/units/unical/shadow.png");
          a(242, image2);
          return image2;
        case 243:
          image2 = Image.createImage("/units/unical/taran.png");
          a(243, image2);
          return image2;
        case 244:
          image2 = Image.createImage("/units/unical/valkiriya.png");
          a(244, image2);
          return image2;
        case 300:
          return x[0];
        case 301:
          return x[1];
        case 302:
          return x[2];
        case 303:
          return x[3];
        case 304:
          return x[4];
        case 305:
          return x[5];
        case 306:
          return x[6];
        case 307:
          return x[7];
        case 308:
          return x[8];
        case 309:
          return x[9];
        case 310:
          return x[10];
        case 311:
          return x[11];
        case 312:
          return x[12];
        case 313:
          return x[13];
        case 314:
          return x[14];
        case 315:
          return x[15];
        case 316:
          return x[16];
        case 317:
          return x[17];
        case 318:
          return x[18];
        case 319:
          return x[19];
        case 320:
          return x[20];
        case 321:
          return x[21];
        case 322:
          return x[22];
        case 323:
          return x[23];
        case 324:
          return x[24];
        case 325:
          return x[25];
        case 326:
          return x[26];
        case 327:
          return x[27];
        case 328:
          return x[28];
        case 329:
          return x[29];
        case 330:
          return x[30];
        case 331:
          return x[31];
        case 332:
          return x[32];
        case 333:
          return x[33];
        case 334:
          return x[34];
        case 335:
          return x[35];
        case 336:
          return x[36];
        case 337:
          return x[37];
        case 338:
          return x[38];
        case 339:
          return x[39];
        case 340:
          return x[40];
        case 341:
          return x[41];
        case 342:
          return x[42];
        case 343:
          return x[43];
        case 344:
          return x[44];
        case 700:
          return B[0];
        case 701:
          return B[1];
        case 702:
          return B[2];
        case 703:
          return B[3];
        case 704:
          return B[4];
        case 705:
          return B[5];
        case 706:
          return B[6];
        case 800:
          return F[0];
        case 801:
          return F[1];
        case 802:
          return F[2];
        case 803:
          return F[3];
        case 900:
          return G[0];
        case 901:
          return G[1];
        case 902:
          return G[2];
        case 903:
          return G[3];
        case 1000:
          return I[0];
        case 1001:
          return I[1];
        case 1002:
          return I[2];
        case 1003:
          return I[3];
        case 1004:
          return I[4];
        case 1005:
          return I[5];
        case 1006:
          return I[6];
        case 1007:
          return I[7];
      } 
      int i;
      switch (i = paramInt) {
        case 400:
        
        case 401:
        
        case 402:
        
        case 403:
        
        case 404:
        
        case 405:
        
        case 406:
        
        case 407:
        
        case 408:
        
        case 409:
        
        case 410:
        
        case 411:
        
        case 412:
        
        case 413:
        
        case 414:
        
        case 415:
        
        case 416:
        
        case 417:
        
        case 418:
        
        case 419:
        
        case 420:
        
        case 421:
        
        case 422:
        
        case 423:
        
        case 424:
        
        case 425:
        
        case 426:
        
        case 427:
        
        case 428:
        
        case 429:
        
        case 430:
        
        case 431:
        
        case 432:
        
        case 433:
        
        case 434:
        
        case 435:
        
        case 436:
        
        case 437:
        
        case 438:
        
        case 439:
        
        case 440:
        
        case 441:
        
        case 442:
        
        case 443:
        
        case 444:
        
        case 445:
        
        case 446:
        
        case 500:
        
        case 501:
        
        case 502:
        
        case 503:
        
        case 504:
        
        case 505:
        
        case 506:
        
        case 507:
        
        case 508:
        
        case 509:
        
        case 510:
        
        case 511:
        
        case 600:
        
        case 601:
        case 602:
        case 603:
        case 604:
        case 605:
        case 606:
        case 607:
        case 608:
        case 609:
        case 610:
        case 611:
        case 612:
        case 613:
        case 614:
        case 615:
        case 616:
        case 617:
        case 618:
        case 619:
        case 620:
        case 621:
        case 622:
        case 623:
        case 624:
        case 625:
        case 626:
        case 627:
        case 628:
        case 629:
        case 630:
        
        default:
          break;
      } 
      Image image1;
      return ((image1 = null) != null) ? image1 : b(paramInt);
    } catch (Exception exception) {
      System.out.println("Error on getImageByName");
      exception.printStackTrace();
      return null;
    } 
  }
  
  private static Image b(int paramInt) {
    try {
      Image image;
      if ((image = d(paramInt)) != null) {
        a(paramInt, image);
        return image;
      } 
      if (r != null)
        synchronized (r) {
          if (0 < r.length) {
            if (r[0] == paramInt)
              return q; 
            return q;
          } 
        }  
    } catch (Exception exception) {
      System.out.println("Error on getUnnamedPicture");
      exception.printStackTrace();
    } 
    return null;
  }
  
  public static void a(int paramInt, Image paramImage) {
    if (C == null || D == null) {
      C = new int[0];
      D = new Image[0];
      E = new long[0];
    } 
    for (byte b = 0; b < C.length; b++) {
      if (C[b] == paramInt) {
        c(b);
        return;
      } 
    } 
    if (C.length > 20) {
      long l = E[0];
      byte b1 = 0;
      for (byte b2 = 1; b2 < C.length; b2++) {
        if (l < E[b2]) {
          l = E[b2];
          b1 = b2;
        } 
      } 
      D[b1] = paramImage;
      c(b1);
      C[b1] = paramInt;
      return;
    } 
    int[] arrayOfInt = new int[C.length + 1];
    System.arraycopy(C, 0, arrayOfInt, 0, C.length);
    C = null;
    C = arrayOfInt;
    Image[] arrayOfImage = new Image[D.length + 1];
    System.arraycopy(D, 0, arrayOfImage, 0, D.length);
    D = null;
    D = arrayOfImage;
    long[] arrayOfLong = new long[E.length + 1];
    System.arraycopy(E, 0, arrayOfLong, 0, E.length);
    E = null;
    E = arrayOfLong;
    int i = arrayOfImage.length - 1;
    C[i] = paramInt;
    D[i] = paramImage;
    c(i);
  }
  
  public static void c() {
    C = new int[0];
    D = null;
    D = new Image[0];
    E = new long[0];
  }
  
  private static void c(int paramInt) {
    E[paramInt] = System.currentTimeMillis();
  }
  
  public static void a(byte[] paramArrayOfbyte, int paramInt) {
    RecordStore recordStore = null;
    try {
      recordStore = RecordStore.openRecordStore(s, true);
      ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
      DataOutputStream dataOutputStream;
      (dataOutputStream = new DataOutputStream(byteArrayOutputStream)).writeInt(paramInt);
      dataOutputStream.writeInt(paramArrayOfbyte.length);
      dataOutputStream.write(paramArrayOfbyte);
      dataOutputStream.flush();
      byte[] arrayOfByte = byteArrayOutputStream.toByteArray();
      recordStore.addRecord(arrayOfByte, 0, arrayOfByte.length);
      dataOutputStream.close();
      t.put(Integer.toString(paramInt), new Integer(u++));
      Image image = Image.createImage(paramArrayOfbyte, 0, paramArrayOfbyte.length);
      a(paramInt, image);
    } catch (Exception exception2) {
      Exception exception1;
      (exception1 = null).printStackTrace();
    } finally {
      try {
        if (recordStore != null)
          recordStore.closeRecordStore(); 
      } catch (Exception exception) {
        System.out.println("Error on loadImageToRms");
        System.err.println(exception);
      } 
    } 
  }
  
  private static Image d(int paramInt) {
    if (t.size() == 0)
      d(); 
    RecordStore recordStore = null;
    try {
      recordStore = RecordStore.openRecordStore(s, true);
      Integer integer;
      if ((integer = (Integer)t.get(Integer.toString(paramInt))) != null && recordStore.getNumRecords() > 0) {
        int i = integer.intValue();
        byte[] arrayOfByte1 = recordStore.getRecord(i);
        ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(arrayOfByte1);
        DataInputStream dataInputStream;
        (dataInputStream = new DataInputStream(byteArrayInputStream)).readInt();
        int j;
        byte[] arrayOfByte2 = new byte[j = dataInputStream.readInt()];
        dataInputStream.readFully(arrayOfByte2);
        try {
          Image image = Image.createImage(arrayOfByte2, 0, j);
          Image image = image;
          return image;
        } catch (Exception exception1) {
          System.out.println("Error createRGBImage");
          System.err.println(exception1);
          return null;
        } 
      } 
      return null;
    } catch (Exception exception2) {
      Exception exception1;
      (exception1 = null).printStackTrace();
    } finally {
      try {
        if (exception != null)
          exception.closeRecordStore(); 
      } catch (Exception exception1) {
        System.out.println("Error on loadImageFromRms");
        System.err.println(exception1);
      } 
    } 
    return null;
  }
  
  private static void d() {
    if (t.size() != 0)
      return; 
    RecordStore recordStore = null;
    try {
      byte b = 1;
      if ((recordStore = RecordStore.openRecordStore(s, true)).getNumRecords() > 0)
        while (b <= recordStore.getNumRecords()) {
          byte[] arrayOfByte = recordStore.getRecord(b);
          ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(arrayOfByte);
          DataInputStream dataInputStream;
          int i = (dataInputStream = new DataInputStream(byteArrayInputStream)).readInt();
          dataInputStream.readInt();
          Integer integer = new Integer(b);
          t.put(Integer.toString(i), integer);
          b++;
        }  
      u = b;
    } catch (Exception exception2) {
      Exception exception1;
      (exception1 = null).printStackTrace();
    } finally {
      try {
        if (recordStore != null)
          recordStore.closeRecordStore(); 
      } catch (Exception exception) {
        System.out.println("Error on loadImageFromRms");
        System.err.println(exception);
      } 
    } 
  }
}


/* Location:              C:\Users\sora\Desktop\Third_World_War_of_Kings_2D.jar!\com\fenix\main\c.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */