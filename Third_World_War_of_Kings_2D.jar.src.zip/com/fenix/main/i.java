package com.fenix.main;

import ag;
import com.hellomoto.fullscreen.FullCn;
import java.io.IOException;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;
import k;

public final class i extends FullCn implements Runnable {
  private static i d;
  
  public static int a;
  
  public static int b;
  
  private b e;
  
  private int f;
  
  private boolean g;
  
  private Image h;
  
  private Graphics i;
  
  public static boolean c = false;
  
  private static boolean j = false;
  
  private int k = 0;
  
  private int l = 0;
  
  private long m;
  
  public static i a() {
    if (d == null)
      d = new i(); 
    return d;
  }
  
  public final void b() {
    this.g = false;
  }
  
  public i() {
    setFullScreenMode(true);
    d = this;
    a = getWidth();
    b = getHeight();
    try {
      c.a();
      c.b();
    } catch (IOException iOException) {}
    this.f = 0;
    this.e = b.a();
    g g;
    (g = g.a()).b();
    this.e.a(g);
    this.h = Image.createImage(a, b);
    this.i = this.h.getGraphics();
    ag.a().b();
    ag.a().b(0);
    d = this;
  }
  
  public final void run() {
    while (this.g) {
      long l1 = System.currentTimeMillis();
      f f = this.e.b();
      if (j)
        this.k++; 
      if (this.k > 15)
        f.e(this.f); 
      repaint();
      serviceRepaints();
      long l2 = System.currentTimeMillis() - l1;
      this.l++;
      if (l2 < 60L) {
        this.m += 60L;
        a(60L - l2);
      } else {
        this.m += l2;
        a(1L);
      } 
      if (this.m >= 1000L) {
        this.m -= 1000L;
        this.l = 0;
      } 
    } 
  }
  
  public final void paint(Graphics paramGraphics) {
    this.e.b().a(this.i);
    paramGraphics.drawImage(this.h, 0, 0, 20);
    paramGraphics.setColor(16777215);
    if ((k.a()).c.size() > 0) {
      paramGraphics.setFont(h.d);
      k.a().b(paramGraphics);
    } 
  }
  
  protected final void showNotify() {
    this.g = true;
    Thread thread;
    (thread = new Thread(this)).start();
  }
  
  protected final void hideNotify() {
    this.g = false;
  }
  
  public static void a(long paramLong) {
    try {
      Thread.sleep(paramLong);
      return;
    } catch (InterruptedException interruptedException) {
      return;
    } 
  }
  
  public static void c() {
    j = false;
  }
  
  protected final void KEYPRESSED(int paramInt) {
    paramInt = a(paramInt);
    this.f |= paramInt;
    if (paramInt != 8192 && paramInt != 4096) {
      j = true;
      this.k = 0;
    } 
    this.e.b().e(paramInt);
  }
  
  protected final void KEYRELEASED(int paramInt) {
    paramInt = a(paramInt);
    j = false;
    this.k = 0;
    this.f &= paramInt ^ 0xFFFFFFFF;
  }
  
  private int a(int paramInt) {
    switch (paramInt) {
      case -6:
        return 8192;
      case -7:
        return 4096;
      case 52:
        return 2;
      case 49:
        return 64;
      case 55:
        return 512;
      case 54:
        return 4;
      case 51:
        return 128;
      case 57:
        return 256;
      case 50:
        return 8;
      case 56:
        return 16;
      case 53:
        return 32;
      case -8:
        return 1048576;
      case 48:
        return 2048;
      case 35:
        return 16384;
      case 42:
        return 1024;
    } 
    switch (getGameAction(paramInt)) {
      case 2:
        return 262144;
      case 5:
        return 32768;
      case 1:
        return 65536;
      case 6:
        return 131072;
      case 8:
        return 524288;
      case 9:
        return 64;
      case 10:
        return 128;
      case 12:
        return 256;
      case 11:
        return 512;
    } 
    return 0;
  }
}


/* Location:              C:\Users\sora\Desktop\Third_World_War_of_Kings_2D.jar!\com\fenix\main\i.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */