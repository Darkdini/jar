/*     */ package com.hellomoto.fullscreen;
/*     */ 
/*     */ import javax.microedition.lcdui.game.GameCanvas;
/*     */ 
/*     */ 
/*     */ public abstract class FullCn
/*     */   extends GameCanvas
/*     */ {
/*     */   boolean setFullScreen;
/*     */   int[] codes;
/*     */   int[] CodeFrom;
/*     */   int[] CodeTo;
/*     */   int n;
/*     */   int cX;
/*     */   int cY;
/*     */   int t;
/*     */   int dX;
/*     */   int dY;
/*     */   int d;
/*     */   int key;
/*     */   int Pres;
/*     */   
/*     */   protected FullCn() {
/*  24 */     super(false);
/*  25 */     Init();
/*     */   }
/*     */ 
/*     */   
/*     */   protected FullCn(boolean flag) {
/*  30 */     super(flag);
/*  31 */     Init();
/*     */   }
/*     */ 
/*     */   
/*     */   private void Init() {
/*  36 */     this.setFullScreen = true;
/*  37 */     this.Pres = 53;
/*  38 */     this.n = 13;
/*  39 */     this.codes = new int[13];
/*  40 */     this.CodeFrom = new int[] { 0, 0, 50, 52, 54, 56, 53, -30, -31, -23, -31, 56, 54, -202, -202, -202, -202, -202, -202, -202, -202 };
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  45 */     this.CodeTo = new int[] { -6, -7, -1, -3, -4, -2, -5, 42, 35, 0, 51, 54, 56, -202, -202, -202, -202, -202, -202, -202, -202 };
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  50 */     setFullScreenMode(this.setFullScreen);
/*  51 */     for (int i = 0; i < 13; i++) {
/*     */       
/*  53 */       if (i != 0 && i != 3 && i != 4 && i != 7) {
/*     */         
/*  55 */         this.codes[i] = keyCodeConvert(super.getKeyCode(i));
/*     */       } else {
/*     */         
/*  58 */         this.codes[i] = 0;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private int keyCodeConvert(int i) {
/*  66 */     for (int j = 0; j < this.n; j++) {
/*     */       
/*  68 */       if (this.CodeFrom[j] == i)
/*     */       {
/*  70 */         return this.CodeTo[j];
/*     */       }
/*     */     } 
/*     */     
/*  74 */     return i;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void keyPressed(int i) {
/*  79 */     KEYPRESSED(keyCodeConvert(i));
/*     */   }
/*     */ 
/*     */   
/*     */   protected void keyReleased(int i) {
/*  84 */     KEYRELEASED(keyCodeConvert(i));
/*     */   }
/*     */ 
/*     */   
/*     */   protected void keyRepeated(int i) {
/*  89 */     KEYREPEATED(keyCodeConvert(i));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void KEYPRESSED(int i) {}
/*     */ 
/*     */ 
/*     */   
/*     */   protected void KEYRELEASED(int i) {}
/*     */ 
/*     */ 
/*     */   
/*     */   protected void KEYREPEATED(int i) {}
/*     */ 
/*     */   
/*     */   private int mod(int i) {
/* 106 */     if (i < 0)
/*     */     {
/* 108 */       i *= -1;
/*     */     }
/* 110 */     return i;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void keyPres(int i) {
/* 115 */     i = keyCodeConvert(i);
/* 116 */     if (this.key != i) {
/*     */       
/* 118 */       KEYRELEASED(this.key);
/* 119 */       KEYPRESSED(i);
/* 120 */       this.key = i;
/*     */     } else {
/*     */       
/* 123 */       KEYREPEATED(i);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void pointerDragged(int x, int y) {
/* 129 */     this.dX = mod(this.cX - x);
/* 130 */     this.dY = mod(this.cY - y);
/* 131 */     this.d = getWidth() / 10;
/* 132 */     if ((((mod(this.dX - this.dY) <= 7) ? 1 : 0) & (((this.dX + this.dY) / 2 > this.d - this.d / 2) ? 1 : 0)) != 0) {
/*     */       
/* 134 */       if ((((this.cX > x) ? 1 : 0) & ((this.cY > y) ? 1 : 0)) != 0) {
/*     */         
/* 136 */         keyPres(49);
/*     */       }
/* 138 */       else if ((((this.cX < x) ? 1 : 0) & ((this.cY > y) ? 1 : 0)) != 0) {
/*     */         
/* 140 */         keyPres(51);
/*     */       }
/* 142 */       else if ((((this.cX > x) ? 1 : 0) & ((this.cY < y) ? 1 : 0)) != 0) {
/*     */         
/* 144 */         keyPres(55);
/*     */       }
/* 146 */       else if ((((this.cX < x) ? 1 : 0) & ((this.cY < y) ? 1 : 0)) != 0) {
/*     */         
/* 148 */         keyPres(57);
/*     */       } 
/* 150 */       this.cY = x;
/* 151 */       this.cY = y;
/* 152 */       this.t = 0;
/*     */     } else {
/*     */       
/* 155 */       if ((((this.dX > this.dY) ? 1 : 0) & ((this.dX > this.d) ? 1 : 0) & ((this.dY <= this.d / 2) ? 1 : 0)) != 0) {
/*     */         
/* 157 */         if (this.cX > x) {
/*     */           
/* 159 */           keyPres(52);
/*     */         }
/* 161 */         else if (this.cX < x) {
/*     */           
/* 163 */           keyPres(54);
/*     */         } 
/* 165 */         this.cX = x;
/* 166 */         this.cY = y;
/* 167 */         this.t = 0;
/*     */       } 
/* 169 */       if ((((this.dX < this.dY) ? 1 : 0) & ((this.dY > this.d) ? 1 : 0) & ((this.dX <= this.d / 2) ? 1 : 0)) != 0) {
/*     */         
/* 171 */         if (this.cY > y) {
/*     */           
/* 173 */           keyPres(50);
/*     */         }
/* 175 */         else if (this.cY < y) {
/*     */           
/* 177 */           keyPres(56);
/*     */         } 
/* 179 */         this.cX = x;
/* 180 */         this.cY = y;
/* 181 */         this.t = 0;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void pointerPressed(int x, int y) {
/* 188 */     int screenW = getWidth();
/* 189 */     int screenH = getHeight();
/* 190 */     if (y > screenH / 7 * 6) {
/*     */       
/* 192 */       if (x < screenW / 3) {
/*     */         
/* 194 */         KEYPRESSED(this.CodeTo[0]);
/*     */       }
/* 196 */       else if (x < screenW / 3 * 2) {
/*     */         
/* 198 */         KEYPRESSED(48);
/*     */       } else {
/*     */         
/* 201 */         KEYPRESSED(this.CodeTo[1]);
/*     */       } 
/*     */     } else {
/*     */       
/* 205 */       this.t = 1;
/* 206 */       this.cX = x;
/* 207 */       this.cY = y;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void pointerReleased(int x, int y) {
/* 213 */     int screenW = getWidth();
/* 214 */     int screenH = getHeight();
/* 215 */     if (this.key != 0) {
/*     */       
/* 217 */       KEYRELEASED(this.key);
/* 218 */       this.key = 0;
/*     */     } 
/* 220 */     if (y > screenH / 7 * 6) {
/*     */       
/* 222 */       if (x < screenW / 3) {
/*     */         
/* 224 */         KEYRELEASED(this.CodeTo[0]);
/*     */       }
/* 226 */       else if (x < screenW / 3 * 2) {
/*     */         
/* 228 */         KEYRELEASED(48);
/*     */       } else {
/*     */         
/* 231 */         KEYRELEASED(this.CodeTo[1]);
/*     */       } 
/*     */     } else {
/*     */       
/* 235 */       this.dX = this.cX - x;
/* 236 */       this.dY = this.cY - y;
/* 237 */       if ((((mod(this.dX) <= 2) ? 1 : 0) & ((mod(this.dY) <= 3) ? 1 : 0) & ((this.t == 1) ? 1 : 0)) != 0)
/*     */       {
/* 239 */         keyPres(this.Pres);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getGameAction(int i) {
/* 247 */     boolean flag = false;
/* 248 */     for (int k = 0; k < this.n; k++) {
/*     */       
/* 250 */       if (this.CodeTo[k] == i) {
/*     */ 
/*     */ 
/*     */         
/* 254 */         flag = true;
/* 255 */         int j = super.getGameAction(this.CodeFrom[k]);
/* 256 */         if (j != 0)
/*     */         {
/* 258 */           return j;
/*     */         }
/*     */       } 
/*     */     } 
/* 262 */     return flag ? 0 : super.getGameAction(i);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getKeyCode(int i) {
/* 267 */     return (this.codes[i] == 0) ? super.getKeyCode(i) : this.codes[i];
/*     */   }
/*     */ 
/*     */   
/*     */   public String getKeyName(int i) {
/* 272 */     for (int j = 0; j < this.n; j++) {
/*     */       
/* 274 */       if (this.CodeTo[j] == i)
/*     */       {
/* 276 */         return super.getKeyName(this.CodeFrom[j]);
/*     */       }
/*     */     } 
/*     */     
/* 280 */     return super.getKeyName(i);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getWidth() {
/* 285 */     return 240;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getHeight() {
/* 290 */     return 400;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void sizeChanged(int i, int j) {
/* 295 */     setFullScreenMode(this.setFullScreen);
/*     */   }
/*     */ }


/* Location:              C:\Users\sora\Desktop\Third_World_War_of_Kings_2D.jar!\com\hellomoto\fullscreen\FullCn.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */