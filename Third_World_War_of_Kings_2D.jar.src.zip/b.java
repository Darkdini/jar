import com.fenix.main.a;
import com.fenix.main.b;
import com.fenix.main.c;
import com.fenix.main.h;
import com.fenix.main.i;
import javax.microedition.lcdui.Graphics;

public final class b extends ah implements a {
  private static b f;
  
  public int a = 1;
  
  public int b = 1;
  
  public int c = 1;
  
  private int g = 1;
  
  public int d = 1;
  
  public static b a() {
    if (f == null)
      f = new b(); 
    return f;
  }
  
  private b() {
    this.d = h.d.getHeight();
    this.c = h.d.stringWidth(r.a().a(r.a[3])) + 15;
    this.g = 8 * (this.d + 2) + 10;
    this.a = i.a - this.c;
    this.b = i.b / 2 - this.g / 2;
    b b1 = this;
    for (byte b2 = 0; b2 < 8; b2++) {
      byte b3 = b2;
      String str = r.a().a(r.a[b3]);
      ae ae1;
      ae ae2;
      (ae1 = ae2 = new ae()).a = str;
      (ae1 = ae2).a(b1.a + b1.c - h.d.stringWidth(r.a().a(r.a[b2])) - 5, b1.b + 2 + b2 * (b1.d + 2));
      ae1.b = 0;
      b1.a(ae1);
    } 
    b1.b(0);
    a(this);
  }
  
  public final void a(Graphics paramGraphics) {
    int i = paramGraphics.getClipX();
    int j = paramGraphics.getClipY();
    int k = paramGraphics.getClipWidth();
    int m = paramGraphics.getClipHeight();
    int n = c.k.getHeight();
    int i1 = c.k.getWidth();
    int i2 = (this.g + 8 - 5) / n + 1;
    int i3 = (this.c + 8 - 6) / i1 + 1;
    paramGraphics.setClip(this.a - 4, this.b - 4, this.c + 8, this.g + 8);
    byte b1;
    for (b1 = 0; b1 < i2; b1++) {
      for (byte b2 = 0; b2 < i3; b2++)
        paramGraphics.drawImage(c.k, this.a - 4 + b2 * i1, this.b - 4 + b1 * n, 0); 
    } 
    paramGraphics.setClip(i, j, k, m);
    paramGraphics.setColor(11642239);
    paramGraphics.drawRect(this.a + 1 - 4, this.b + 1 - 4, this.c + 4, this.g + 5);
    paramGraphics.setColor(14793067);
    paramGraphics.drawRect(this.a + 3 - 4, this.b + 3 - 4, this.c + 4, this.g + 1);
    paramGraphics.setColor(0);
    paramGraphics.drawRect(this.a + 4 - 4, this.b + 4 - 4, this.c + 4, this.g - 1);
    for (b1 = 0; b1 < this.e.size(); b1++) {
      ((ae)this.e.elementAt(b1)).a(paramGraphics);
      if (b1 == 2 || b1 == 3) {
        paramGraphics.setColor(16777215);
        i = 0;
        k = this.b + 3 + b1 * (this.d + 2);
        j = this.a + 5;
        Graphics graphics;
        (graphics = paramGraphics).drawLine(j + 3, k + 1, j + 3, k + 7);
        graphics.drawLine(j + 2, k + 2, j + 2, k + 6);
        graphics.drawLine(j + 1, k + 3, j + 1, k + 5);
        graphics.drawLine(j, k + 4, j, k + 4);
      } 
    } 
  }
  
  public final void a(int paramInt) {
    switch (paramInt) {
      case 8:
      case 65536:
        c();
        return;
      case 16:
      case 131072:
        d();
        return;
      case 32:
      case 8192:
      case 524288:
        c(b());
        return;
      case 2:
      case 262144:
        if (b() == 2)
          c(2); 
        if (b() == 3) {
          c(3);
          return;
        } 
        break;
      case 4096:
        b.a().a(k.a());
        break;
    } 
  }
  
  private static void c(int paramInt) {
    switch (paramInt) {
      case 0:
        k.a();
        k.a(11, 16, 0, null);
        return;
      case 1:
        System.out.println("Cabinet");
        k.a();
        k.a(11, 18, 0, null);
        return;
      case 2:
        w.a().b(0);
        b.a().a(w.a());
        return;
      case 3:
        ad.a().b(0);
        b.a().a(ad.a());
        return;
      case 4:
        k.a();
        k.a(11, 17, 0, null);
        return;
      case 5:
        System.out.println("?");
        k.a().c();
        return;
      case 6:
        System.out.println("Razvlechenija");
        k.a().d();
        return;
      case 7:
        k.a().b();
        break;
    } 
  }
}


/* Location:              C:\Users\sora\Desktop\Third_World_War_of_Kings_2D.jar!\b.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */