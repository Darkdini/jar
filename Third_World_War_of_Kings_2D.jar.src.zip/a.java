import com.fenix.main.h;
import javax.microedition.lcdui.Graphics;

public final class a extends n {
  public v a;
  
  private h b = new h();
  
  private int c = 0;
  
  private boolean d = false;
  
  public a() {
    this.b.f(22);
    this.a = new v(1, 6);
    this.a.b("0");
    this.a.a("0");
  }
  
  public final void a(String paramString) {
    this.b.b(paramString);
  }
  
  public final void a(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.a(paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public final void a(int paramInt) {
    super.a(paramInt);
    this.a.a(paramInt);
    this.b.a(paramInt + this.a.m() + 3);
  }
  
  public final void b(int paramInt) {
    super.b(paramInt);
    this.a.b(paramInt);
    this.b.b(paramInt);
  }
  
  public final void c(int paramInt) {
    super.c(paramInt);
    System.out.println("12");
    paramInt = this.a.a();
    System.out.println("13");
    if (paramInt > 10)
      paramInt = 10; 
    paramInt *= h.d.stringWidth("W");
    System.out.println("14");
    System.out.println("14.1");
    this.a.c(paramInt);
    System.out.println("14.2");
    System.out.println("btnMax=" + this.b.j());
    this.b.c(h.d.stringWidth(this.b.j()) + 4);
    System.out.println("Set Widht MAX =" + this.b.m());
  }
  
  public final void d(int paramInt) {
    super.d(paramInt);
    this.a.d(paramInt);
    this.b.d(paramInt);
  }
  
  public final void e(int paramInt) {
    String str;
    int i;
    if (this.c == 1 && this.a.a == 1) {
      this.a.e(paramInt);
      if (this.a.a == 1)
        return; 
    } 
    switch (paramInt) {
      case 4:
      case 16:
      case 32768:
      case 131072:
        (this = this).a.a(false);
        this.b.a(false);
        this.c++;
        if (this.c > 2) {
          this.c = 2;
          this.d = true;
          break;
        } 
        b();
        return;
      case 2:
      case 8:
      case 65536:
      case 262144:
        (this = this).a.a(false);
        this.b.a(false);
        this.c--;
        if (this.c < 0) {
          this.c = 0;
          this.d = true;
          break;
        } 
        b();
        return;
      case 32:
      case 524288:
        if ((str = this.a.b()) == null || str == "" || str.length() == 0 || str.equals("")) {
          i = 0;
        } else {
          i = Integer.parseInt(i);
        } 
        if (this.c == 0) {
          if (--i < 0)
            i = 0; 
          this.a.a(Integer.toString(i));
        } 
        if (this.c == 2)
          try {
            this.a.a(this.b.j());
            return;
          } catch (Exception exception) {
            System.out.println("Ecxeption in incrementBox" + this);
            System.err.println(this);
            break;
          }  
        break;
    } 
  }
  
  public final void a(Graphics paramGraphics) {
    a a1;
    (a1 = this).a(a1.k());
    a1.b(a1.l());
    this.a.a(paramGraphics);
    this.b.a(paramGraphics);
  }
  
  private void b() {
    switch (this.c) {
      case 0:
        return;
      case 1:
        this.a.a(true);
        this.a.a = 1;
        return;
      case 2:
        this.b.a(true);
        break;
    } 
  }
  
  public final void a(boolean paramBoolean) {
    this.d = false;
    super.a(paramBoolean);
    if (paramBoolean != true)
      return; 
    b();
  }
  
  public final boolean a() {
    return this.d;
  }
}


/* Location:              C:\Users\sora\Desktop\Third_World_War_of_Kings_2D.jar!\a.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */