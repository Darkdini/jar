import com.fenix.main.a;
import com.fenix.main.c;
import com.fenix.main.f;
import com.fenix.main.h;
import com.fenix.main.i;
import javax.microedition.lcdui.Graphics;

public final class q extends f implements a {
  private int c = 0;
  
  private int d = 0;
  
  private int e = 15;
  
  private int f = 0;
  
  private int g = 70;
  
  private int h = 70;
  
  private int i;
  
  private int j;
  
  private int k;
  
  private int l;
  
  private int m;
  
  private int n;
  
  private int o;
  
  private int p;
  
  public n[][] a;
  
  private boolean q = false;
  
  private int r = 1;
  
  private long s = 0L;
  
  private int[] t;
  
  private int[] u;
  
  private int v = 5;
  
  private int w = h.d.getHeight() + 2;
  
  private int x = 0;
  
  private int y = 0;
  
  int b = 0;
  
  public q() {
    a(this);
    a(100, 100);
  }
  
  public final void a(int paramInt1, int paramInt2) {
    this.g = paramInt1;
    this.h = paramInt2;
    this.k = i.a * this.g / 100;
    this.l = i.b * this.h / 100;
    this.i = i.a / 2 - this.k / 2;
    this.j = i.b / 2 - this.l / 2;
    this.m = this.i + 5;
    this.n = this.j + 5;
    this.o = this.k - 10 - 10;
    this.p = this.l - 10 - 14;
  }
  
  public final void a(String paramString, n[][] paramArrayOfn) {
    this.a = paramArrayOfn;
    System.currentTimeMillis();
    c();
    System.currentTimeMillis();
    System.currentTimeMillis();
    b(0, 0);
    System.currentTimeMillis();
    int i = this.a.length - 1;
    this.c = this.a[i][0].l() + this.t[i] - this.n - this.p + 10;
    this.f = this.a[0][0].l();
    if (this.b != 5)
      d(); 
  }
  
  public final void a() {
    c();
    int i = this.a.length - 1;
    this.c = this.a[i][0].l() + this.t[i] - this.n - this.p + 10;
    this.f = this.a[0][0].l();
    this.d = 0;
    d();
  }
  
  public final void b() {
    int i = this.a.length - 1;
    if (this.p >= this.a[i][0].l() - this.n) {
      i = (this.j + this.p - this.a[i][0].l() + this.a[i][0].n()) / 2;
      b(0, i);
    } 
    this.f = this.a[0][0].l();
  }
  
  private int a(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    int i = (i = this.m + this.o - this.a[paramInt1][paramInt3 - 1].k() + this.a[paramInt1][paramInt3 - 1].m() + this.v) / (paramInt3 - paramInt2);
    int j;
    for (j = paramInt2; j <= paramInt3 - 1; j++) {
      int m = 0;
      int i1 = 0;
      switch (this.a[paramInt1][j].o()) {
        case 0:
          m = 0;
          break;
        case 1:
          m = i / 2;
          break;
        case 2:
          m = i;
          break;
      } 
      switch (this.a[paramInt1][j].p()) {
        case 0:
          i1 = 0;
          break;
        case 1:
          i1 = paramInt4 / 2 - this.a[paramInt1][j].n() / 2;
          break;
        case 2:
          i1 = paramInt4 - this.a[paramInt1][j].n();
          break;
      } 
      int i2;
      if (this.a[paramInt1][j] instanceof m && (i2 = paramInt3 - paramInt2) == 1) {
        this.a[paramInt1][j].a(this.m + this.v);
        this.a[paramInt1][j].c(this.o - 2 * this.v);
        ((m)this.a[paramInt1][j]).a();
        break;
      } 
      this.a[paramInt1][j].a(this.a[paramInt1][j].k() + i * (j - paramInt2) + m);
      this.a[paramInt1][j].b(this.a[paramInt1][j].l() + i1);
    } 
    j = 0;
    for (int k = paramInt2; k <= paramInt3 - 1; k++) {
      if (j < this.a[paramInt1][k].n())
        j = this.a[paramInt1][k].n(); 
    } 
    return j;
  }
  
  private void c() {
    try {
      this.t = new int[this.a.length];
      this.u = new int[this.a.length];
      for (byte b = 0; b < this.t.length; b++) {
        int i = this.m + this.v;
        if (b == 0) {
          this.u[b] = this.n;
        } else {
          this.u[b] = this.u[b - 1] + this.t[b - 1];
        } 
        int j = this.u[b] + this.v;
        int k = 0;
        int m = this.v;
        byte b1 = 0;
        for (byte b2 = 0; b2 < (this.a[b]).length; b2++) {
          int i1 = 0;
          if (this.a[b][b2] instanceof j) {
            if ((this.a[b]).length > 1)
              System.out.println("Все пипец"); 
            if (((j)this.a[b][b2]).a() == 0) {
              i1 = this.o - 2 * this.v;
              this.a[b][b2].c(i1);
              this.a[b][b2].d(14);
            } else if (((j)this.a[b][b2]).a() == 1) {
              i1 = this.o - 2 * this.v;
              this.a[b][b2].c(i1);
              this.a[b][b2].d(6);
            } 
          } else if (this.a[b][b2] instanceof a) {
            a a1;
            int i2;
            if ((i2 = (a1 = (a)this.a[b][b2]).a.a()) > 10)
              i2 = 10; 
            i2 = (i2 *= h.d.stringWidth("W")) + 36;
            ((a)this.a[b][b2]).c(i2);
            ((a)this.a[b][b2]).d(this.w);
          } else if (this.a[b][b2] instanceof v) {
            if ((i1 = ((v)this.a[b][b2]).a()) > 10 && (this.a[b]).length != 1)
              i1 = 10; 
            if ((i1 *= h.d.stringWidth("W")) > this.o - 2 * this.v)
              i1 = this.o - 2 * this.v - 2; 
            this.a[b][b2].c(i1);
            this.a[b][b2].d(this.w);
          } else if (this.a[b][b2] instanceof e) {
            this.a[b][b2].d(12);
            e e;
            int i2 = (i2 = (e = (e)this.a[b][b2]).n() + 5 + h.d.stringWidth(e.j())) + 5;
            this.a[b][b2].c(i2);
          } else if (this.a[b][b2] instanceof t) {
            if ((i1 = h.d.stringWidth(((t)this.a[b][b2]).j())) > this.o - 2 * this.v)
              i1 = this.o - 2 * this.v - 2; 
            this.a[b][b2].c(i1);
            this.a[b][b2].d(h.d.getHeight());
          } else if (this.a[b][b2] instanceof h) {
            if ((i1 = h.d.stringWidth(((h)this.a[b][b2]).j()) + 6) > this.o - 2 * this.v)
              i1 = this.o - 2 * this.v - 2; 
            if (i1 < h.d.getHeight() + 4)
              i1 = h.d.getHeight() + 4; 
            this.a[b][b2].c(i1);
            this.a[b][b2].d(h.d.getHeight() + 4);
          } else if (this.a[b][b2] instanceof z) {
            i1 = ((z)this.a[b][b2]).a();
            this.a[b][b2].c(i1);
            this.a[b][b2].d(((z)this.a[b][b2]).b());
          } else if (this.a[b][b2] instanceof m) {
            if ((this.a[b]).length > 2) {
              System.out.println("Все пипец");
            } else if ((this.a[b]).length == 1) {
              i1 = this.o - 2 * this.v;
            } else if ((this.a[b]).length == 2) {
              i1 = this.o / 2 - 3 * this.v;
            } 
            this.a[b][b2].c(i1);
            ((m)this.a[b][b2]).a();
          } else if (this.a[b][b2] instanceof af) {
            if ((this.a[b]).length > 2)
              System.out.println("Все пипец"); 
            if ((this.a[b]).length == 1)
              i1 = this.o - 2 * this.v; 
            if ((this.a[b]).length == 2)
              i1 = this.o / 2 - 3 * this.v; 
            this.a[b][b2].c(i1);
            this.a[b][b2].d(54);
            ((af)this.a[b][b2]).a();
          } else if (this.a[b][b2] instanceof aa) {
            if ((i1 = ((aa)this.a[b][b2]).b()) < 50)
              i1 = 50; 
            if (i1 > this.o - 2 * this.v)
              i1 = this.o - 2 * this.v - 2; 
            this.a[b][b2].c(i1);
            this.a[b][b2].d(this.w);
          } 
          this.a[b][b2].a(i);
          this.a[b][b2].b(j);
          i += i1 + this.v;
          if ((this.a[b]).length > 1 && i > this.m + this.o) {
            k = a(b, b1, b2, k);
            b1 = b2;
            i = this.m + this.v;
            j += k + this.v;
            this.a[b][b2].a(i);
            i += i1 + this.v;
            this.a[b][b2].b(j);
            m += k + this.v;
            k = 0;
          } 
          if (k < this.a[b][b2].n())
            k = this.a[b][b2].n(); 
        } 
        k = a(b, b1, (this.a[b]).length, k);
        this.t[b] = m + k;
      } 
      return;
    } catch (Exception exception) {
      System.err.print("DesignConstructor.calcSize " + exception);
      exception.printStackTrace();
      return;
    } 
  }
  
  private boolean d() {
    boolean bool = false;
    byte b = -1;
    byte b1 = 0;
    while (true) {
      if (++b >= (this.a[b1]).length)
        if (b1 < this.a.length - 1) {
          b1++;
          b = 0;
        } else {
          break;
        }  
      if (this.a[b1][b].f()) {
        if (this.a[b1][b].h()) {
          this.x = b1;
          this.y = b;
          bool = true;
          break;
        } 
        if (this.a[b1][b] instanceof m && this.a[b1][b].g() && ((m)this.a[b1][b]).a(this.n, this.p)) {
          this.x = b1;
          this.y = b;
          bool = true;
          break;
        } 
      } 
    } 
    for (b = 0; b < this.a.length; b++) {
      for (b1 = 0; b1 < (this.a[b]).length; b1++)
        this.a[b][b1].a(false); 
    } 
    this.a[this.x][this.y].a(true);
    if (this.a[this.x][this.y] instanceof v) {
      ((v)this.a[this.x][this.y]).a = 1;
      this.q = true;
    } 
    return bool;
  }
  
  private void b(int paramInt1, int paramInt2) {
    for (paramInt1 = 0; paramInt1 < this.a.length; paramInt1++) {
      for (byte b = 0; b < (this.a[paramInt1]).length; b++) {
        this.a[paramInt1][b].b(0, paramInt2);
        this.a[paramInt1][b].d(true);
        if (this.a[paramInt1][b].l() + this.a[paramInt1][b].n() < this.n)
          this.a[paramInt1][b].d(false); 
        if (this.a[paramInt1][b].l() > this.n + this.p)
          this.a[paramInt1][b].d(false); 
        this.a[paramInt1][b].e(true);
        if (this.a[paramInt1][b].l() < this.n)
          this.a[paramInt1][b].e(false); 
        if (this.a[paramInt1][b].l() + this.a[paramInt1][b].n() > this.n + this.p)
          this.a[paramInt1][b].e(false); 
      } 
    } 
  }
  
  public final void b(int paramInt) {
    this.b = paramInt;
  }
  
  public final void a(int paramInt) {
    // Byte code:
    //   0: iload_1
    //   1: sipush #4096
    //   4: if_icmpne -> 92
    //   7: getstatic k.a : Z
    //   10: ifne -> 91
    //   13: getstatic k.b : Z
    //   16: ifne -> 91
    //   19: aload_0
    //   20: getfield b : I
    //   23: iconst_5
    //   24: if_icmpne -> 34
    //   27: invokestatic a : ()Lcom/fenix/main/Main;
    //   30: invokevirtual c : ()V
    //   33: return
    //   34: aload_0
    //   35: getfield b : I
    //   38: iconst_2
    //   39: if_icmpeq -> 49
    //   42: aload_0
    //   43: getfield b : I
    //   46: ifne -> 57
    //   49: invokestatic a : ()Lk;
    //   52: iconst_2
    //   53: invokevirtual d : (I)V
    //   56: return
    //   57: aload_0
    //   58: getfield b : I
    //   61: iconst_1
    //   62: if_icmpne -> 91
    //   65: aload_0
    //   66: getfield q : Z
    //   69: iconst_1
    //   70: if_icmpne -> 84
    //   73: invokestatic a : ()Lk;
    //   76: aload_0
    //   77: getfield b : I
    //   80: invokevirtual d : (I)V
    //   83: return
    //   84: invokestatic a : ()Lk;
    //   87: iconst_2
    //   88: invokevirtual d : (I)V
    //   91: return
    //   92: aload_0
    //   93: iconst_0
    //   94: putfield q : Z
    //   97: aload_0
    //   98: getfield a : [[Ln;
    //   101: aload_0
    //   102: getfield x : I
    //   105: aaload
    //   106: aload_0
    //   107: getfield y : I
    //   110: aaload
    //   111: instanceof m
    //   114: ifeq -> 177
    //   117: aload_0
    //   118: getfield a : [[Ln;
    //   121: aload_0
    //   122: getfield x : I
    //   125: aaload
    //   126: aload_0
    //   127: getfield y : I
    //   130: aaload
    //   131: checkcast m
    //   134: iload_1
    //   135: aload_0
    //   136: getfield n : I
    //   139: aload_0
    //   140: getfield p : I
    //   143: invokevirtual a : (III)V
    //   146: aload_0
    //   147: getfield a : [[Ln;
    //   150: aload_0
    //   151: getfield x : I
    //   154: aaload
    //   155: aload_0
    //   156: getfield y : I
    //   159: aaload
    //   160: checkcast m
    //   163: invokevirtual b : ()Z
    //   166: ifne -> 177
    //   169: iload_1
    //   170: sipush #8192
    //   173: if_icmpeq -> 177
    //   176: return
    //   177: aload_0
    //   178: getfield a : [[Ln;
    //   181: aload_0
    //   182: getfield x : I
    //   185: aaload
    //   186: aload_0
    //   187: getfield y : I
    //   190: aaload
    //   191: instanceof v
    //   194: ifeq -> 272
    //   197: aload_0
    //   198: getfield a : [[Ln;
    //   201: aload_0
    //   202: getfield x : I
    //   205: aaload
    //   206: aload_0
    //   207: getfield y : I
    //   210: aaload
    //   211: checkcast v
    //   214: getfield a : I
    //   217: iconst_1
    //   218: if_icmpne -> 272
    //   221: aload_0
    //   222: getfield a : [[Ln;
    //   225: aload_0
    //   226: getfield x : I
    //   229: aaload
    //   230: aload_0
    //   231: getfield y : I
    //   234: aaload
    //   235: checkcast v
    //   238: iload_1
    //   239: invokevirtual e : (I)V
    //   242: aload_0
    //   243: getfield a : [[Ln;
    //   246: aload_0
    //   247: getfield x : I
    //   250: aaload
    //   251: aload_0
    //   252: getfield y : I
    //   255: aaload
    //   256: checkcast v
    //   259: getfield a : I
    //   262: iconst_1
    //   263: if_icmpne -> 272
    //   266: aload_0
    //   267: iconst_1
    //   268: putfield q : Z
    //   271: return
    //   272: aload_0
    //   273: getfield a : [[Ln;
    //   276: aload_0
    //   277: getfield x : I
    //   280: aaload
    //   281: aload_0
    //   282: getfield y : I
    //   285: aaload
    //   286: instanceof af
    //   289: ifeq -> 344
    //   292: aload_0
    //   293: getfield a : [[Ln;
    //   296: aload_0
    //   297: getfield x : I
    //   300: aaload
    //   301: aload_0
    //   302: getfield y : I
    //   305: aaload
    //   306: checkcast af
    //   309: iload_1
    //   310: invokevirtual e : (I)V
    //   313: aload_0
    //   314: getfield a : [[Ln;
    //   317: aload_0
    //   318: getfield x : I
    //   321: aaload
    //   322: aload_0
    //   323: getfield y : I
    //   326: aaload
    //   327: checkcast af
    //   330: invokevirtual c : ()Z
    //   333: ifne -> 344
    //   336: iload_1
    //   337: sipush #8192
    //   340: if_icmpeq -> 344
    //   343: return
    //   344: aload_0
    //   345: getfield a : [[Ln;
    //   348: aload_0
    //   349: getfield x : I
    //   352: aaload
    //   353: aload_0
    //   354: getfield y : I
    //   357: aaload
    //   358: instanceof aa
    //   361: ifeq -> 410
    //   364: aload_0
    //   365: getfield a : [[Ln;
    //   368: aload_0
    //   369: getfield x : I
    //   372: aaload
    //   373: aload_0
    //   374: getfield y : I
    //   377: aaload
    //   378: checkcast aa
    //   381: getfield a : I
    //   384: iconst_1
    //   385: if_icmpne -> 410
    //   388: aload_0
    //   389: getfield a : [[Ln;
    //   392: aload_0
    //   393: getfield x : I
    //   396: aaload
    //   397: aload_0
    //   398: getfield y : I
    //   401: aaload
    //   402: checkcast aa
    //   405: iload_1
    //   406: invokevirtual e : (I)V
    //   409: return
    //   410: aload_0
    //   411: getfield a : [[Ln;
    //   414: aload_0
    //   415: getfield x : I
    //   418: aaload
    //   419: aload_0
    //   420: getfield y : I
    //   423: aaload
    //   424: instanceof a
    //   427: ifeq -> 515
    //   430: aload_0
    //   431: getfield a : [[Ln;
    //   434: aload_0
    //   435: getfield x : I
    //   438: aaload
    //   439: aload_0
    //   440: getfield y : I
    //   443: aaload
    //   444: checkcast a
    //   447: iload_1
    //   448: invokevirtual e : (I)V
    //   451: aload_0
    //   452: getfield a : [[Ln;
    //   455: aload_0
    //   456: getfield x : I
    //   459: aaload
    //   460: aload_0
    //   461: getfield y : I
    //   464: aaload
    //   465: checkcast a
    //   468: getfield a : Lv;
    //   471: getfield a : I
    //   474: iconst_1
    //   475: if_icmpne -> 484
    //   478: aload_0
    //   479: iconst_1
    //   480: putfield q : Z
    //   483: return
    //   484: aload_0
    //   485: getfield a : [[Ln;
    //   488: aload_0
    //   489: getfield x : I
    //   492: aaload
    //   493: aload_0
    //   494: getfield y : I
    //   497: aaload
    //   498: checkcast a
    //   501: invokevirtual a : ()Z
    //   504: ifne -> 515
    //   507: iload_1
    //   508: sipush #8192
    //   511: if_icmpeq -> 515
    //   514: return
    //   515: iload_1
    //   516: lookupswitch default -> 3273, 2 -> 1127, 4 -> 661, 8 -> 1127, 16 -> 661, 32 -> 1542, 1024 -> 643, 8192 -> 632, 16384 -> 644, 32768 -> 661, 65536 -> 1127, 131072 -> 661, 262144 -> 1127, 524288 -> 1542
    //   632: invokestatic a : ()Lk;
    //   635: aload_0
    //   636: getfield b : I
    //   639: invokevirtual d : (I)V
    //   642: return
    //   643: return
    //   644: invokestatic a : ()Lag;
    //   647: invokevirtual d : ()I
    //   650: iconst_2
    //   651: if_icmpne -> 3273
    //   654: invokestatic a : ()Lk;
    //   657: invokevirtual e : ()V
    //   660: return
    //   661: aload_0
    //   662: dup
    //   663: astore_1
    //   664: astore #4
    //   666: iconst_0
    //   667: istore #5
    //   669: aload #4
    //   671: iconst_0
    //   672: putfield q : Z
    //   675: aload #4
    //   677: getfield y : I
    //   680: istore #6
    //   682: aload #4
    //   684: getfield x : I
    //   687: istore #7
    //   689: iinc #6, 1
    //   692: iload #6
    //   694: aload #4
    //   696: getfield a : [[Ln;
    //   699: iload #7
    //   701: aaload
    //   702: arraylength
    //   703: if_icmplt -> 725
    //   706: iload #7
    //   708: aload #4
    //   710: getfield a : [[Ln;
    //   713: arraylength
    //   714: iconst_1
    //   715: isub
    //   716: if_icmpge -> 860
    //   719: iinc #7, 1
    //   722: iconst_0
    //   723: istore #6
    //   725: aload #4
    //   727: getfield a : [[Ln;
    //   730: iload #7
    //   732: aaload
    //   733: iload #6
    //   735: aaload
    //   736: invokevirtual f : ()Z
    //   739: ifeq -> 689
    //   742: aload #4
    //   744: getfield a : [[Ln;
    //   747: iload #7
    //   749: aaload
    //   750: iload #6
    //   752: aaload
    //   753: invokevirtual h : ()Z
    //   756: ifeq -> 779
    //   759: aload #4
    //   761: iload #7
    //   763: putfield x : I
    //   766: aload #4
    //   768: iload #6
    //   770: putfield y : I
    //   773: iconst_1
    //   774: istore #5
    //   776: goto -> 860
    //   779: aload #4
    //   781: getfield a : [[Ln;
    //   784: iload #7
    //   786: aaload
    //   787: iload #6
    //   789: aaload
    //   790: instanceof m
    //   793: ifeq -> 689
    //   796: aload #4
    //   798: getfield a : [[Ln;
    //   801: iload #7
    //   803: aaload
    //   804: iload #6
    //   806: aaload
    //   807: invokevirtual g : ()Z
    //   810: ifeq -> 689
    //   813: aload #4
    //   815: getfield a : [[Ln;
    //   818: iload #7
    //   820: aaload
    //   821: iload #6
    //   823: aaload
    //   824: checkcast m
    //   827: aload #4
    //   829: getfield n : I
    //   832: aload #4
    //   834: getfield p : I
    //   837: invokevirtual a : (II)Z
    //   840: ifeq -> 689
    //   843: aload #4
    //   845: iload #7
    //   847: putfield x : I
    //   850: aload #4
    //   852: iload #6
    //   854: putfield y : I
    //   857: iconst_1
    //   858: istore #5
    //   860: iconst_0
    //   861: istore_0
    //   862: iload_0
    //   863: aload #4
    //   865: getfield a : [[Ln;
    //   868: arraylength
    //   869: if_icmpge -> 914
    //   872: iconst_0
    //   873: istore #8
    //   875: iload #8
    //   877: aload #4
    //   879: getfield a : [[Ln;
    //   882: iload_0
    //   883: aaload
    //   884: arraylength
    //   885: if_icmpge -> 908
    //   888: aload #4
    //   890: getfield a : [[Ln;
    //   893: iload_0
    //   894: aaload
    //   895: iload #8
    //   897: aaload
    //   898: iconst_0
    //   899: invokevirtual a : (Z)V
    //   902: iinc #8, 1
    //   905: goto -> 875
    //   908: iinc #0, 1
    //   911: goto -> 862
    //   914: aload #4
    //   916: getfield a : [[Ln;
    //   919: aload #4
    //   921: getfield x : I
    //   924: aaload
    //   925: aload #4
    //   927: getfield y : I
    //   930: aaload
    //   931: iconst_1
    //   932: invokevirtual a : (Z)V
    //   935: aload #4
    //   937: getfield a : [[Ln;
    //   940: aload #4
    //   942: getfield x : I
    //   945: aaload
    //   946: aload #4
    //   948: getfield y : I
    //   951: aaload
    //   952: instanceof v
    //   955: ifeq -> 1036
    //   958: aload #4
    //   960: getfield a : [[Ln;
    //   963: aload #4
    //   965: getfield x : I
    //   968: aaload
    //   969: aload #4
    //   971: getfield y : I
    //   974: aaload
    //   975: checkcast v
    //   978: iconst_1
    //   979: putfield a : I
    //   982: aload #4
    //   984: getfield a : [[Ln;
    //   987: aload #4
    //   989: getfield x : I
    //   992: aaload
    //   993: aload #4
    //   995: getfield y : I
    //   998: aaload
    //   999: checkcast v
    //   1002: invokevirtual b : ()Ljava/lang/String;
    //   1005: ldc 'Login'
    //   1007: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1010: ifeq -> 1030
    //   1013: aload #4
    //   1015: getfield b : I
    //   1018: iconst_5
    //   1019: if_icmpne -> 1030
    //   1022: getstatic java/lang/System.out : Ljava/io/PrintStream;
    //   1025: ldc 'Login!!'
    //   1027: invokevirtual println : (Ljava/lang/String;)V
    //   1030: aload #4
    //   1032: iconst_1
    //   1033: putfield q : Z
    //   1036: iload #5
    //   1038: ifne -> 1126
    //   1041: aload_1
    //   1042: dup
    //   1043: getfield d : I
    //   1046: aload_1
    //   1047: getfield e : I
    //   1050: iadd
    //   1051: putfield d : I
    //   1054: aload_1
    //   1055: getfield d : I
    //   1058: aload_1
    //   1059: getfield c : I
    //   1062: iconst_5
    //   1063: iadd
    //   1064: if_icmple -> 1080
    //   1067: iconst_0
    //   1068: istore_3
    //   1069: aload_1
    //   1070: aload_1
    //   1071: getfield c : I
    //   1074: putfield d : I
    //   1077: goto -> 1119
    //   1080: aload_1
    //   1081: getfield d : I
    //   1084: aload_1
    //   1085: getfield c : I
    //   1088: if_icmple -> 1114
    //   1091: aload_1
    //   1092: getfield d : I
    //   1095: aload_1
    //   1096: getfield c : I
    //   1099: isub
    //   1100: istore_3
    //   1101: aload_1
    //   1102: aload_1
    //   1103: getfield c : I
    //   1106: iload_3
    //   1107: isub
    //   1108: putfield d : I
    //   1111: goto -> 1119
    //   1114: aload_1
    //   1115: getfield e : I
    //   1118: istore_3
    //   1119: aload_1
    //   1120: iconst_0
    //   1121: iload_3
    //   1122: ineg
    //   1123: invokespecial b : (II)V
    //   1126: return
    //   1127: aload_0
    //   1128: dup
    //   1129: astore_1
    //   1130: astore #4
    //   1132: iconst_0
    //   1133: istore #5
    //   1135: aload #4
    //   1137: iconst_0
    //   1138: putfield q : Z
    //   1141: aload #4
    //   1143: getfield y : I
    //   1146: istore #6
    //   1148: aload #4
    //   1150: getfield x : I
    //   1153: istore #7
    //   1155: iinc #6, -1
    //   1158: iload #6
    //   1160: ifge -> 1184
    //   1163: iload #7
    //   1165: ifle -> 1319
    //   1168: iinc #7, -1
    //   1171: aload #4
    //   1173: getfield a : [[Ln;
    //   1176: iload #7
    //   1178: aaload
    //   1179: arraylength
    //   1180: iconst_1
    //   1181: isub
    //   1182: istore #6
    //   1184: aload #4
    //   1186: getfield a : [[Ln;
    //   1189: iload #7
    //   1191: aaload
    //   1192: iload #6
    //   1194: aaload
    //   1195: invokevirtual f : ()Z
    //   1198: ifeq -> 1155
    //   1201: aload #4
    //   1203: getfield a : [[Ln;
    //   1206: iload #7
    //   1208: aaload
    //   1209: iload #6
    //   1211: aaload
    //   1212: invokevirtual h : ()Z
    //   1215: ifeq -> 1238
    //   1218: aload #4
    //   1220: iload #7
    //   1222: putfield x : I
    //   1225: aload #4
    //   1227: iload #6
    //   1229: putfield y : I
    //   1232: iconst_1
    //   1233: istore #5
    //   1235: goto -> 1319
    //   1238: aload #4
    //   1240: getfield a : [[Ln;
    //   1243: iload #7
    //   1245: aaload
    //   1246: iload #6
    //   1248: aaload
    //   1249: instanceof m
    //   1252: ifeq -> 1155
    //   1255: aload #4
    //   1257: getfield a : [[Ln;
    //   1260: iload #7
    //   1262: aaload
    //   1263: iload #6
    //   1265: aaload
    //   1266: invokevirtual g : ()Z
    //   1269: ifeq -> 1155
    //   1272: aload #4
    //   1274: getfield a : [[Ln;
    //   1277: iload #7
    //   1279: aaload
    //   1280: iload #6
    //   1282: aaload
    //   1283: checkcast m
    //   1286: aload #4
    //   1288: getfield n : I
    //   1291: aload #4
    //   1293: getfield p : I
    //   1296: invokevirtual a : (II)Z
    //   1299: ifeq -> 1155
    //   1302: aload #4
    //   1304: iload #7
    //   1306: putfield x : I
    //   1309: aload #4
    //   1311: iload #6
    //   1313: putfield y : I
    //   1316: iconst_1
    //   1317: istore #5
    //   1319: iconst_0
    //   1320: istore_0
    //   1321: iload_0
    //   1322: aload #4
    //   1324: getfield a : [[Ln;
    //   1327: arraylength
    //   1328: if_icmpge -> 1373
    //   1331: iconst_0
    //   1332: istore #8
    //   1334: iload #8
    //   1336: aload #4
    //   1338: getfield a : [[Ln;
    //   1341: iload_0
    //   1342: aaload
    //   1343: arraylength
    //   1344: if_icmpge -> 1367
    //   1347: aload #4
    //   1349: getfield a : [[Ln;
    //   1352: iload_0
    //   1353: aaload
    //   1354: iload #8
    //   1356: aaload
    //   1357: iconst_0
    //   1358: invokevirtual a : (Z)V
    //   1361: iinc #8, 1
    //   1364: goto -> 1334
    //   1367: iinc #0, 1
    //   1370: goto -> 1321
    //   1373: aload #4
    //   1375: getfield a : [[Ln;
    //   1378: aload #4
    //   1380: getfield x : I
    //   1383: aaload
    //   1384: aload #4
    //   1386: getfield y : I
    //   1389: aaload
    //   1390: iconst_1
    //   1391: invokevirtual a : (Z)V
    //   1394: aload #4
    //   1396: getfield a : [[Ln;
    //   1399: aload #4
    //   1401: getfield x : I
    //   1404: aaload
    //   1405: aload #4
    //   1407: getfield y : I
    //   1410: aaload
    //   1411: instanceof v
    //   1414: ifeq -> 1447
    //   1417: aload #4
    //   1419: getfield a : [[Ln;
    //   1422: aload #4
    //   1424: getfield x : I
    //   1427: aaload
    //   1428: aload #4
    //   1430: getfield y : I
    //   1433: aaload
    //   1434: checkcast v
    //   1437: iconst_1
    //   1438: putfield a : I
    //   1441: aload #4
    //   1443: iconst_1
    //   1444: putfield q : Z
    //   1447: iload #5
    //   1449: ifne -> 1541
    //   1452: iconst_0
    //   1453: istore_3
    //   1454: aload_1
    //   1455: dup
    //   1456: getfield d : I
    //   1459: aload_1
    //   1460: getfield e : I
    //   1463: isub
    //   1464: putfield d : I
    //   1467: aload_1
    //   1468: getfield d : I
    //   1471: ifge -> 1530
    //   1474: aload_1
    //   1475: getfield d : I
    //   1478: ifgt -> 1522
    //   1481: aload_1
    //   1482: getfield f : I
    //   1485: aload_1
    //   1486: getfield a : [[Ln;
    //   1489: iconst_0
    //   1490: aaload
    //   1491: iconst_0
    //   1492: aaload
    //   1493: invokevirtual l : ()I
    //   1496: if_icmpeq -> 1522
    //   1499: aload_1
    //   1500: iconst_0
    //   1501: iconst_m1
    //   1502: aload_1
    //   1503: getfield a : [[Ln;
    //   1506: iconst_0
    //   1507: aaload
    //   1508: iconst_0
    //   1509: aaload
    //   1510: invokevirtual l : ()I
    //   1513: aload_1
    //   1514: getfield f : I
    //   1517: isub
    //   1518: imul
    //   1519: invokespecial b : (II)V
    //   1522: aload_1
    //   1523: iconst_0
    //   1524: putfield d : I
    //   1527: goto -> 1535
    //   1530: aload_1
    //   1531: getfield e : I
    //   1534: istore_3
    //   1535: aload_1
    //   1536: iconst_0
    //   1537: iload_3
    //   1538: invokespecial b : (II)V
    //   1541: return
    //   1542: aload_0
    //   1543: getfield a : [[Ln;
    //   1546: aload_0
    //   1547: getfield x : I
    //   1550: aaload
    //   1551: aload_0
    //   1552: getfield y : I
    //   1555: aaload
    //   1556: instanceof aa
    //   1559: ifeq -> 1635
    //   1562: aload_0
    //   1563: getfield a : [[Ln;
    //   1566: aload_0
    //   1567: getfield x : I
    //   1570: aaload
    //   1571: aload_0
    //   1572: getfield y : I
    //   1575: aaload
    //   1576: checkcast aa
    //   1579: getfield a : I
    //   1582: ifne -> 1635
    //   1585: aload_0
    //   1586: getfield a : [[Ln;
    //   1589: aload_0
    //   1590: getfield x : I
    //   1593: aaload
    //   1594: aload_0
    //   1595: getfield y : I
    //   1598: aaload
    //   1599: checkcast aa
    //   1602: iconst_1
    //   1603: putfield a : I
    //   1606: aload_0
    //   1607: getfield a : [[Ln;
    //   1610: aload_0
    //   1611: getfield x : I
    //   1614: aaload
    //   1615: aload_0
    //   1616: getfield y : I
    //   1619: aaload
    //   1620: checkcast aa
    //   1623: aload_0
    //   1624: getfield n : I
    //   1627: aload_0
    //   1628: getfield p : I
    //   1631: invokevirtual a : (II)V
    //   1634: return
    //   1635: aload_0
    //   1636: getfield a : [[Ln;
    //   1639: aload_0
    //   1640: getfield x : I
    //   1643: aaload
    //   1644: aload_0
    //   1645: getfield y : I
    //   1648: aaload
    //   1649: instanceof h
    //   1652: ifeq -> 3233
    //   1655: aload_0
    //   1656: getfield a : [[Ln;
    //   1659: aload_0
    //   1660: getfield x : I
    //   1663: aaload
    //   1664: aload_0
    //   1665: getfield y : I
    //   1668: aaload
    //   1669: checkcast h
    //   1672: dup
    //   1673: astore_2
    //   1674: invokevirtual d : ()I
    //   1677: bipush #22
    //   1679: if_icmpne -> 2138
    //   1682: aload_2
    //   1683: invokevirtual a : ()I
    //   1686: ifne -> 2056
    //   1689: aload_0
    //   1690: aload_2
    //   1691: invokevirtual e : ()[I
    //   1694: astore_3
    //   1695: astore_1
    //   1696: aload_3
    //   1697: ifnonnull -> 1704
    //   1700: aconst_null
    //   1701: goto -> 2032
    //   1704: aload_3
    //   1705: arraylength
    //   1706: anewarray java/lang/String
    //   1709: astore #4
    //   1711: iconst_0
    //   1712: istore #7
    //   1714: iload #7
    //   1716: aload_3
    //   1717: arraylength
    //   1718: if_icmpge -> 2030
    //   1721: ldc ''
    //   1723: astore #5
    //   1725: iconst_0
    //   1726: istore #6
    //   1728: iconst_0
    //   1729: istore #8
    //   1731: iload #8
    //   1733: aload_1
    //   1734: getfield a : [[Ln;
    //   1737: arraylength
    //   1738: if_icmpge -> 2017
    //   1741: iconst_0
    //   1742: istore #9
    //   1744: iload #9
    //   1746: aload_1
    //   1747: getfield a : [[Ln;
    //   1750: iload #8
    //   1752: aaload
    //   1753: arraylength
    //   1754: if_icmpge -> 2006
    //   1757: aload_1
    //   1758: getfield a : [[Ln;
    //   1761: iload #8
    //   1763: aaload
    //   1764: iload #9
    //   1766: aaload
    //   1767: invokevirtual q : ()I
    //   1770: aload_3
    //   1771: iload #7
    //   1773: iaload
    //   1774: if_icmpne -> 2000
    //   1777: aload_1
    //   1778: getfield a : [[Ln;
    //   1781: iload #8
    //   1783: aaload
    //   1784: iload #9
    //   1786: aaload
    //   1787: instanceof v
    //   1790: ifeq -> 1814
    //   1793: aload_1
    //   1794: getfield a : [[Ln;
    //   1797: iload #8
    //   1799: aaload
    //   1800: iload #9
    //   1802: aaload
    //   1803: checkcast v
    //   1806: invokevirtual b : ()Ljava/lang/String;
    //   1809: astore #5
    //   1811: goto -> 1968
    //   1814: aload_1
    //   1815: getfield a : [[Ln;
    //   1818: iload #8
    //   1820: aaload
    //   1821: iload #9
    //   1823: aaload
    //   1824: instanceof af
    //   1827: ifeq -> 1851
    //   1830: aload_1
    //   1831: getfield a : [[Ln;
    //   1834: iload #8
    //   1836: aaload
    //   1837: iload #9
    //   1839: aaload
    //   1840: checkcast af
    //   1843: invokevirtual b : ()Ljava/lang/String;
    //   1846: astore #5
    //   1848: goto -> 1968
    //   1851: aload_1
    //   1852: getfield a : [[Ln;
    //   1855: iload #8
    //   1857: aaload
    //   1858: iload #9
    //   1860: aaload
    //   1861: instanceof aa
    //   1864: ifeq -> 1891
    //   1867: aload_1
    //   1868: getfield a : [[Ln;
    //   1871: iload #8
    //   1873: aaload
    //   1874: iload #9
    //   1876: aaload
    //   1877: checkcast aa
    //   1880: invokevirtual a : ()I
    //   1883: invokestatic toString : (I)Ljava/lang/String;
    //   1886: astore #5
    //   1888: goto -> 1968
    //   1891: aload_1
    //   1892: getfield a : [[Ln;
    //   1895: iload #8
    //   1897: aaload
    //   1898: iload #9
    //   1900: aaload
    //   1901: instanceof a
    //   1904: ifeq -> 1934
    //   1907: aload_1
    //   1908: getfield a : [[Ln;
    //   1911: iload #8
    //   1913: aaload
    //   1914: iload #9
    //   1916: aaload
    //   1917: checkcast a
    //   1920: dup
    //   1921: astore #5
    //   1923: getfield a : Lv;
    //   1926: invokevirtual b : ()Ljava/lang/String;
    //   1929: astore #5
    //   1931: goto -> 1968
    //   1934: aload_1
    //   1935: getfield a : [[Ln;
    //   1938: iload #8
    //   1940: aaload
    //   1941: iload #9
    //   1943: aaload
    //   1944: instanceof e
    //   1947: ifeq -> 1968
    //   1950: aload_1
    //   1951: getfield a : [[Ln;
    //   1954: iload #8
    //   1956: aaload
    //   1957: iload #9
    //   1959: aaload
    //   1960: checkcast e
    //   1963: invokevirtual b : ()Ljava/lang/String;
    //   1966: astore #5
    //   1968: getstatic java/lang/System.out : Ljava/io/PrintStream;
    //   1971: new java/lang/StringBuffer
    //   1974: dup
    //   1975: invokespecial <init> : ()V
    //   1978: ldc 'curV '
    //   1980: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   1983: aload #5
    //   1985: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   1988: invokevirtual toString : ()Ljava/lang/String;
    //   1991: invokevirtual println : (Ljava/lang/String;)V
    //   1994: iconst_1
    //   1995: istore #6
    //   1997: goto -> 2006
    //   2000: iinc #9, 1
    //   2003: goto -> 1744
    //   2006: iload #6
    //   2008: ifne -> 2017
    //   2011: iinc #8, 1
    //   2014: goto -> 1731
    //   2017: aload #4
    //   2019: iload #7
    //   2021: aload #5
    //   2023: aastore
    //   2024: iinc #7, 1
    //   2027: goto -> 1714
    //   2030: aload #4
    //   2032: astore_1
    //   2033: invokestatic a : ()Lk;
    //   2036: aload_2
    //   2037: invokevirtual b : ()I
    //   2040: aload_1
    //   2041: aload_2
    //   2042: invokevirtual e : ()[I
    //   2045: aload_2
    //   2046: invokevirtual c : ()[I
    //   2049: iconst_0
    //   2050: invokevirtual a : (I[Ljava/lang/String;[I[IZ)V
    //   2053: goto -> 3233
    //   2056: aload_2
    //   2057: invokevirtual a : ()I
    //   2060: iconst_1
    //   2061: if_icmpne -> 2087
    //   2064: invokestatic a : ()Lk;
    //   2067: aload_2
    //   2068: invokevirtual b : ()I
    //   2071: aconst_null
    //   2072: aload_2
    //   2073: invokevirtual e : ()[I
    //   2076: aload_2
    //   2077: invokevirtual c : ()[I
    //   2080: iconst_1
    //   2081: invokevirtual a : (I[Ljava/lang/String;[I[IZ)V
    //   2084: goto -> 3233
    //   2087: aload_2
    //   2088: invokevirtual a : ()I
    //   2091: iconst_2
    //   2092: if_icmpne -> 3233
    //   2095: iconst_4
    //   2096: newarray byte
    //   2098: dup
    //   2099: astore_1
    //   2100: iconst_0
    //   2101: aload_2
    //   2102: invokevirtual q : ()I
    //   2105: i2l
    //   2106: invokestatic a : ([BIJ)V
    //   2109: invokestatic a : ()Lk;
    //   2112: pop
    //   2113: aload_2
    //   2114: invokevirtual c : ()[I
    //   2117: iconst_0
    //   2118: iaload
    //   2119: aload_2
    //   2120: invokevirtual c : ()[I
    //   2123: iconst_1
    //   2124: iaload
    //   2125: aload_2
    //   2126: invokevirtual c : ()[I
    //   2129: iconst_2
    //   2130: iaload
    //   2131: aload_1
    //   2132: invokestatic a : (III[B)V
    //   2135: goto -> 3233
    //   2138: aload_2
    //   2139: invokevirtual d : ()I
    //   2142: bipush #27
    //   2144: if_icmpne -> 2157
    //   2147: invokestatic a : ()Lag;
    //   2150: iconst_0
    //   2151: invokevirtual b : (I)V
    //   2154: goto -> 3233
    //   2157: aload_2
    //   2158: invokevirtual d : ()I
    //   2161: bipush #9
    //   2163: if_icmpne -> 2209
    //   2166: aload_0
    //   2167: getfield a : [[Ln;
    //   2170: iconst_1
    //   2171: aaload
    //   2172: iconst_0
    //   2173: aaload
    //   2174: checkcast v
    //   2177: invokevirtual b : ()Ljava/lang/String;
    //   2180: putstatic com/fenix/main/g.a : Ljava/lang/String;
    //   2183: aload_0
    //   2184: getfield a : [[Ln;
    //   2187: iconst_2
    //   2188: aaload
    //   2189: iconst_0
    //   2190: aaload
    //   2191: checkcast v
    //   2194: invokevirtual b : ()Ljava/lang/String;
    //   2197: putstatic com/fenix/main/g.b : Ljava/lang/String;
    //   2200: invokestatic a : ()Lg;
    //   2203: invokevirtual d : ()V
    //   2206: goto -> 3233
    //   2209: aload_2
    //   2210: invokevirtual d : ()I
    //   2213: ifne -> 2226
    //   2216: invokestatic a : ()Lk;
    //   2219: iconst_1
    //   2220: invokevirtual d : (I)V
    //   2223: goto -> 3233
    //   2226: aload_2
    //   2227: invokevirtual d : ()I
    //   2230: bipush #10
    //   2232: if_icmpne -> 3233
    //   2235: bipush #17
    //   2237: anewarray [Ln;
    //   2240: astore_1
    //   2241: iconst_0
    //   2242: istore_2
    //   2243: iload_2
    //   2244: aload_1
    //   2245: arraylength
    //   2246: if_icmpge -> 2262
    //   2249: aload_1
    //   2250: iload_2
    //   2251: iconst_1
    //   2252: anewarray n
    //   2255: aastore
    //   2256: iinc #2, 1
    //   2259: goto -> 2243
    //   2262: aload_1
    //   2263: iconst_0
    //   2264: aaload
    //   2265: iconst_0
    //   2266: new j
    //   2269: dup
    //   2270: invokespecial <init> : ()V
    //   2273: aastore
    //   2274: aload_1
    //   2275: iconst_0
    //   2276: aaload
    //   2277: iconst_0
    //   2278: aaload
    //   2279: checkcast j
    //   2282: iconst_0
    //   2283: invokevirtual e : (I)V
    //   2286: aload_1
    //   2287: iconst_0
    //   2288: aaload
    //   2289: iconst_0
    //   2290: aaload
    //   2291: checkcast j
    //   2294: ldc 'Регистрация'
    //   2296: invokevirtual a : (Ljava/lang/String;)V
    //   2299: aload_1
    //   2300: iconst_1
    //   2301: aaload
    //   2302: iconst_0
    //   2303: new m
    //   2306: dup
    //   2307: invokespecial <init> : ()V
    //   2310: aastore
    //   2311: aload_1
    //   2312: iconst_1
    //   2313: aaload
    //   2314: iconst_0
    //   2315: aaload
    //   2316: checkcast m
    //   2319: ldc 'Имя: {u4|8|0|?}'
    //   2321: invokevirtual a : (Ljava/lang/String;)V
    //   2324: aload_1
    //   2325: iconst_1
    //   2326: aaload
    //   2327: iconst_0
    //   2328: aaload
    //   2329: checkcast m
    //   2332: iconst_1
    //   2333: invokevirtual b : (Z)V
    //   2336: aload_1
    //   2337: iconst_1
    //   2338: aaload
    //   2339: iconst_0
    //   2340: aaload
    //   2341: iconst_1
    //   2342: invokevirtual g : (I)V
    //   2345: aload_1
    //   2346: iconst_1
    //   2347: aaload
    //   2348: iconst_0
    //   2349: aaload
    //   2350: iconst_1
    //   2351: invokevirtual h : (I)V
    //   2354: aload_1
    //   2355: iconst_2
    //   2356: aaload
    //   2357: iconst_0
    //   2358: new v
    //   2361: dup
    //   2362: iconst_5
    //   2363: bipush #10
    //   2365: invokespecial <init> : (II)V
    //   2368: aastore
    //   2369: aload_1
    //   2370: iconst_2
    //   2371: aaload
    //   2372: iconst_0
    //   2373: aaload
    //   2374: iconst_1
    //   2375: invokevirtual i : (I)V
    //   2378: aload_1
    //   2379: iconst_2
    //   2380: aaload
    //   2381: iconst_0
    //   2382: aaload
    //   2383: iconst_1
    //   2384: invokevirtual g : (I)V
    //   2387: aload_1
    //   2388: iconst_2
    //   2389: aaload
    //   2390: iconst_0
    //   2391: aaload
    //   2392: iconst_1
    //   2393: invokevirtual h : (I)V
    //   2396: aload_1
    //   2397: iconst_3
    //   2398: aaload
    //   2399: iconst_0
    //   2400: new m
    //   2403: dup
    //   2404: invokespecial <init> : ()V
    //   2407: aastore
    //   2408: aload_1
    //   2409: iconst_3
    //   2410: aaload
    //   2411: iconst_0
    //   2412: aaload
    //   2413: checkcast m
    //   2416: ldc 'Пароль: {u4|8|1|?}'
    //   2418: invokevirtual a : (Ljava/lang/String;)V
    //   2421: aload_1
    //   2422: iconst_3
    //   2423: aaload
    //   2424: iconst_0
    //   2425: aaload
    //   2426: checkcast m
    //   2429: iconst_1
    //   2430: invokevirtual b : (Z)V
    //   2433: aload_1
    //   2434: iconst_3
    //   2435: aaload
    //   2436: iconst_0
    //   2437: aaload
    //   2438: iconst_1
    //   2439: invokevirtual g : (I)V
    //   2442: aload_1
    //   2443: iconst_3
    //   2444: aaload
    //   2445: iconst_0
    //   2446: aaload
    //   2447: iconst_1
    //   2448: invokevirtual h : (I)V
    //   2451: aload_1
    //   2452: iconst_4
    //   2453: aaload
    //   2454: iconst_0
    //   2455: new v
    //   2458: dup
    //   2459: iconst_5
    //   2460: bipush #10
    //   2462: invokespecial <init> : (II)V
    //   2465: aastore
    //   2466: aload_1
    //   2467: iconst_4
    //   2468: aaload
    //   2469: iconst_0
    //   2470: aaload
    //   2471: iconst_2
    //   2472: invokevirtual i : (I)V
    //   2475: aload_1
    //   2476: iconst_4
    //   2477: aaload
    //   2478: iconst_0
    //   2479: aaload
    //   2480: iconst_1
    //   2481: invokevirtual g : (I)V
    //   2484: aload_1
    //   2485: iconst_4
    //   2486: aaload
    //   2487: iconst_0
    //   2488: aaload
    //   2489: iconst_1
    //   2490: invokevirtual h : (I)V
    //   2493: aload_1
    //   2494: iconst_5
    //   2495: aaload
    //   2496: iconst_0
    //   2497: new m
    //   2500: dup
    //   2501: invokespecial <init> : ()V
    //   2504: aastore
    //   2505: aload_1
    //   2506: iconst_5
    //   2507: aaload
    //   2508: iconst_0
    //   2509: aaload
    //   2510: checkcast m
    //   2513: ldc 'E-mail: {u4|8|2|?}'
    //   2515: invokevirtual a : (Ljava/lang/String;)V
    //   2518: aload_1
    //   2519: iconst_5
    //   2520: aaload
    //   2521: iconst_0
    //   2522: aaload
    //   2523: iconst_1
    //   2524: invokevirtual g : (I)V
    //   2527: aload_1
    //   2528: iconst_5
    //   2529: aaload
    //   2530: iconst_0
    //   2531: aaload
    //   2532: iconst_1
    //   2533: invokevirtual h : (I)V
    //   2536: aload_1
    //   2537: bipush #6
    //   2539: aaload
    //   2540: iconst_0
    //   2541: new v
    //   2544: dup
    //   2545: iconst_5
    //   2546: bipush #25
    //   2548: invokespecial <init> : (II)V
    //   2551: aastore
    //   2552: aload_1
    //   2553: bipush #6
    //   2555: aaload
    //   2556: iconst_0
    //   2557: aaload
    //   2558: iconst_3
    //   2559: invokevirtual i : (I)V
    //   2562: aload_1
    //   2563: bipush #6
    //   2565: aaload
    //   2566: iconst_0
    //   2567: aaload
    //   2568: iconst_1
    //   2569: invokevirtual g : (I)V
    //   2572: aload_1
    //   2573: bipush #6
    //   2575: aaload
    //   2576: iconst_0
    //   2577: aaload
    //   2578: iconst_1
    //   2579: invokevirtual h : (I)V
    //   2582: aload_1
    //   2583: bipush #7
    //   2585: aaload
    //   2586: iconst_0
    //   2587: new m
    //   2590: dup
    //   2591: invokespecial <init> : ()V
    //   2594: aastore
    //   2595: aload_1
    //   2596: bipush #7
    //   2598: aaload
    //   2599: iconst_0
    //   2600: aaload
    //   2601: checkcast m
    //   2604: ldc 'Раса: {u4|8|3|?}'
    //   2606: invokevirtual a : (Ljava/lang/String;)V
    //   2609: aload_1
    //   2610: bipush #7
    //   2612: aaload
    //   2613: iconst_0
    //   2614: aaload
    //   2615: iconst_1
    //   2616: invokevirtual g : (I)V
    //   2619: aload_1
    //   2620: bipush #7
    //   2622: aaload
    //   2623: iconst_0
    //   2624: aaload
    //   2625: iconst_1
    //   2626: invokevirtual h : (I)V
    //   2629: aload_1
    //   2630: bipush #8
    //   2632: aaload
    //   2633: iconst_0
    //   2634: new m
    //   2637: dup
    //   2638: invokespecial <init> : ()V
    //   2641: aastore
    //   2642: aload_1
    //   2643: bipush #8
    //   2645: aaload
    //   2646: iconst_0
    //   2647: aaload
    //   2648: iconst_1
    //   2649: invokevirtual g : (I)V
    //   2652: aload_1
    //   2653: bipush #8
    //   2655: aaload
    //   2656: iconst_0
    //   2657: aaload
    //   2658: iconst_1
    //   2659: invokevirtual h : (I)V
    //   2662: aload_1
    //   2663: bipush #8
    //   2665: aaload
    //   2666: iconst_0
    //   2667: aaload
    //   2668: checkcast m
    //   2671: ldc 'Игровые {u4|11|0|0|расы}.'
    //   2673: invokevirtual a : (Ljava/lang/String;)V
    //   2676: aload_1
    //   2677: bipush #9
    //   2679: aaload
    //   2680: iconst_0
    //   2681: new aa
    //   2684: dup
    //   2685: invokespecial <init> : ()V
    //   2688: aastore
    //   2689: aload_1
    //   2690: bipush #9
    //   2692: aaload
    //   2693: iconst_0
    //   2694: aaload
    //   2695: iconst_4
    //   2696: invokevirtual i : (I)V
    //   2699: aload_1
    //   2700: bipush #9
    //   2702: aaload
    //   2703: iconst_0
    //   2704: aaload
    //   2705: iconst_1
    //   2706: invokevirtual g : (I)V
    //   2709: aload_1
    //   2710: bipush #9
    //   2712: aaload
    //   2713: iconst_0
    //   2714: aaload
    //   2715: iconst_1
    //   2716: invokevirtual h : (I)V
    //   2719: iconst_3
    //   2720: anewarray java/lang/String
    //   2723: dup
    //   2724: iconst_0
    //   2725: ldc 'Люди'
    //   2727: aastore
    //   2728: dup
    //   2729: iconst_1
    //   2730: ldc 'Эльфы'
    //   2732: aastore
    //   2733: dup
    //   2734: iconst_2
    //   2735: ldc 'Гномы'
    //   2737: aastore
    //   2738: astore_2
    //   2739: aload_1
    //   2740: bipush #9
    //   2742: aaload
    //   2743: iconst_0
    //   2744: aaload
    //   2745: checkcast aa
    //   2748: aload_2
    //   2749: invokevirtual a : ([Ljava/lang/String;)V
    //   2752: aload_1
    //   2753: bipush #10
    //   2755: aaload
    //   2756: iconst_0
    //   2757: new m
    //   2760: dup
    //   2761: invokespecial <init> : ()V
    //   2764: aastore
    //   2765: aload_1
    //   2766: bipush #10
    //   2768: aaload
    //   2769: iconst_0
    //   2770: aaload
    //   2771: checkcast m
    //   2774: ldc 'Контрольный вопрос: {u4|8|5|?}'
    //   2776: invokevirtual a : (Ljava/lang/String;)V
    //   2779: aload_1
    //   2780: bipush #10
    //   2782: aaload
    //   2783: iconst_0
    //   2784: aaload
    //   2785: iconst_1
    //   2786: invokevirtual g : (I)V
    //   2789: aload_1
    //   2790: bipush #10
    //   2792: aaload
    //   2793: iconst_0
    //   2794: aaload
    //   2795: iconst_1
    //   2796: invokevirtual h : (I)V
    //   2799: aload_1
    //   2800: bipush #11
    //   2802: aaload
    //   2803: iconst_0
    //   2804: new v
    //   2807: dup
    //   2808: iconst_4
    //   2809: bipush #40
    //   2811: invokespecial <init> : (II)V
    //   2814: aastore
    //   2815: aload_1
    //   2816: bipush #11
    //   2818: aaload
    //   2819: iconst_0
    //   2820: aaload
    //   2821: bipush #7
    //   2823: invokevirtual i : (I)V
    //   2826: aload_1
    //   2827: bipush #11
    //   2829: aaload
    //   2830: iconst_0
    //   2831: aaload
    //   2832: iconst_1
    //   2833: invokevirtual g : (I)V
    //   2836: aload_1
    //   2837: bipush #11
    //   2839: aaload
    //   2840: iconst_0
    //   2841: aaload
    //   2842: iconst_1
    //   2843: invokevirtual h : (I)V
    //   2846: aload_1
    //   2847: bipush #12
    //   2849: aaload
    //   2850: iconst_0
    //   2851: new m
    //   2854: dup
    //   2855: invokespecial <init> : ()V
    //   2858: aastore
    //   2859: aload_1
    //   2860: bipush #12
    //   2862: aaload
    //   2863: iconst_0
    //   2864: aaload
    //   2865: checkcast m
    //   2868: ldc 'Ответ: {u4|8|6|?}'
    //   2870: invokevirtual a : (Ljava/lang/String;)V
    //   2873: aload_1
    //   2874: bipush #12
    //   2876: aaload
    //   2877: iconst_0
    //   2878: aaload
    //   2879: iconst_1
    //   2880: invokevirtual g : (I)V
    //   2883: aload_1
    //   2884: bipush #12
    //   2886: aaload
    //   2887: iconst_0
    //   2888: aaload
    //   2889: iconst_1
    //   2890: invokevirtual h : (I)V
    //   2893: aload_1
    //   2894: bipush #13
    //   2896: aaload
    //   2897: iconst_0
    //   2898: new v
    //   2901: dup
    //   2902: iconst_4
    //   2903: bipush #40
    //   2905: invokespecial <init> : (II)V
    //   2908: aastore
    //   2909: aload_1
    //   2910: bipush #13
    //   2912: aaload
    //   2913: iconst_0
    //   2914: aaload
    //   2915: bipush #8
    //   2917: invokevirtual i : (I)V
    //   2920: aload_1
    //   2921: bipush #13
    //   2923: aaload
    //   2924: iconst_0
    //   2925: aaload
    //   2926: iconst_1
    //   2927: invokevirtual g : (I)V
    //   2930: aload_1
    //   2931: bipush #13
    //   2933: aaload
    //   2934: iconst_0
    //   2935: aaload
    //   2936: iconst_1
    //   2937: invokevirtual h : (I)V
    //   2940: aload_1
    //   2941: bipush #14
    //   2943: aaload
    //   2944: iconst_0
    //   2945: new m
    //   2948: dup
    //   2949: invokespecial <init> : ()V
    //   2952: aastore
    //   2953: aload_1
    //   2954: bipush #14
    //   2956: aaload
    //   2957: iconst_0
    //   2958: aaload
    //   2959: iconst_1
    //   2960: invokevirtual g : (I)V
    //   2963: aload_1
    //   2964: bipush #14
    //   2966: aaload
    //   2967: iconst_0
    //   2968: aaload
    //   2969: iconst_1
    //   2970: invokevirtual h : (I)V
    //   2973: aload_1
    //   2974: bipush #14
    //   2976: aaload
    //   2977: iconst_0
    //   2978: aaload
    //   2979: checkcast m
    //   2982: ldc '{u4|10|0|0|Правила} игры. {u4|8|4|?}'
    //   2984: invokevirtual a : (Ljava/lang/String;)V
    //   2987: aload_1
    //   2988: bipush #15
    //   2990: aaload
    //   2991: iconst_0
    //   2992: new e
    //   2995: dup
    //   2996: invokespecial <init> : ()V
    //   2999: aastore
    //   3000: aload_1
    //   3001: bipush #15
    //   3003: aaload
    //   3004: iconst_0
    //   3005: aaload
    //   3006: bipush #6
    //   3008: invokevirtual i : (I)V
    //   3011: aload_1
    //   3012: bipush #15
    //   3014: aaload
    //   3015: iconst_0
    //   3016: aaload
    //   3017: iconst_1
    //   3018: invokevirtual g : (I)V
    //   3021: aload_1
    //   3022: bipush #15
    //   3024: aaload
    //   3025: iconst_0
    //   3026: aaload
    //   3027: iconst_1
    //   3028: invokevirtual h : (I)V
    //   3031: aload_1
    //   3032: bipush #15
    //   3034: aaload
    //   3035: iconst_0
    //   3036: aaload
    //   3037: checkcast e
    //   3040: ldc 'Принимаю'
    //   3042: invokevirtual b : (Ljava/lang/String;)V
    //   3045: aload_1
    //   3046: bipush #16
    //   3048: aaload
    //   3049: iconst_0
    //   3050: new h
    //   3053: dup
    //   3054: invokespecial <init> : ()V
    //   3057: aastore
    //   3058: aload_1
    //   3059: bipush #16
    //   3061: aaload
    //   3062: iconst_0
    //   3063: aaload
    //   3064: iconst_1
    //   3065: invokevirtual g : (I)V
    //   3068: aload_1
    //   3069: bipush #16
    //   3071: aaload
    //   3072: iconst_0
    //   3073: aaload
    //   3074: checkcast h
    //   3077: bipush #22
    //   3079: invokevirtual f : (I)V
    //   3082: aload_1
    //   3083: bipush #16
    //   3085: aaload
    //   3086: iconst_0
    //   3087: aaload
    //   3088: checkcast h
    //   3091: ldc 'Продолжить'
    //   3093: invokevirtual b : (Ljava/lang/String;)V
    //   3096: iconst_3
    //   3097: newarray int
    //   3099: dup
    //   3100: iconst_0
    //   3101: iconst_4
    //   3102: iastore
    //   3103: dup
    //   3104: iconst_1
    //   3105: bipush #7
    //   3107: iastore
    //   3108: dup
    //   3109: iconst_2
    //   3110: iconst_0
    //   3111: iastore
    //   3112: astore_2
    //   3113: bipush #8
    //   3115: newarray int
    //   3117: dup
    //   3118: iconst_0
    //   3119: iconst_1
    //   3120: iastore
    //   3121: dup
    //   3122: iconst_1
    //   3123: iconst_2
    //   3124: iastore
    //   3125: dup
    //   3126: iconst_2
    //   3127: iconst_3
    //   3128: iastore
    //   3129: dup
    //   3130: iconst_3
    //   3131: iconst_4
    //   3132: iastore
    //   3133: dup
    //   3134: iconst_4
    //   3135: iconst_5
    //   3136: iastore
    //   3137: dup
    //   3138: iconst_5
    //   3139: bipush #6
    //   3141: iastore
    //   3142: dup
    //   3143: bipush #6
    //   3145: bipush #7
    //   3147: iastore
    //   3148: dup
    //   3149: bipush #7
    //   3151: bipush #8
    //   3153: iastore
    //   3154: astore_3
    //   3155: aload_1
    //   3156: bipush #16
    //   3158: aaload
    //   3159: iconst_0
    //   3160: aaload
    //   3161: checkcast h
    //   3164: aload_3
    //   3165: invokevirtual a : ([I)V
    //   3168: aload_1
    //   3169: bipush #16
    //   3171: aaload
    //   3172: iconst_0
    //   3173: aaload
    //   3174: checkcast h
    //   3177: aload_2
    //   3178: iconst_0
    //   3179: invokevirtual a : ([II)V
    //   3182: aload_1
    //   3183: bipush #16
    //   3185: aaload
    //   3186: iconst_0
    //   3187: aaload
    //   3188: checkcast h
    //   3191: iconst_1
    //   3192: invokevirtual e : (I)V
    //   3195: new q
    //   3198: dup
    //   3199: invokespecial <init> : ()V
    //   3202: dup
    //   3203: astore_2
    //   3204: bipush #100
    //   3206: bipush #100
    //   3208: invokevirtual a : (II)V
    //   3211: aload_2
    //   3212: aconst_null
    //   3213: aload_1
    //   3214: invokevirtual a : (Ljava/lang/String;[[Ln;)V
    //   3217: aload_2
    //   3218: iconst_3
    //   3219: istore_3
    //   3220: dup
    //   3221: astore_1
    //   3222: iload_3
    //   3223: putfield b : I
    //   3226: invokestatic a : ()Lcom/fenix/main/b;
    //   3229: aload_2
    //   3230: invokevirtual a : (Lcom/fenix/main/f;)V
    //   3233: aload_0
    //   3234: getfield a : [[Ln;
    //   3237: aload_0
    //   3238: getfield x : I
    //   3241: aaload
    //   3242: aload_0
    //   3243: getfield y : I
    //   3246: aaload
    //   3247: instanceof e
    //   3250: ifeq -> 3273
    //   3253: aload_0
    //   3254: getfield a : [[Ln;
    //   3257: aload_0
    //   3258: getfield x : I
    //   3261: aaload
    //   3262: aload_0
    //   3263: getfield y : I
    //   3266: aaload
    //   3267: checkcast e
    //   3270: invokevirtual a : ()V
    //   3273: return
  }
  
  public final void a(Graphics paramGraphics) {
    Graphics graphics = paramGraphics;
    q q1 = this;
    graphics.setColor(2233600);
    int i = c.k.getHeight();
    int j = c.k.getWidth();
    int k = q1.l / i + 1;
    int m = q1.k / j + 1;
    graphics.setClip(q1.i, q1.j, q1.k, q1.l);
    for (byte b2 = 0; b2 < k; b2++) {
      for (byte b = 0; b < m; b++)
        graphics.drawImage(c.k, q1.i + b * j, q1.j + b2 * i, 0); 
    } 
    graphics.setColor(11642239);
    graphics.drawRect(q1.i + 1, q1.j + 1, q1.k - 3, q1.l - 3);
    graphics.setColor(14793067);
    graphics.drawRect(q1.i + 3, q1.j + 3, q1.k - 7, q1.l - 7);
    graphics.setColor(0);
    graphics.drawRect(q1.i + 4, q1.j + 4, q1.k - 9, q1.l - 9);
    a(paramGraphics, this.i + this.o + 5, this.j + 5, 10, this.p - 1 + 14, this.p / 5, this.d / 5, this.c / 5 + this.p / 5);
    paramGraphics.setClip(this.m, this.n, this.o, this.p);
    byte b1;
    for (b1 = 0; b1 < this.a.length; b1++) {
      for (byte b = 0; b < (this.a[b1]).length; b++) {
        if (this.a[b1][b].l() + this.a[b1][b].n() > 0 && this.a[b1][b].l() - this.j < this.l)
          this.a[b1][b].a(paramGraphics); 
      } 
    } 
    if (this.a[this.x][this.y] instanceof aa && ((aa)this.a[this.x][this.y]).a == 1)
      ((aa)this.a[this.x][this.y]).a(paramGraphics); 
    paramGraphics.drawRect(this.m, this.j + this.l - 10, this.o - 4, 4);
    paramGraphics.setClip(0, 0, i.a, i.b);
    if (k.a || k.b) {
      paramGraphics.setColor(16746240);
      for (b1 = 0; b1 < this.r; b1++)
        paramGraphics.fillRoundRect(this.m + (this.k - 10 * this.r - 15) / 2 + b1 * 10, this.j + this.l - 17, 8, 10, 9, 9); 
      if (this.r > 4) {
        this.r = 1;
        return;
      } 
      if (System.currentTimeMillis() - this.s > 500L) {
        this.s = System.currentTimeMillis();
        this.r++;
        return;
      } 
    } else {
      if (this.b == 1) {
        if (this.q == true) {
          paramGraphics.drawImage(c.a(702), this.m, this.j + this.l - 17, 0);
          paramGraphics.drawImage(c.a(700), this.i + this.o - 6, this.j + this.l - 17, 0);
          return;
        } 
        paramGraphics.drawImage(c.a(700), this.m, this.j + this.l - 17, 0);
        paramGraphics.drawImage(c.a(701), this.i + this.o - 6, this.j + this.l - 17, 0);
        return;
      } 
      if (this.b == 2 || this.b == 0 || this.b == 5) {
        if (this.q == true) {
          paramGraphics.drawImage(c.a(702), this.m, this.j + this.l - 17, 0);
          paramGraphics.drawImage(c.a(701), this.i + this.o - 6, this.j + this.l - 17, 0);
          return;
        } 
        paramGraphics.drawImage(c.a(701), this.i + this.o - 6, this.j + this.l - 17, 0);
        return;
      } 
      if (this.b == 3) {
        if (this.q == true) {
          paramGraphics.drawImage(c.a(702), this.m, this.j + this.l - 17, 0);
          return;
        } 
        paramGraphics.drawImage(c.a(700), this.m, this.j + this.l - 17, 0);
        return;
      } 
      if (this.b == 10) {
        if (this.q == true) {
          paramGraphics.drawImage(c.a(702), this.m, this.j + this.l - 17, 0);
          return;
        } 
        paramGraphics.drawImage(c.a(700), this.m, this.j + this.l - 17, 0);
      } 
    } 
  }
  
  private static void a(Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3) {
    if (paramInt3 == 0) {
      paramGraphics.drawLine(paramInt1 + 1, paramInt2 + 3, paramInt1 + 7, paramInt2 + 3);
      paramGraphics.drawLine(paramInt1 + 2, paramInt2 + 2, paramInt1 + 6, paramInt2 + 2);
      paramGraphics.drawLine(paramInt1 + 3, paramInt2 + 1, paramInt1 + 5, paramInt2 + 1);
      paramGraphics.drawLine(paramInt1 + 4, paramInt2, paramInt1 + 4, paramInt2);
    } 
    if (paramInt3 == 1) {
      paramGraphics.drawLine(paramInt1 + 1, paramInt2, paramInt1 + 7, paramInt2);
      paramGraphics.drawLine(paramInt1 + 2, paramInt2 + 1, paramInt1 + 6, paramInt2 + 1);
      paramGraphics.drawLine(paramInt1 + 3, paramInt2 + 2, paramInt1 + 5, paramInt2 + 2);
      paramGraphics.drawLine(paramInt1 + 4, paramInt2 + 3, paramInt1 + 4, paramInt2 + 3);
    } 
  }
  
  public static void a(Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7) {
    paramGraphics.setColor(2230016);
    paramGraphics.fillRect(paramInt1, paramInt2, 10, paramInt4);
    paramInt3 = c.p.getHeight();
    int i = c.p.getWidth();
    int j = paramInt4 / paramInt3;
    int k;
    for (k = 0; k < j; k++)
      paramGraphics.drawImage(c.p, paramInt1 + 5 - i / 2, k * paramInt3 + paramInt2, 0); 
    k = paramGraphics.getClipX();
    int m = paramGraphics.getClipY();
    int i1 = paramGraphics.getClipWidth();
    int i2 = paramGraphics.getClipHeight();
    int i3 = paramInt4 % paramInt3;
    if (paramInt2 + j * paramInt3 + i3 < paramGraphics.getClipY() + paramGraphics.getClipHeight()) {
      paramGraphics.setClip(paramInt1, paramInt2 + j * paramInt3, 10, i3);
      paramGraphics.drawImage(c.p, paramInt1 + 5 - i / 2, j * paramInt3 + paramInt2, 0);
      paramGraphics.setClip(k, m, i1, i2);
    } 
    paramGraphics.setColor(3215616);
    paramGraphics.fillRect(paramInt1 + 2, paramInt2 + 2, 7, 6);
    paramGraphics.fillRect(paramInt1 + 2, paramInt2 + paramInt4 + 2 - 10, 7, 6);
    paramGraphics.setColor(6037505);
    a(paramGraphics, paramInt1 + 1, paramInt2 + 5 - 2, 0);
    a(paramGraphics, paramInt1 + 1, paramInt2 + paramInt4 - 5 - 1, 1);
    paramInt3 = paramInt4 - 20;
    if (paramInt7 <= paramInt5) {
      paramInt4 = paramInt3;
      i = 0;
    } else {
      if ((i = paramInt3 / paramInt7) == 0) {
        i = 3;
        if ((paramInt4 = paramInt5 * paramInt3 / paramInt7) < 5)
          paramInt4 = 14; 
        j = i3 = (paramInt7 - paramInt5) / 3 + 1;
        i3 = paramInt7 / i3 + 1;
        if (j > 50)
          i3 = j / 9; 
        paramInt6 /= i3;
        paramInt3 = paramInt3 - paramInt4 - (paramInt7 - paramInt5) / i3 * 3;
      } else {
        paramInt4 = paramInt5 * paramInt3 / paramInt7;
        paramInt3 = paramInt3 - paramInt4 - (paramInt7 - paramInt5) * i;
      } 
      paramInt4 += paramInt3;
    } 
    paramGraphics.setColor(3671296);
    paramGraphics.fillRect(paramInt1, paramInt2 + 10 + paramInt6 * i, 9, paramInt4);
    paramInt3 = c.o.getHeight();
    c.o.getWidth();
    j = paramInt4 / paramInt3;
    for (i3 = 0; i3 < j; i3++)
      paramGraphics.drawImage(c.o, paramInt1 + 1, i3 * paramInt3 + paramInt2 + 10 + paramInt6 * i, 0); 
    i3 = paramInt4 % paramInt3;
    if (paramInt2 + j * paramInt3 + i3 < paramGraphics.getClipY() + paramGraphics.getClipHeight()) {
      paramGraphics.setClip(paramInt1 + 1, paramInt2 + 10 + paramInt6 * i + j * paramInt3, 10, i3);
      paramGraphics.drawImage(c.o, paramGraphics.getClipX(), paramGraphics.getClipY(), 0);
      paramGraphics.setClip(k, m, i1, i2);
    } 
  }
}


/* Location:              C:\Users\sora\Desktop\Third_World_War_of_Kings_2D.jar!\q.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */