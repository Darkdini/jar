import com.fenix.main.c;
import com.fenix.main.h;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;

public final class h extends n {
  private int a;
  
  private int b = 2;
  
  private int[] c;
  
  private int d = 0;
  
  private Image e = null;
  
  private int[] f;
  
  public h() {
    b("");
    c(true);
    this.a = 0;
  }
  
  public final void e(int paramInt) {
    this.b = 1;
  }
  
  public final void f(int paramInt) {
    this.a = paramInt;
  }
  
  public final void a(int[] paramArrayOfint, int paramInt) {
    this.c = paramArrayOfint;
    this.d = paramInt;
  }
  
  public final int a() {
    return this.d;
  }
  
  public final int b() {
    return this.b;
  }
  
  public final int[] c() {
    return this.c;
  }
  
  public final int d() {
    return this.a;
  }
  
  public final void a(Graphics paramGraphics) {
    if (!g())
      return; 
    if (!i()) {
      this.e = c.l;
    } else {
      this.e = c.m;
    } 
    int i = k();
    int j = l();
    int k = m();
    int m = n();
    int i1 = this.e.getHeight();
    int i2 = this.e.getWidth();
    int i3 = k / i2;
    int i4 = k % i2;
    if (!i()) {
      paramGraphics.setColor(4408105);
    } else {
      paramGraphics.setColor(6184506);
    } 
    paramGraphics.fillRect(i, j, k, m);
    int i5 = paramGraphics.getClipX();
    int i6 = paramGraphics.getClipY();
    int i7 = paramGraphics.getClipWidth();
    int i8 = paramGraphics.getClipHeight();
    int i9 = j;
    if (j - i6 < 0)
      i9 = i6; 
    int i10 = i1;
    if (j + i1 > i6 + i8)
      i10 = i1 - j + i1 - i6 - i8; 
    if (j - i6 >= 0) {
      paramGraphics.setClip(i + i3 * i2, i9, i4, i10);
      paramGraphics.drawImage(this.e, paramGraphics.getClipX(), paramGraphics.getClipY(), 0);
      paramGraphics.setClip(i5, i6, i7, i8);
    } 
    for (i4 = 0; i4 < 1; i4++) {
      for (i5 = 0; i5 < i3; i5++)
        paramGraphics.drawImage(this.e, i + i5 * i2, j + i4 * i1, 0); 
    } 
    if (!i()) {
      paramGraphics.setColor(9735534);
      paramGraphics.drawRect(i - 1, j - 1, k + 1, m + 1);
      paramGraphics.setColor(0);
      paramGraphics.drawRect(i - 2, j - 2, k + 3, m + 3);
    } else {
      paramGraphics.setColor(16777164);
      paramGraphics.drawRect(i - 1, j - 1, k + 1, m + 1);
      paramGraphics.setColor(0);
      paramGraphics.drawRect(i - 2, j - 2, k + 3, m + 3);
    } 
    paramGraphics.setColor(16777215);
    paramGraphics.setFont(h.d);
    paramGraphics.drawString(j(), k() + k / 2 - paramGraphics.getFont().stringWidth(j()) / 2, j + m / 2 - paramGraphics.getFont().getHeight() / 2 + 1, 0);
  }
  
  public final void a(int[] paramArrayOfint) {
    this.f = paramArrayOfint;
  }
  
  public final int[] e() {
    return this.f;
  }
}


/* Location:              C:\Users\sora\Desktop\Third_World_War_of_Kings_2D.jar!\h.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */