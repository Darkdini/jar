import com.fenix.main.c;
import javax.microedition.lcdui.Font;
import javax.microedition.lcdui.Image;

public final class l {
  private static l a;
  
  private int[] b = new int[3];
  
  private int c = 0;
  
  public static l a() {
    if (a == null)
      a = new l(); 
    return a;
  }
  
  public final String[] a(String paramString, Font paramFont, int paramInt, boolean paramBoolean) {
    try {
      String[] arrayOfString2;
      System.currentTimeMillis();
      paramBoolean = false;
      int j = 0;
      String[] arrayOfString3 = new String[20];
      int k = 0;
      int i;
      do {
        if ((j = paramString.indexOf("\n", paramBoolean)) == -1)
          j = paramString.length(); 
        System.currentTimeMillis();
        arrayOfString2 = a(paramString.substring(paramBoolean, j), paramFont, paramInt);
        if (arrayOfString3.length >= k + arrayOfString2.length)
          continue; 
        String[] arrayOfString = new String[k + arrayOfString2.length + 20];
        System.arraycopy(arrayOfString3, 0, arrayOfString, 0, arrayOfString3.length);
        arrayOfString3 = arrayOfString;
        System.arraycopy(arrayOfString2, 0, arrayOfString3, k, arrayOfString2.length);
        k += arrayOfString2.length;
      } while ((i = j + 1) < paramString.length() && j != -1);
      String[] arrayOfString1 = new String[k];
      System.arraycopy(arrayOfString3, 0, arrayOfString1, 0, k);
      if (this.c > 0) {
        c.r = null;
        int m = 0;
        if (c.r == null) {
          c.r = new int[this.c];
        } else {
          int[] arrayOfInt = new int[c.r.length];
          System.arraycopy(c.r, 0, arrayOfInt, 0, arrayOfInt.length);
          c.r = null;
          c.r = new int[this.c + arrayOfInt.length];
          System.arraycopy(arrayOfInt, 0, c.r, 0, arrayOfInt.length);
          m = arrayOfInt.length;
        } 
        for (i = 0; i < this.c; i++)
          c.r[i + m] = this.b[i]; 
        k.a();
        k.a(c.r);
        this.b = null;
        this.b = new int[0];
        this.c = 0;
      } 
      return arrayOfString1;
    } catch (Exception exception) {
      System.err.println("TextParser.parse - *> " + this);
      return null;
    } 
  }
  
  public final int a(String paramString, Font paramFont) {
    try {
      int i = paramString.indexOf("{");
      int j = 0;
      if (i < 0)
        return paramFont.stringWidth(paramString); 
      while ((i = paramString.indexOf("{")) >= 0) {
        String str1;
        Image image;
        String str2 = paramString.substring(0, i);
        j += paramFont.stringWidth(str2);
        switch (paramString.charAt(i + 1)) {
          case 'i':
            if ((image = c.a(i = Integer.parseInt(paramString.substring(i + 2, paramString.indexOf("}", i))))) == null) {
              image = c.q;
              int k = i;
              l l1;
              if ((l1 = this).c >= l1.b.length) {
                int[] arrayOfInt = new int[l1.b.length + 3];
                System.arraycopy(l1.b, 0, arrayOfInt, 0, l1.b.length);
                l1.b = null;
                l1.b = arrayOfInt;
              } 
              byte b = 0;
              while (true) {
                if (b < l1.c) {
                  if (k != l1.b[b]) {
                    b++;
                    continue;
                  } 
                  break;
                } 
                l1.b[l1.c++] = k;
                break;
              } 
            } 
            j += image.getWidth();
            break;
          case 'u':
            str1 = paramString.substring(paramString.indexOf("{") + 2, paramString.indexOf("}"));
            j += paramFont.stringWidth(str1.substring(str1.lastIndexOf('|') + 1));
            break;
        } 
        paramString = paramString.substring(paramString.indexOf("}") + 1);
      } 
      return j += paramFont.stringWidth(paramString);
    } catch (Exception exception) {
      System.err.println("Error in TextParser.calcSubstringWidth " + exception);
      return 20;
    } 
  }
  
  public static int b(String paramString, Font paramFont) {
    try {
      int i = paramString.indexOf("{i");
      int j = 0;
      paramFont.getHeight();
      int k = paramFont.getHeight();
      if (i < 0)
        return paramFont.getHeight(); 
      try {
        while ((i = paramString.indexOf("{i")) >= 0) {
          int m = c.a(Integer.parseInt(paramString.substring(i + 2, paramString.indexOf("}", i)))).getHeight();
          if (j < m)
            if (m > k) {
              j = m;
            } else {
              j = k;
            }  
          paramString = paramString.substring(paramString.indexOf("}") + 1);
        } 
      } catch (Exception exception) {}
      return j;
    } catch (Exception exception) {
      System.err.println("TextParser.calcSubstringHeight - > " + exception);
      return 10;
    } 
  }
  
  private String[] a(String paramString, Font paramFont, int paramInt) {
    String[] arrayOfString1 = new String[10];
    byte b = 0;
    int i = 0;
    int j = 1;
    int k = -1;
    while (j) {
      int m;
      if ((m = paramString.indexOf(" ", i)) > -1) {
        if (paramString.substring(0, m).lastIndexOf('{') > paramString.substring(0, m).lastIndexOf('}')) {
          i = m + 1;
          continue;
        } 
        if (a(paramString.substring(0, m), paramFont) > paramInt) {
          if (k != -1) {
            m = k;
            arrayOfString1[b] = paramString.substring(0, k);
          } else {
            arrayOfString1[b] = paramString.substring(0, m);
          } 
          if (b + 1 >= arrayOfString1.length) {
            String[] arrayOfString = new String[arrayOfString1.length];
            System.arraycopy(arrayOfString1, 0, arrayOfString, 0, arrayOfString1.length);
            arrayOfString1 = new String[arrayOfString.length + 10];
            System.arraycopy(arrayOfString, 0, arrayOfString1, 0, arrayOfString.length);
          } 
          paramString = paramString.substring(m + 1, paramString.length());
          b++;
          k = -1;
          i = 0;
          continue;
        } 
        k = m;
        i = m + 1;
        continue;
      } 
      String str = paramString.substring(0);
      if ((j = a(str, paramFont)) > paramInt) {
        if (k != -1) {
          arrayOfString1[b] = str.substring(0, k);
          if (b + 1 >= arrayOfString1.length) {
            String[] arrayOfString = new String[arrayOfString1.length];
            System.arraycopy(arrayOfString1, 0, arrayOfString, 0, arrayOfString1.length);
            arrayOfString1 = new String[arrayOfString.length + 10];
            System.arraycopy(arrayOfString, 0, arrayOfString1, 0, arrayOfString.length);
          } 
          arrayOfString1[++b] = str.substring(k);
          if (b + 1 >= arrayOfString1.length) {
            String[] arrayOfString = new String[arrayOfString1.length];
            System.arraycopy(arrayOfString1, 0, arrayOfString, 0, arrayOfString1.length);
            arrayOfString1 = new String[arrayOfString.length + 10];
            System.arraycopy(arrayOfString, 0, arrayOfString1, 0, arrayOfString.length);
          } 
          b++;
          paramString = paramString.substring(m + 1, paramString.length());
          k = -1;
        } else {
          arrayOfString1[b] = str;
          if (b + 1 >= arrayOfString1.length) {
            String[] arrayOfString = new String[arrayOfString1.length];
            System.arraycopy(arrayOfString1, 0, arrayOfString, 0, arrayOfString1.length);
            arrayOfString1 = new String[arrayOfString.length + 10];
            System.arraycopy(arrayOfString, 0, arrayOfString1, 0, arrayOfString.length);
          } 
          b++;
          paramString = paramString.substring(m + 1, paramString.length());
          k = -1;
        } 
      } else {
        arrayOfString1[b] = paramString.substring(0);
        if (b + 1 >= arrayOfString1.length) {
          String[] arrayOfString = new String[arrayOfString1.length];
          System.arraycopy(arrayOfString1, 0, arrayOfString, 0, arrayOfString1.length);
          arrayOfString1 = new String[arrayOfString.length + 10];
          System.arraycopy(arrayOfString, 0, arrayOfString1, 0, arrayOfString.length);
        } 
        paramString = paramString.substring(m + 1, paramString.length());
        b++;
        k = -1;
      } 
      j = 0;
    } 
    String[] arrayOfString2 = new String[b];
    System.arraycopy(arrayOfString1, 0, arrayOfString2, 0, arrayOfString2.length);
    return arrayOfString2;
  }
}


/* Location:              C:\Users\sora\Desktop\Third_World_War_of_Kings_2D.jar!\l.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */