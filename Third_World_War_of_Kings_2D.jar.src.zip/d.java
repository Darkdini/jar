import java.io.ByteArrayOutputStream;

public final class d extends x {
  private int a;
  
  private int b;
  
  private byte[] c;
  
  private ByteArrayOutputStream d;
  
  public d(int paramInt1, int paramInt2, int paramInt3) {
    a(2);
    this.a = paramInt1;
    this.b = paramInt2;
    this.d = new ByteArrayOutputStream();
    b(1);
  }
  
  private d(int paramInt1, int paramInt2, byte[] paramArrayOfbyte, int paramInt3) {
    a(2);
    this.a = paramInt1;
    this.b = paramInt2;
    this.c = paramArrayOfbyte;
    b(paramInt3);
  }
  
  public d(int paramInt1, int paramInt2, int paramInt3, byte[] paramArrayOfbyte) {
    this.d = new ByteArrayOutputStream();
    this.d.write(paramArrayOfbyte, 0, paramArrayOfbyte.length);
    this.c = paramArrayOfbyte;
    this.a = paramInt2;
    this.b = paramInt3;
    a(paramInt1);
  }
  
  public final void a(byte[] paramArrayOfbyte) {
    this.d.write(paramArrayOfbyte, 0, paramArrayOfbyte.length);
  }
  
  public final int a() {
    return this.a;
  }
  
  public final int b() {
    return this.b;
  }
  
  public final byte[] c() {
    return this.c;
  }
  
  public final byte[] d() {
    byte[] arrayOfByte1;
    g.a(arrayOfByte1 = new byte[this.d.size() + 6 + 4], 0, 42);
    g.a(arrayOfByte1, 1, f());
    int i = 1;
    byte b = 2;
    byte[] arrayOfByte2;
    g.a(arrayOfByte2 = arrayOfByte1, b, i, true);
    i = arrayOfByte1.length - 6;
    b = 4;
    g.a(arrayOfByte2 = arrayOfByte1, b, i, true);
    i = this.a;
    b = 6;
    g.a(arrayOfByte2 = arrayOfByte1, b, i, true);
    i = this.b;
    b = 8;
    g.a(arrayOfByte2 = arrayOfByte1, b, i, true);
    System.arraycopy(this.d.toByteArray(), 0, arrayOfByte1, 10, this.d.size());
    return arrayOfByte1;
  }
  
  public static x a(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
    int i = g.b(paramArrayOfbyte, paramInt1);
    int j = g.b(paramArrayOfbyte, paramInt1 + 2);
    int k = g.a(paramArrayOfbyte, paramInt1 - 3);
    byte[] arrayOfByte = new byte[paramInt2 - 4];
    System.arraycopy(paramArrayOfbyte, paramInt1 + 4, arrayOfByte, 0, paramInt2 - 4);
    return new d(i, j, arrayOfByte, k);
  }
}


/* Location:              C:\Users\sora\Desktop\Third_World_War_of_Kings_2D.jar!\d.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */