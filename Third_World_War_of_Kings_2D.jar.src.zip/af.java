import com.fenix.main.Main;
import com.fenix.main.h;
import javax.microedition.lcdui.Graphics;

public final class af extends n {
  private String[] b;
  
  private StringBuffer c = null;
  
  private int d = 0;
  
  private int e = 0;
  
  public int a = 0;
  
  private int f = 0;
  
  private boolean g = false;
  
  private boolean h = false;
  
  public af() {
    c(true);
    this.c = new StringBuffer("");
    this.d = 0;
  }
  
  public final void a(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.a(paramInt1, paramInt2, paramInt3, paramInt4);
    a(this.c.toString());
  }
  
  public final void a(String paramString) {
    this.d = 0;
    System.out.println("SET VALUE");
    if (this.c != null)
      this.c = null; 
    if (paramString == null || paramString.length() <= 0) {
      this.c = new StringBuffer();
      this.c.setLength(0);
      this.e = 0;
      this.f = 0;
      return;
    } 
    this.c = new StringBuffer(paramString);
    if (m() > 0 && n() > 0)
      a(); 
  }
  
  public final void a() {
    this.b = l.a().a(this.c.toString(), h.d, m() - 25, true);
    this.e = this.b.length;
    this.f = (n() - 5) / h.d.getHeight();
    System.out.println("Memo text is parsing");
  }
  
  public final String b() {
    return (this.c == null || this.c.length() <= 0) ? "" : this.c.toString();
  }
  
  public final void a(Graphics paramGraphics) {
    if (!g())
      return; 
    int i = k();
    int j = l();
    int k = m();
    int m = n();
    if (i()) {
      paramGraphics.setColor(8986913);
    } else {
      paramGraphics.setColor(6684672);
    } 
    paramGraphics.fillRect(i, j, k, m);
    paramGraphics.setColor(1114112);
    paramGraphics.drawLine(i, j + m, i, j);
    paramGraphics.drawLine(i, j, i + k, j);
    paramGraphics.setColor(6706500);
    paramGraphics.drawLine(i + k, j + 1, i + k, j + m);
    paramGraphics.drawLine(i + k, j + m, i, j + m);
    paramGraphics.setFont(h.d);
    paramGraphics.setColor(16777215);
    if (this.b != null) {
      int i1;
      if ((i1 = this.d + this.f) >= this.e)
        i1 = this.e; 
      for (int i2 = this.d; i2 < i1; i2++)
        paramGraphics.drawString(this.b[i2], i + 5, j + 5 + (i2 - this.d) * paramGraphics.getFont().getHeight(), 0); 
      q.a(paramGraphics, i + k - 10, j + 1, 10, m - 1, this.f, this.d, this.e);
    } 
  }
  
  public final void e(int paramInt) {
    switch (paramInt) {
      case 8:
      case 65536:
        this.d--;
        if (this.d < 0) {
          this.d = 0;
          this.g = true;
          return;
        } 
        break;
      case 16:
      case 131072:
        this.d++;
        if (this.d >= this.e - this.f) {
          this.d = this.e - this.f;
          this.g = true;
        } 
        if (this.e < this.f) {
          this.d = 0;
          return;
        } 
        break;
      case 32:
      case 524288:
        if (this.h) {
          Main.a(b());
          Main.a(this);
          Main.a().b();
          System.out.println("After setNabeTextBox");
          this.a = 2;
          return;
        } 
        break;
      case 4096:
        this.a = 0;
        break;
    } 
  }
  
  public final boolean c() {
    return this.g;
  }
  
  public final void a(boolean paramBoolean) {
    super.a(paramBoolean);
    if (paramBoolean)
      this.g = false; 
  }
  
  public final void b(boolean paramBoolean) {
    this.h = paramBoolean;
  }
}


/* Location:              C:\Users\sora\Desktop\Third_World_War_of_Kings_2D.jar!\af.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */