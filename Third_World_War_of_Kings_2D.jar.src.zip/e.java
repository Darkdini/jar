import com.fenix.main.h;
import javax.microedition.lcdui.Graphics;

public final class e extends n {
  private boolean a = false;
  
  private boolean b = false;
  
  public e() {
    b("Hello");
    this.a = false;
    this.b = false;
  }
  
  public final void a() {
    this.b = !this.b;
  }
  
  public final String b() {
    return this.b ? "1" : "0";
  }
  
  public final void a(Graphics paramGraphics) {
    int i = k();
    int j = l();
    int k = n();
    if (i()) {
      paramGraphics.setColor(8986913);
    } else {
      paramGraphics.setColor(6684672);
    } 
    paramGraphics.fillRect(i, j, k, k);
    paramGraphics.setColor(0);
    paramGraphics.drawRect(i - 1, j - 1, k + 2, k + 2);
    if (i()) {
      paramGraphics.setColor(16777164);
      paramGraphics.drawRect(i, j, k, k);
    } else {
      paramGraphics.setColor(9735534);
      paramGraphics.drawRect(i, j, k, k);
    } 
    if (this.b) {
      if (i()) {
        paramGraphics.setColor(16777215);
      } else {
        paramGraphics.setColor(9735534);
      } 
      paramGraphics.drawRect(i + 2, j + 2, k - 4, k - 4);
      paramGraphics.setColor(3215616);
      paramGraphics.fillRect(i + 3, j + 3, k - 5, k - 5);
    } 
    i = i + k + 5 + 2;
    paramGraphics.setFont(h.d);
    if (i()) {
      paramGraphics.setColor(11642239);
      paramGraphics.fillRect(i, j, paramGraphics.getFont().stringWidth(j()), k);
    } 
    paramGraphics.setColor(16777215);
    paramGraphics.drawString(j(), i, j + k / 2 - paramGraphics.getFont().getHeight() / 2, 0);
  }
}


/* Location:              C:\Users\sora\Desktop\Third_World_War_of_Kings_2D.jar!\e.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */