public class x {
  private int a;
  
  private byte[] b;
  
  private int c = 0;
  
  protected x() {}
  
  public x(byte[] paramArrayOfbyte, int paramInt) {
    this.a = paramInt;
    this.b = paramArrayOfbyte;
  }
  
  public final void a(int paramInt) {
    this.a = paramInt;
  }
  
  public final void b(int paramInt) {
    this.c = paramInt;
    if (paramInt == 1)
      k.a = true; 
  }
  
  final int e() {
    return this.c;
  }
  
  public final int f() {
    return this.a;
  }
  
  public byte[] d() {
    byte[] arrayOfByte1;
    g.a(arrayOfByte1 = new byte[6 + this.b.length], 0, 42);
    g.a(arrayOfByte1, 1, this.a);
    int i = 0;
    byte b = 2;
    byte[] arrayOfByte2;
    g.a(arrayOfByte2 = arrayOfByte1, b, i, true);
    i = this.b.length;
    b = 4;
    g.a(arrayOfByte2 = arrayOfByte1, b, i, true);
    System.arraycopy(this.b, 0, arrayOfByte1, 6, this.b.length);
    return arrayOfByte1;
  }
  
  public static x a(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
    if (g.a(paramArrayOfbyte, paramInt1) != 42)
      throw new ac(130, 2); 
    int i;
    if ((i = g.a(paramArrayOfbyte, paramInt1 + 1)) < 1 || i > 5) {
      System.out.println("Error in Packet parse ---");
      throw new ac(130, 3);
    } 
    int j;
    if ((j = g.b(paramArrayOfbyte, paramInt1 + 4)) + 6 != paramInt2) {
      System.out.println("Error in FLAP header");
      return null;
    } 
    switch (i) {
      case 1:
        return f.a(paramArrayOfbyte, paramInt1 + 6, paramInt2 - 6);
      case 2:
        return d.a(paramArrayOfbyte, paramInt1 + 6, paramInt2 - 6);
      case 4:
        return null;
      case 5:
        return new x(null, 5);
    } 
    return null;
  }
}


/* Location:              C:\Users\sora\Desktop\Third_World_War_of_Kings_2D.jar!\x.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */