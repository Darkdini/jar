public final class ac extends Exception {
  public ac() {}
  
  public ac(int paramInt1, int paramInt2) {
    System.out.println("Exception in :");
    System.out.println("Group: " + paramInt1);
    System.out.println("Subgroup: " + paramInt2);
  }
}


/* Location:              C:\Users\sora\Desktop\Third_World_War_of_Kings_2D.jar!\ac.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */