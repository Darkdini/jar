import com.fenix.main.b;
import com.fenix.main.d;
import com.fenix.main.h;
import com.fenix.main.i;
import java.io.IOException;
import java.util.Vector;

public final class ag implements Runnable {
  private static ag b = null;
  
  private d c;
  
  private g d = new g(this);
  
  private Vector e = new Vector();
  
  private int f = 0;
  
  private Thread g = null;
  
  public int a = 0;
  
  private boolean h = true;
  
  public static ag a() {
    if (b == null)
      b = new ag(); 
    return b;
  }
  
  public final void b() {
    Thread thread;
    (thread = new Thread(this)).start();
  }
  
  protected final void c() {
    this.c = d.d();
    try {
      i.c = true;
      this.c.a(h.c, h.b, false);
      this.d.b();
      return;
    } catch (Exception exception) {
      a();
      a(1);
      throw new IOException("Unable to connect");
    } 
  }
  
  public static void a(int paramInt) {
    m m;
    System.out.println("RETRY CONNECTION WINDOWWWWWWWWWWWWWWWWWWWWWWWW");
    i.c = false;
    h h;
    (h = new h()).f(27);
    h.g(1);
    n[][] arrayOfN;
    (arrayOfN = new n[3][1])[0][0] = new z();
    ((z)arrayOfN[0][0]).e(10);
    arrayOfN[0][0].g(1);
    arrayOfN[0][0].h(0);
    if (paramInt == 1) {
      (m = new m()).a("Невозможно установить соединение с сервером.\n");
      m.g(1);
      h.b("Повторить");
      arrayOfN[1][0] = m;
    } else if (m == 2) {
      (m = new m()).a("Соединение с сервером прервано. Попробуйте переподсоединиться.");
      m.g(1);
      arrayOfN[1][0] = m;
      h.b("Повторить");
    } 
    arrayOfN[2][0] = h;
    q q;
    (q = new q()).a((String)null, arrayOfN);
    q.b(5);
    b.a().a(q);
  }
  
  public final void b(int paramInt) {
    paramInt = 0;
    ag ag1 = this;
    c c;
    (c = new c(ag1)).start();
    boolean bool = true;
    (this = this).f = bool;
  }
  
  public final void run() {
    while (this.h) {
      ag ag1;
      if ((ag1 = this).c != null && ag1.c.c())
        try {
          if (ag1.c.b() > 0) {
            System.currentTimeMillis();
            byte[] arrayOfByte = new byte[6];
            int j = 0;
            int i;
            do {
            
            } while ((i = ag1.c.a(arrayOfByte, j, arrayOfByte.length - j)) != -1 && (j += i) < arrayOfByte.length);
            if (i != -1) {
              if (g.a(arrayOfByte, 0) != 42) {
                System.out.println("Error in netEngine. Verify flap header");
                System.out.println("Byte is : " + g.a(arrayOfByte, 0));
                throw new ac(130, 3);
              } 
              byte[] arrayOfByte1 = new byte[g.b(arrayOfByte, 4)];
              j = 0;
              if (arrayOfByte1.length > 0)
                do {
                
                } while ((i = ag1.c.a(arrayOfByte1, j, arrayOfByte1.length - j)) != -1 && (j += i) < arrayOfByte1.length); 
              if (i != -1) {
                byte[] arrayOfByte2 = new byte[arrayOfByte.length + arrayOfByte1.length];
                System.arraycopy(arrayOfByte, 0, arrayOfByte2, 0, arrayOfByte.length);
                System.arraycopy(arrayOfByte1, 0, arrayOfByte2, arrayOfByte.length, arrayOfByte1.length);
                synchronized (ag1.e) {
                  ag1.e.addElement(arrayOfByte2);
                } 
                System.currentTimeMillis();
              } 
            } 
          } 
        } catch (IOException iOException) {
          System.err.println("Error in netEngine reciveData()" + iOException);
        } catch (ac ac) {
          System.err.println("Exception in netEngine: " + ac);
        }  
      if (f() > 0) {
        ag ag2;
        try {
          x x;
          if ((x = g()) == null)
            return; 
          if (x.e() > 0)
            k.a = false; 
        } catch (ac ac) {
          System.err.println("Error in netEngine.GAME_ENGINE " + ac);
          continue;
        } 
        switch (this.f) {
          case 1:
            if (ac.f() == 1) {
              if (ac instanceof d)
                this.d.a((d)ac); 
            } else if (ac.f() == 2 && ac instanceof d) {
              k.a().a((d)ac);
            } 
            if (this.d.c() == 3) {
              byte b = 2;
              ag ag3;
              (ag3 = this).f = b;
              d d1 = new d(10, 0, 1);
              this.c.a(d1);
              break;
            } 
            if (this.d.c() == 5) {
              y.a();
              boolean bool = false;
              (ag2 = this).f = bool;
            } 
            break;
          case 2:
            if (ag2 instanceof d)
              k.a().a((d)ag2); 
            break;
        } 
      } 
      try {
        Thread.sleep(50L);
      } catch (Exception exception) {}
    } 
  }
  
  private synchronized int f() {
    return (this.e == null) ? 0 : this.e.size();
  }
  
  private x g() {
    byte[] arrayOfByte2;
    Vector vector;
    /* monitor enter BinaryOperatorExpression{ClassFileLocalVariableReferenceExpression{type=ObjectType{java/util/Vector}, name=null} = FieldReferenceExpression{lastType=ObjectType{java/util/Vector}, expression=ThisExpression{ObjectType{ag}}, name=e, descriptor=Ljava/util/Vector;}} */
    try {
      if (this.e.size() == 0)
        return null; 
      arrayOfByte2 = this.e.elementAt(0);
    } finally {
      this = null;
      /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/util/Vector}, name=null} */
    } 
    byte[] arrayOfByte1;
    return x.a(arrayOfByte1 = arrayOfByte2, 0, this.length);
  }
  
  public final void a(x paramx) {
    this.c.a(paramx);
  }
  
  public final int d() {
    return this.f;
  }
  
  public final void e() {
    i.c = false;
    this.c.a();
    try {
      Thread.sleep(100L);
    } catch (Exception exception) {}
    b(0);
  }
}


/* Location:              C:\Users\sora\Desktop\Third_World_War_of_Kings_2D.jar!\ag.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */