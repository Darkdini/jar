import com.fenix.main.a;
import com.fenix.main.b;
import com.fenix.main.c;
import com.fenix.main.f;
import com.fenix.main.g;
import com.fenix.main.h;
import com.fenix.main.i;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Calendar;
import java.util.TimeZone;
import java.util.Vector;
import javax.microedition.io.Connector;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;
import javax.wireless.messaging.Message;
import javax.wireless.messaging.MessageConnection;
import javax.wireless.messaging.TextMessage;

public final class k extends f implements a {
  private static k d;
  
  private s e;
  
  private s f;
  
  private s g;
  
  private int h = 0;
  
  private int[][] i = new int[][] { 
      { 
        0, 0, 0, 0, 0, 0, 0, 0, 6, 0, 
        0, 0, 0, 0, 0, 0, 0 }, { 
        0, 0, 0, 0, 0, 0, 0, 0, 6, 0, 
        0, 0, 0, 0, 0, 0, 0 }, { 
        0, 0, 0, 0, 0, 0, 0, 0, 6, 0, 
        0, 0, 0, 0, 0, 0, 0 }, { 
        0, 0, 0, 0, 0, 0, 0, 0, 6, 0, 
        0, 0, 0, 0, 0, 0, 0 }, { 
        0, 0, 0, 0, 0, 0, 0, 0, 6, 0, 
        0, 0, 0, 0, 0, 0, 0 }, { 
        0, 0, 0, 0, 0, 1, 1, 1, 3, 1, 
        1, 1, 0, 0, 0, 0, 0 }, { 
        0, 0, 0, 0, 0, 1, 1, 1, 3, 1, 
        1, 1, 0, 0, 0, 0, 0 }, { 
        0, 0, 0, 0, 0, 1, 1, 1, 3, 1, 
        1, 1, 0, 0, 0, 0, 0 }, { 
        5, 5, 5, 5, 5, 2, 2, 2, 4, 1, 
        1, 1, 0, 0, 0, 0, 0 }, { 
        0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 
        1, 1, 0, 0, 0, 0, 0 }, 
      { 
        0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 
        1, 1, 0, 0, 0, 0, 0 }, { 
        0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 
        1, 1, 0, 0, 0, 0, 0 }, { 
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0, 0 }, { 
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0, 0 }, { 
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0, 0 }, { 
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0, 0 }, { 
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0, 0 } };
  
  private int[][] j = new int[][] { 
      { 
        7, 7, 7, 7, 7, 7, 0, 0, 0, 8, 
        8, 8, 8, 8, 8 }, { 
        7, 7, 7, 7, 7, 0, 0, 0, 0, 8, 
        8, 8, 8, 8, 8 }, { 
        7, 7, 7, 7, 7, 0, 0, 0, 0, 8, 
        8, 8, 8, 8, 8 }, { 
        7, 7, 7, 7, 7, 7, 0, 0, 0, 8, 
        8, 8, 8, 8, 8 }, { 
        7, 7, 7, 7, 7, 7, 0, 0, 0, 8, 
        8, 8, 8, 8, 8 }, { 
        7, 7, 7, 7, 7, 7, 0, 0, 0, 0, 
        0, 8, 8, 8, 8 }, { 
        7, 7, 7, 7, 7, 0, 0, 0, 0, 0, 
        0, 8, 8, 8, 8 }, { 
        0, 0, 7, 7, 7, 0, 0, 0, 0, 0, 
        0, 0, 0, 8, 8 }, { 
        0, 0, 7, 7, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 0, 0 }, { 
        0, 0, 7, 7, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 0, 0 }, 
      { 
        0, 0, 7, 7, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 0, 0 }, { 
        0, 0, 0, 0, 0, 0, 0, 9, 9, 9, 
        9, 0, 0, 0, 0 }, { 
        0, 0, 0, 0, 0, 0, 9, 9, 9, 9, 
        9, 9, 0, 0, 0 }, { 
        0, 0, 9, 9, 9, 9, 9, 9, 0, 0, 
        9, 9, 9, 9, 9 }, { 
        0, 0, 9, 9, 9, 9, 9, 9, 0, 0, 
        9, 9, 9, 9, 9 } };
  
  private int[][] k = new int[][] { 
      { 
        -1, -1, -1, -1, -1, -1, -1, -1, -1, 1, 
        1, 2, 2, 2, 2 }, { 
        -1, 1, 1, 1, -1, -1, -1, -1, -1, 2, 
        1, 1, 2, 2, 2 }, { 
        -1, -1, 1, 1, -1, -1, -1, -1, -1, 2, 
        2, 1, 2, 2, 2 }, { 
        -1, -1, -1, -1, 1, -1, -1, -1, -1, 1, 
        2, 1, 1, 2, 2 }, { 
        -1, -1, -1, -1, -1, -1, -1, -1, -1, 2, 
        2, 2, 2, 1, 2 }, { 
        -1, -1, -1, -1, -1, -1, -1, -1, -1, 1, 
        1, 1, 2, 1, 2 }, { 
        -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 
        1, 1, 1, 2, 1 }, { 
        0, 0, -1, -1, -1, -1, -1, -1, -1, -1, 
        1, 1, 1, 2, 2 }, { 
        0, 0, -1, -1, -1, -1, -1, -1, -1, -1, 
        0, 0, 0, 0, 0 }, { 
        0, 0, -1, -1, -1, -1, -1, -1, -1, -1, 
        -1, -1, 0, 0, 0 }, 
      { 
        0, 0, -1, -1, -1, -1, -1, -1, -1, -1, 
        -1, -1, -1, 0, 0 }, { 
        0, -1, -1, -1, -1, -1, -1, -1, -1, -1, 
        -1, -1, -1, 0, 0 }, { 
        0, -1, -1, -1, -1, -1, -1, -1, -1, -1, 
        -1, -1, -1, -1, 0 }, { 
        0, -1, -1, -1, -1, -1, -1, -1, -1, -1, 
        -1, -1, -1, -1, -1 }, { 
        0, 0, -1, -1, -1, -1, -1, -1, -1, -1, 
        -1, -1, -1, -1, -1 } };
  
  private int[][] l = new int[][] { 
      { 
        -1, -1, -1, -1, -1, 4, -1, -1, -1, 2, 
        -1, -1, -1, -1, -1 }, { 
        -1, -1, -1, -1, 0, -1, -1, -1, -1, 2, 
        -1, -1, -1, -1, -1 }, { 
        -1, -1, -1, -1, 0, -1, -1, -1, -1, 2, 
        -1, -1, -1, -1, -1 }, { 
        -1, -1, -1, -1, -1, 10, -1, -1, -1, 2, 
        -1, -1, -1, -1, -1 }, { 
        -1, -1, -1, -1, -1, 0, -1, -1, -1, 6, 
        1, -1, -1, -1, -1 }, { 
        -1, -1, -1, -1, -1, 4, -1, -1, -1, -1, 
        -1, 2, -1, -1, -1 }, { 
        1, 1, -1, -1, 0, -1, -1, -1, -1, -1, 
        -1, 6, 1, -1, -1 }, { 
        -1, -1, 2, -1, 4, -1, -1, -1, -1, -1, 
        -1, -1, -1, 6, 1 }, { 
        -1, -1, 2, 0, -1, -1, -1, -1, -1, -1, 
        -1, -1, -1, -1, -1 }, { 
        -1, -1, 2, 0, -1, -1, -1, -1, -1, -1, 
        -1, -1, -1, -1, -1 }, 
      { 
        -1, -1, 6, 4, -1, -1, -1, -1, -1, -1, 
        -1, -1, -1, -1, -1 }, { 
        -1, -1, -1, -1, -1, -1, -1, 20, 15, 15, 
        22, -1, -1, -1, -1 }, { 
        -1, -1, -1, -1, -1, -1, 20, 17, 13, 13, 
        19, 22, -1, -1, -1 }, { 
        -1, -1, 20, 15, 15, 15, 21, 12, -1, -1, 
        14, 23, 15, 15, 15 }, { 
        -1, -1, 14, -1, -1, -1, -1, 12, -1, -1, 
        14, -1, -1, -1, -1 } };
  
  private int[][] m = new int[][] { { -1, -1, -1, -1, -1, -1, -1 }, { -1, -1, -1, -1, -1, -1, -1 }, { -1, 1, -1, -1, -1, -1, -1 }, { -1, -1, -1, 0, -1, -1, -1 }, { -1, -1, -1, -1, -1, -1, -1 }, { -1, -1, -1, -1, -1, -1, -1 }, { -1, -1, -1, -1, -1, -1, -1 } };
  
  private int[][] n = new int[][] { 
      { 
        -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 
        -1, -1, -1, -1, -1 }, { 
        -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 
        -1, -1, -1, -1, -1 }, { 
        -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 
        -1, -1, -1, -1, -1 }, { 
        -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 
        -1, -1, -1, -1, -1 }, { 
        -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 
        -1, -1, -1, -1, -1 }, { 
        -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 
        -1, -1, -1, -1, -1 }, { 
        -1, -1, -1, -1, -1, -1, 4, -1, -1, -1, 
        -1, -1, -1, -1, -1 }, { 
        -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 
        -1, -1, -1, -1, -1 }, { 
        -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 
        -1, -1, -1, -1, -1 }, { 
        -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 
        -1, -1, -1, -1, -1 }, 
      { 
        -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 
        -1, -1, -1, -1, -1 }, { 
        -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 
        -1, -1, -1, -1, -1 }, { 
        -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 
        -1, -1, -1, -1, -1 }, { 
        -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 
        -1, -1, -1, -1, -1 }, { 
        -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 
        -1, -1, -1, -1, -1 } };
  
  private int[][] o = new int[][] { { 0, 0, 0, 0, 0, 0, 0 }, { 0, 0, 0, 0, 0, 0, 0 }, { 0, 0, 0, 0, 0, 0, 0 }, { 0, 0, 0, 0, 0, 0, 0 }, { 0, 0, 0, 0, 0, 0, 0 }, { 0, 0, 0, 0, 0, 0, 0 }, { 0, 0, 0, 0, 0, 0, 0 } };
  
  private int p = 0;
  
  private int q = 0;
  
  private int r = 0;
  
  private int s = 0;
  
  private int t = 0;
  
  private int u = 360;
  
  private int v = 300;
  
  private int w = 100;
  
  private int x = 200;
  
  private int y = 5000;
  
  private int z = 2000;
  
  private int A = 2000;
  
  private int B = 2000;
  
  private int C = 2000;
  
  private int D = 80;
  
  public static boolean a = false;
  
  public static boolean b = false;
  
  private long E = 0L;
  
  private boolean F = false;
  
  private int G = 0;
  
  private int H = 0;
  
  private int[][] I;
  
  private int J = 0;
  
  public Vector c = new Vector();
  
  private int K = 0;
  
  private int L = 0;
  
  private String M = "GMT+03:00";
  
  private int N = 0;
  
  private Vector O;
  
  private long P = 0L;
  
  private long Q = 0L;
  
  private long R = 0L;
  
  private long S = 0L;
  
  private long T = 0L;
  
  private long U = 0L;
  
  private long V = 0L;
  
  private boolean W = false;
  
  private int X = h.d.getHeight();
  
  public static k a() {
    if (d == null)
      d = new k(); 
    return d;
  }
  
  public k() {
    a(this);
    i.a();
    i.a();
    this.e = new s();
    this.e.a(this.i);
    this.e.d(this.m);
    this.e.b(8, 8);
    this.e.a(5, 5, 11, 11);
    this.e.c(i.a / 2 - 496 - 31, i.b / 2 - 16);
    this.f = new s();
    this.f.a(this.j);
    this.f.b(this.k);
    this.f.c(this.l);
    this.f.d(this.n);
    this.f.b(8, 8);
    this.f.a(0, 0, 14, 14);
    this.f.c(i.a / 2 - 496 - 31, i.b / 2 - 16);
    this.g = new s();
    this.g.a(this.o);
    this.g.b(3, 3);
    this.g.a(0, 0, 6, 6);
    this.g.c(i.a / 2 - 186 - 31, i.b / 2 - 16);
    d = this;
    this.R = 0L;
    this.S = 0L;
    this.T = 0L;
    this.U = 0L;
    this.V = 0L;
    this.Q = 0L;
    this.P = System.currentTimeMillis();
  }
  
  public final void a(int paramInt) {
    n[][] arrayOfN;
    q q;
    d d;
    switch (paramInt) {
      case 4096:
        b.a().a(b.a());
        return;
      case 8192:
        if (this.h == 2) {
          (arrayOfN = new n[4][])[0] = new n[1];
          this[1] = new n[2];
          this[2] = new n[2];
          this[3] = new n[1];
          this[0][0] = new j();
          ((j)this[0][0]).e(0);
          ((j)this[0][0]).a("Перейти:");
          this[1][0] = new t();
          String str = "X:";
          t t;
          (t = (t)this[1][0]).b(str);
          this[1][0].g(1);
          this[1][0].h(1);
          this[1][1] = new v(1, 4);
          this[1][1].i(12);
          this[1][1].g(0);
          this[1][1].h(1);
          this[2][0] = new t();
          str = "Y:";
          (t = (t)this[2][0]).b(str);
          this[2][0].g(1);
          this[2][0].h(1);
          this[2][1] = new v(1, 4);
          this[2][1].i(13);
          this[2][1].g(0);
          this[2][1].h(1);
          this[3][0] = new h();
          ((h)this[3][0]).f(22);
          ((h)this[3][0]).b("Перейти");
          int[] arrayOfInt = { 12, 13 };
          ((h)this[3][0]).a(arrayOfInt);
          arrayOfInt = new int[] { 10, 19, 0 };
          ((h)this[3][0]).a(arrayOfInt, 0);
          this[3][0].g(1);
          this[3][0].h(1);
          q q1;
          (q1 = new q()).a(70, 50);
          q1.a((String)null, this);
          b.a().a(q1);
          return;
        } 
        a();
        a(11, 26, 0, null);
        return;
      case 2:
      case 262144:
        if (((k)super).h == 0)
          ((k)super).e.d(); 
        if (((k)super).h == 1)
          ((k)super).f.d(); 
        if (((k)super).h == 2) {
          ((k)super).g.h();
          return;
        } 
        break;
      case 4:
      case 32768:
        if (((k)super).h == 0)
          ((k)super).e.c(); 
        if (((k)super).h == 1)
          ((k)super).f.c(); 
        if (((k)super).h == 2) {
          ((k)super).g.g();
          return;
        } 
        break;
      case 8:
      case 65536:
        if (((k)super).h == 0)
          ((k)super).e.a(); 
        if (((k)super).h == 1)
          ((k)super).f.a(); 
        if (((k)super).h == 2) {
          ((k)super).g.e();
          return;
        } 
        break;
      case 16:
      case 131072:
        if (((k)super).h == 0)
          ((k)super).e.b(); 
        if (((k)super).h == 1)
          ((k)super).f.b(); 
        if (((k)super).h == 2) {
          ((k)super).g.f();
          return;
        } 
        break;
      case 32:
      case 524288:
        if (((k)super).h == 0) {
          paramInt = ((k)super).e.i();
          int i = ((k)super).e.j();
          if (((k)super).m[i][paramInt] == -1) {
            byte[] arrayOfByte1 = g.a(paramInt);
            byte[] arrayOfByte2 = g.a(i);
            d d1;
            (d1 = new d(10, 5, 1)).a(arrayOfByte1);
            d1.a(arrayOfByte2);
            ((k)super).E = System.currentTimeMillis();
            byte b = 5;
            n[][] arrayOfN1;
            ((k)(arrayOfN1 = this)).N = b;
            ag.a().a(d1);
          } 
          if (((k)super).m[i][paramInt] == -2)
            super.g(); 
          if (((k)super).m[i][paramInt] >= 0) {
            super.f();
            return;
          } 
          break;
        } 
        if (((k)super).h == 1) {
          paramInt = ((k)super).f.i();
          int i = ((k)super).f.j();
          if (((k)super).n[i][paramInt] == -1) {
            byte[] arrayOfByte1 = g.a(paramInt);
            byte[] arrayOfByte2 = g.a(i);
            d d1;
            (d1 = new d(10, 5, 1)).a(arrayOfByte1);
            d1.a(arrayOfByte2);
            ((k)super).E = System.currentTimeMillis();
            byte b = 5;
            n[][] arrayOfN1;
            ((k)(arrayOfN1 = this)).N = b;
            ag.a().a(d1);
          } 
          if (((k)super).n[i][paramInt] == -2)
            super.g(); 
          if (((k)super).n[i][paramInt] >= 0) {
            super.f();
            return;
          } 
          break;
        } 
        if (((k)super).h == 2) {
          paramInt = ((k)super).g.i();
          int i = ((k)super).g.j();
          u u;
          if ((u = u.a(paramInt, i)) != null) {
            if (u.k == 0) {
              n[][] arrayOfN1;
              (arrayOfN1 = new n[7][])[0] = new n[1];
              arrayOfN1[1] = new n[2];
              arrayOfN1[2] = new n[1];
              arrayOfN1[3] = new n[1];
              arrayOfN1[4] = new n[1];
              arrayOfN1[5] = new n[1];
              arrayOfN1[6] = new n[3];
              arrayOfN1[0][0] = new j();
              ((j)arrayOfN1[0][0]).e(0);
              ((j)arrayOfN1[0][0]).a("Замок");
              arrayOfN1[1][0] = new m();
              ((m)arrayOfN1[1][0]).a(u.f.substring(u.f.indexOf(":") + 1, u.f.length()) + "\nX:" + Integer.toString(u.d) + " Y:" + Integer.toString(u.e));
              arrayOfN1[1][0].g(1);
              arrayOfN1[1][0].h(1);
              arrayOfN1[1][1] = new z();
              ((z)arrayOfN1[1][1]).e(601 + u.l);
              arrayOfN1[1][1].g(1);
              arrayOfN1[1][1].h(1);
              arrayOfN1[2][0] = new m();
              ((m)arrayOfN1[2][0]).a("Игрок: {u11|15|10|" + u.a + "|" + u.g.substring(u.g.indexOf(":") + 1, u.g.length()) + "}");
              arrayOfN1[2][0].g(0);
              arrayOfN1[2][0].h(1);
              arrayOfN1[3][0] = new m();
              ((m)arrayOfN1[3][0]).a("Раса: " + u.i);
              arrayOfN1[3][0].g(0);
              arrayOfN1[3][0].h(1);
              arrayOfN1[4][0] = new m();
              if (!u.h.substring(u.h.indexOf(":") + 1, u.h.length()).equals("-")) {
                ((m)arrayOfN1[4][0]).a("Альянс: {u11|9|10|" + u.a + "|" + u.h.substring(u.h.indexOf(":") + 1, u.h.length()) + "}");
              } else {
                ((m)arrayOfN1[4][0]).a(u.h);
              } 
              arrayOfN1[4][0].g(0);
              arrayOfN1[4][0].h(1);
              arrayOfN1[5][0] = new m();
              ((m)arrayOfN1[5][0]).a("Рейтинг: " + u.j + " очка(ов)");
              arrayOfN1[5][0].g(0);
              arrayOfN1[5][0].h(1);
              arrayOfN1[6][0] = new h();
              ((h)arrayOfN1[6][0]).f(22);
              ((h)arrayOfN1[6][0]).b("Сообщение");
              int[] arrayOfInt3 = { 10, 20, 1 };
              ((h)arrayOfN1[6][0]).a(arrayOfInt3, 2);
              ((h)arrayOfN1[6][0]).i(u.a);
              arrayOfN1[6][0].g(1);
              arrayOfN1[6][0].h(1);
              arrayOfN1[6][1] = new h();
              ((h)arrayOfN1[6][1]).f(22);
              ((h)arrayOfN1[6][1]).b("Торговля");
              int[] arrayOfInt2 = { 10, 20, 2 };
              ((h)arrayOfN1[6][1]).a(arrayOfInt2, 2);
              ((h)arrayOfN1[6][1]).i(u.a);
              arrayOfN1[6][1].g(1);
              arrayOfN1[6][1].h(1);
              arrayOfN1[6][2] = new h();
              ((h)arrayOfN1[6][2]).f(22);
              ((h)arrayOfN1[6][2]).b("Войска");
              ((h)arrayOfN1[6][2]).i(u.a);
              int[] arrayOfInt1 = { 10, 20, 3 };
              ((h)arrayOfN1[6][2]).a(this, 2);
              arrayOfN1[6][2].g(1);
              arrayOfN1[6][2].h(1);
              (q = new q()).a(100, 100);
              a((String)null, arrayOfN1);
              b.a().a(this);
              break;
            } 
            byte[] arrayOfByte1 = g.a(u.d);
            byte[] arrayOfByte2 = g.a(u.e);
            d d1;
            (d1 = new d(10, 36, 1)).a(arrayOfByte1);
            d1.a(arrayOfByte2);
            ((k)super).E = System.currentTimeMillis();
            byte b = 5;
            q q1;
            ((k)(q1 = this)).N = b;
            ag.a().a(d1);
          } 
          return;
        } 
        break;
      case 1024:
        if (((k)super).h == 0)
          b(1); 
        if (((k)super).h == 1)
          b(2); 
        if (((k)super).h == 2) {
          b(0);
          return;
        } 
        break;
      case 16384:
        super.e();
        return;
      case 2048:
        d = new d(10, 35, 1);
        ag.a().a(d);
        break;
    } 
  }
  
  public final void a(d paramd) {
    k k1;
    d d1;
    byte[] arrayOfByte2;
    k k2;
    byte[] arrayOfByte1;
    int i;
    byte[] arrayOfByte3;
    int m;
    int n;
    int i1;
    int i2;
    int i3;
    boolean bool;
    int j;
    d d2;
    switch (j = (d2 = paramd).a()) {
      case 10:
        paramd = paramd;
        this = this;
        switch (j = paramd.b()) {
          case 0:
            b.a().a(a());
            c.c();
            break;
          case 1:
            d1 = paramd;
            k1 = this;
            arrayOfByte2 = d1.c();
            arrayOfByte3 = null;
            n = 0;
            i1 = arrayOfByte2.length;
            i2 = -1;
            i3 = 0;
            bool = true;
            while (true) {
              if (n < i1) {
                byte[] arrayOfByte;
                if ((arrayOfByte = ab.b(arrayOfByte2, n)) != null) {
                  int i4;
                  switch (i4 = ab.a(arrayOfByte2, n)) {
                    case 6:
                      k1.F = !(g.a(arrayOfByte, 0) == 0);
                      break;
                    case 7:
                      i3 = g.a(arrayOfByte, 0);
                      break;
                    case 8:
                      i2 = g.a(arrayOfByte, 0);
                      break;
                    case 9:
                      arrayOfByte3 = arrayOfByte;
                      break;
                    case 10:
                      if (i3 == 1) {
                        k1.h = i2;
                        k1.a(arrayOfByte, i2);
                      } else {
                        k1.a(arrayOfByte, k1.h);
                      } 
                      bool = false;
                      break;
                    default:
                      System.out.println("Error in build buildings");
                      break;
                  } 
                  n += ab.a + arrayOfByte.length;
                  continue;
                } 
              } else {
                break;
              } 
              f(1);
              System.currentTimeMillis();
              // Byte code: goto -> 999
            } 
            if (i2 == 0) {
              for (byte b = 0; b < 49; b++)
                k1.m[b / 7][b % 7] = arrayOfByte3[b]; 
            } else if (i2 == 1) {
              for (byte b = 0; b < 'á'; b++)
                k1.n[b / 15][b % 15] = arrayOfByte3[b]; 
            } 
            if (i3 == 1)
              k1.h = i2; 
            if (bool) {
              byte[] arrayOfByte = new byte[0];
              k1.e.a(arrayOfByte);
              k1.f.a(arrayOfByte);
            } 
            f(1);
            System.currentTimeMillis();
            // Byte code: goto -> 999
          case 2:
            k2 = k1;
            k1 = this;
            arrayOfByte1 = k2.c();
            n = 0;
            i1 = 0;
            i2 = 0;
            m = 0;
            i3 = arrayOfByte1.length;
            while (true) {
              if (m < i3) {
                byte[] arrayOfByte;
                if ((arrayOfByte = ab.b(arrayOfByte1, m)) != null) {
                  int i4;
                  switch (i4 = ab.a(arrayOfByte1, m)) {
                    case 3:
                      System.out.println("Active farm");
                      n = g.b(arrayOfByte, 0);
                      break;
                    case 4:
                      i1 = g.b(arrayOfByte, 0);
                      break;
                    case 5:
                      i2 = g.b(arrayOfByte, 0);
                      break;
                    case 10:
                      k1.a(arrayOfByte, k1.h);
                      break;
                    default:
                      System.out.println("Error in build buildings");
                      break;
                  } 
                  m += ab.a + arrayOfByte.length;
                  continue;
                } 
              } else {
                break;
              } 
              f(2);
              System.currentTimeMillis();
              // Byte code: goto -> 999
            } 
            System.out.println("activeFarm -> " + n);
            System.out.println("where -> " + i1);
            System.out.println("state -> " + i2);
            if (i2 == 0) {
              if (k1.h == 0) {
                k1.m[i1 / 7][i1 % 7] = -2;
              } else if (k1.h == 1) {
                k1.n[i1 / 15][i1 % 15] = -2;
              } 
              b.a().a(k1);
            } else if (i2 == 2) {
              System.out.println("No resource to build");
            } else if (i2 == 1) {
              System.out.println("Territory is busy");
            } 
            f(2);
            System.currentTimeMillis();
            // Byte code: goto -> 999
          case 6:
            d((d)k1);
            f(6);
            break;
          case 8:
            f(8);
            System.currentTimeMillis();
            e((d)k1);
            break;
          case 10:
            j((d)k1);
            break;
          case 11:
            k((d)k1);
            break;
          case 17:
            b((d)k1);
            break;
          case 20:
            c((d)k1);
            break;
        } 
        return;
      case 11:
        k1 = k1;
        this = this;
        switch (i = k1.b()) {
          case 4:
            f((d)k1);
            break;
          case 5:
            i((d)k1);
            break;
          case 6:
            g((d)k1);
            break;
          case 7:
            h((d)k1);
            break;
        } 
        return;
      case 12:
        k1 = k1;
        (this = this).l((d)k1);
        break;
    } 
  }
  
  public final void a(int paramInt, String[] paramArrayOfString, int[] paramArrayOfint1, int[] paramArrayOfint2, boolean paramBoolean) {
    if (paramBoolean) {
      a(paramArrayOfint2[0], paramArrayOfint2[1], paramArrayOfint2[2], null);
      return;
    } 
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    for (paramBoolean = false; paramBoolean < paramArrayOfString.length; paramBoolean++) {
      byte[] arrayOfByte1 = g.a(paramArrayOfString[paramBoolean]);
      ab.a(paramArrayOfint1[paramBoolean], this, arrayOfByte1);
    } 
    System.out.println("SEND TLV COLECT +++!!!!! channel: " + paramInt + "snackId " + paramArrayOfint2[0] + "|" + paramArrayOfint2[1]);
    byte[] arrayOfByte = toByteArray();
    int j = paramArrayOfint2[1];
    paramInt = paramArrayOfint2[0];
    int i = paramInt;
    if (arrayOfByte == null) {
      System.out.println("Error in sendSnacCommand");
      return;
    } 
    ag.a().a(new d(i, paramInt, j, arrayOfByte));
  }
  
  public static void a(int paramInt1, int paramInt2, int paramInt3, byte[] paramArrayOfbyte) {
    d d = new d(paramInt1, paramInt2, 1);
    if (paramArrayOfbyte != null) {
      ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
      ab.a(paramInt3, byteArrayOutputStream, paramArrayOfbyte);
      d.a(byteArrayOutputStream.toByteArray());
    } else {
      byte[] arrayOfByte = new byte[4];
      ab.a(paramInt3, arrayOfByte);
      d.a(arrayOfByte);
    } 
    ag.a().a(d);
  }
  
  public static void a(int[] paramArrayOfint) {
    d d = new d(10, 27, 1);
    byte[] arrayOfByte = new byte[paramArrayOfint.length << 1];
    for (byte b = 0; b < paramArrayOfint.length; b++) {
      int j = paramArrayOfint[b];
      int i = b << 1;
      byte[] arrayOfByte1;
      g.a(arrayOfByte1 = arrayOfByte, i, j, true);
    } 
    d.a(arrayOfByte);
    ag.a().a(d);
    System.out.println("REQUESTING FOR PICTURE LOADING!!!");
  }
  
  private static void b(d paramd) {
    try {
      byte[] arrayOfByte = paramd.c();
      boolean bool1 = true;
      int i = 0;
      int j = arrayOfByte.length;
      boolean bool2 = true;
      while (i < j) {
        byte[] arrayOfByte2;
        Image image;
        byte[] arrayOfByte1;
        if ((arrayOfByte1 = ab.b(arrayOfByte, i)) == null)
          return; 
        int m;
        switch (m = ab.a(arrayOfByte, i)) {
          case 4:
            bool2 = false;
            break;
          case 5:
            m = g.b(arrayOfByte1, arrayOfByte1.length - 2);
            arrayOfByte2 = new byte[arrayOfByte1.length - 2];
            System.arraycopy(arrayOfByte1, 0, arrayOfByte2, 0, arrayOfByte1.length - 2);
            if (bool2)
              c.a(arrayOfByte2, m); 
            image = Image.createImage(arrayOfByte1, 0, arrayOfByte1.length - 2);
            c.a(m, image);
            break;
          case 6:
            bool1 = false;
            break;
          default:
            System.out.println("Error in getBuildingInform");
            break;
        } 
        i += ab.a + arrayOfByte1.length;
      } 
      if (c.r != null)
        synchronized (c.r) {
          c.r = null;
        }  
      if (bool1)
        ((q)b.a().b()).a(); 
      return;
    } catch (Exception exception) {
      System.err.println(exception);
      System.out.println("Getting image ERROR");
      return;
    } 
  }
  
  public final void b() {
    try {
      c.b();
    } catch (IOException iOException) {}
    b b = b.a();
    g g;
    (g = g.a()).b();
    b.a((f)g);
    byte[] arrayOfByte = new byte[0];
    x x = new x(arrayOfByte, 4);
    ag.a().a(x);
    ag.a().e();
    if (this.O != null) {
      this.O.removeAllElements();
      this.O = null;
    } 
  }
  
  private void f() {
    int i = 0;
    if (this.h == 0) {
      i = this.e.i();
      int j;
      i = (j = this.e.j()) * 7 + i;
    } else if (this.h == 1) {
      i = this.f.i();
      int j;
      i = (j = this.f.j()) * 15 + i;
    } 
    byte[] arrayOfByte = g.a(i);
    byte b = 7;
    (this = this).N = b;
    d d;
    (d = new d(10, 7, 1)).a(arrayOfByte);
    ag.a().a(this);
  }
  
  public static void b(int paramInt) {
    byte[] arrayOfByte = new byte[4];
    if (paramInt < 2) {
      ab.a(paramInt, arrayOfByte);
      d d;
      (d = new d(10, 4, 1)).a(arrayOfByte);
      ag.a().a(d);
    } 
    if (paramInt == 2) {
      d d = new d(10, 8, 1);
      ag.a().a(d);
    } 
  }
  
  private void f(int paramInt) {
    if (this.N == paramInt)
      this.N = 0; 
  }
  
  private void a(byte[] paramArrayOfbyte, int paramInt) {
    switch (paramInt) {
      default:
        this.e.a(paramArrayOfbyte);
        return;
      case 1:
        break;
    } 
    this.f.a(paramArrayOfbyte);
  }
  
  private void c(d paramd) {
    try {
      byte[] arrayOfByte;
      if ((arrayOfByte = ab.b(arrayOfByte = paramd.c(), 0)) == null)
        return; 
      int j = g.a(this, 0);
      String str2 = g.b(this, 1, j);
      int i = j + 1;
      j = g.a(this, i);
      String str1 = g.b(this, ++i, j);
      System.out.println("smsText " + this);
      MessageConnection messageConnection;
      TextMessage textMessage;
      (textMessage = (TextMessage)(messageConnection = (MessageConnection)Connector.open(str2)).newMessage("text")).setPayloadText(this);
      messageConnection.send((Message)textMessage);
      a(11, 41, 1, null);
      return;
    } catch (Exception exception) {
      System.out.println("Cannot send...");
      return;
    } 
  }
  
  private void d(d paramd) {
    byte[] arrayOfByte = paramd.c();
    int i = 0;
    int j = arrayOfByte.length;
    while (i < j) {
      byte[] arrayOfByte1;
      if ((arrayOfByte1 = ab.b(arrayOfByte, i)) == null)
        return; 
      int m;
      switch (m = ab.a(arrayOfByte, i)) {
        case 10:
          this.p = (int)g.c(arrayOfByte1, 0);
          this.q = (int)g.c(arrayOfByte1, 4);
          this.r = (int)g.c(arrayOfByte1, 8);
          this.s = (int)g.c(arrayOfByte1, 12);
          this.t = (int)g.c(arrayOfByte1, 16);
          break;
        case 11:
          this.u = g.b(arrayOfByte1, 0);
          this.v = g.b(arrayOfByte1, 2);
          this.w = g.b(arrayOfByte1, 4);
          this.x = g.b(arrayOfByte1, 6);
          this.y = g.b(arrayOfByte1, 8);
          break;
        case 12:
          this.z = (int)g.c(arrayOfByte1, 0);
          this.A = (int)g.c(arrayOfByte1, 4);
          this.B = (int)g.c(arrayOfByte1, 8);
          this.C = (int)g.c(arrayOfByte1, 12);
          this.D = (int)g.c(arrayOfByte1, 16);
          break;
        default:
          System.out.println("Error in get resources");
          break;
      } 
      i += ab.a + arrayOfByte1.length;
    } 
    this.R = 0L;
    this.S = 0L;
    this.T = 0L;
    this.U = 0L;
    this.V = 0L;
    this.Q = 0L;
    this.P = System.currentTimeMillis();
  }
  
  public final void a(int paramInt1, int paramInt2) {
    byte b = 18;
    k k1;
    (k1 = this).N = b;
    d d = new d(10, 18, 1);
    paramInt1 = paramInt1;
    b = 0;
    byte[] arrayOfByte1;
    byte[] arrayOfByte2;
    g.a(arrayOfByte2 = arrayOfByte1 = new byte[4], b, paramInt1, true);
    paramInt1 = paramInt2;
    b = 2;
    g.a(arrayOfByte2 = arrayOfByte1, b, paramInt1, true);
    a(arrayOfByte1);
    ag.a().a(this);
  }
  
  private void e(d paramd) {
    System.currentTimeMillis();
    byte[] arrayOfByte = paramd.c();
    int i = 0;
    int j = arrayOfByte.length;
    int m = 0;
    int n = 0;
    u.a();
    for (byte b = 0; b < 7; b++) {
      for (byte b1 = 0; b1 < 7; b1++)
        this.o[b][b1] = 0; 
    } 
    System.currentTimeMillis();
    while (i < j) {
      byte[] arrayOfByte1;
      if ((arrayOfByte1 = ab.b(arrayOfByte, i)) == null)
        return; 
      int i1;
      switch (i1 = ab.a(arrayOfByte, i)) {
        case 16:
          m = g.b(arrayOfByte1, 0);
          n = g.b(arrayOfByte1, 2);
          break;
        case 17:
          try {
            int i2 = (int)g.c(arrayOfByte1, 0);
            int i3 = g.b(arrayOfByte1, 4);
            int i4 = g.b(arrayOfByte1, 6);
            int i5 = g.b(arrayOfByte1, 8);
            int i6 = g.b(arrayOfByte1, 10);
            int i7 = g.b(arrayOfByte1, 12);
            i1 = g.a(arrayOfByte1, 14);
            int i8 = g.a(arrayOfByte1, 15);
            int i9 = g.a(arrayOfByte1, 16);
            String str3 = g.b(arrayOfByte1, 17, i1);
            i1 += 17;
            String str4 = g.b(arrayOfByte1, i1, i8);
            i1 += i8;
            String str2 = g.b(arrayOfByte1, i1, i9);
            i1 += i9;
            String str1 = g.b(arrayOfByte1, i1, arrayOfByte1.length - i1);
            if (i7 < 300 && i6 == 10) {
              i6 = 28;
            } else if (i7 < 1000 && i6 == 10) {
              i6 = 10;
            } else if (i7 >= 1000 && i6 == 10) {
              i6 = 29;
            } 
            this.o[i4 - n][i3 - m] = i6;
            if (c.a(i6 + 601) == null || c.a(i6 + 601) == c.q) {
              int[] arrayOfInt;
              (arrayOfInt = new int[1])[0] = i6 + 601;
              a(arrayOfInt);
            } 
            u u;
            (u = new u()).a = i2;
            u.b = i3 - m;
            u.c = i4 - n;
            u.d = i3;
            u.e = i4;
            u.f = str3;
            u.g = str4;
            u.h = str2;
            u.i = str1;
            u.j = i7;
            u.k = i5;
            u.l = i6;
            u.a(u);
          } catch (Exception exception) {
            System.err.println("e - > " + exception);
          } 
          break;
        case 18:
          try {
            int i2 = g.b(arrayOfByte1, 0);
            int i3 = g.b(arrayOfByte1, 2);
            this.g.a(i2, i3);
          } catch (Exception exception) {
            System.err.println("e - > " + exception);
          } 
          break;
        default:
          System.out.println("Error in getNeighbourhoodMap");
          break;
      } 
      i += ab.a + arrayOfByte1.length;
    } 
    System.currentTimeMillis();
    this.h = 2;
    b.a().a(a());
    System.currentTimeMillis();
  }
  
  private void g() {
    // Byte code:
    //   0: aload_0
    //   1: invokestatic currentTimeMillis : ()J
    //   4: putfield E : J
    //   7: aload_0
    //   8: iconst_3
    //   9: istore_2
    //   10: dup
    //   11: astore_1
    //   12: iload_2
    //   13: putfield N : I
    //   16: iconst_0
    //   17: istore_1
    //   18: aload_0
    //   19: getfield h : I
    //   22: ifne -> 51
    //   25: aload_0
    //   26: getfield e : Ls;
    //   29: invokevirtual i : ()I
    //   32: istore_1
    //   33: aload_0
    //   34: getfield e : Ls;
    //   37: invokevirtual j : ()I
    //   40: dup
    //   41: istore_0
    //   42: bipush #7
    //   44: imul
    //   45: iload_1
    //   46: iadd
    //   47: istore_1
    //   48: goto -> 82
    //   51: aload_0
    //   52: getfield h : I
    //   55: iconst_1
    //   56: if_icmpne -> 82
    //   59: aload_0
    //   60: getfield f : Ls;
    //   63: invokevirtual i : ()I
    //   66: istore_1
    //   67: aload_0
    //   68: getfield f : Ls;
    //   71: invokevirtual j : ()I
    //   74: dup
    //   75: istore_0
    //   76: bipush #15
    //   78: imul
    //   79: iload_1
    //   80: iadd
    //   81: istore_1
    //   82: iload_1
    //   83: invokestatic a : (I)[B
    //   86: astore_0
    //   87: getstatic java/lang/System.out : Ljava/io/PrintStream;
    //   90: ldc 'Get Build Rest Time'
    //   92: invokevirtual println : (Ljava/lang/String;)V
    //   95: new d
    //   98: dup
    //   99: bipush #10
    //   101: iconst_3
    //   102: iconst_1
    //   103: invokespecial <init> : (III)V
    //   106: dup
    //   107: astore_1
    //   108: aload_0
    //   109: invokevirtual a : ([B)V
    //   112: invokestatic a : ()Lag;
    //   115: aload_1
    //   116: invokevirtual a : (Lx;)V
    //   119: return
  }
  
  private void f(d paramd) {
    byte[] arrayOfByte = paramd.c();
    int i = 0;
    int j = arrayOfByte.length;
    while (i < j) {
      byte[] arrayOfByte1;
      if ((arrayOfByte1 = ab.b(arrayOfByte, i)) == null)
        return; 
      int m;
      switch (m = ab.a(arrayOfByte, i)) {
        case 1:
          System.out.println("***NEW MESSAGE NOTIFICATION***");
          break;
        case 2:
          System.out.println(g.b(arrayOfByte1, 0, arrayOfByte1.length));
          b.a().a(this);
          return;
        case 3:
          i.a().a(g.b(arrayOfByte1, 0, arrayOfByte1.length), 0);
          i.a().a(o.a());
          i.a().b();
          return;
        default:
          System.out.println("Error in getNewMessageNotification");
          break;
      } 
      i += ab.a + arrayOfByte1.length;
    } 
  }
  
  private void g(d paramd) {
    n[][] arrayOfN;
    byte[] arrayOfByte = paramd.c();
    int i = 0;
    int j = arrayOfByte.length;
    System.out.println("len " + j);
    byte b = 0;
    j j1;
    (j1 = new j()).e(0);
    if (this.G != 2) {
      j1.a("Сообщения");
    } else {
      j1.a("Отчеты");
    } 
    j1 = null;
    String str = null;
    while (i < j) {
      int n;
      int i1;
      int i2;
      j j2;
      StringBuffer stringBuffer;
      m m1;
      byte[] arrayOfByte1;
      if ((arrayOfByte1 = ab.b(arrayOfByte, i)) == null)
        return; 
      int m = ab.a(arrayOfByte, i);
      System.currentTimeMillis();
      switch (m) {
        case 4:
          n = g.b(arrayOfByte1, 0);
          m = g.b(arrayOfByte1, 2);
          i1 = g.b(arrayOfByte1, 4);
          if ((i2 = m / 10) == 1 && m >= 10)
            i2++; 
          arrayOfN = new n[n * 3 + ((m > n) ? 2 : 0) + 1][];
          (j2 = new j()).e(0);
          arrayOfN[b] = new n[1];
          arrayOfN[b++][0] = j2;
          j2.a("Сообщения " + m);
          stringBuffer = new StringBuffer();
          m1 = new m();
          if (i2 < 4) {
            for (byte b1 = 0; b1 < i2; b1++) {
              if (i1 != b1) {
                stringBuffer.append("{u11|6|5|" + b1 + "|" + (b1 + 1) + "}  ");
              } else {
                stringBuffer.append((b1 + 1) + " ");
              } 
            } 
          } else if (i1 < 2) {
            for (byte b1 = 0; b1 < 3; b1++) {
              if (i1 != b1) {
                stringBuffer.append("{u11|6|5|" + b1 + "|" + (b1 + 1) + "}  ");
              } else {
                stringBuffer.append((b1 + 1) + " ");
              } 
            } 
            stringBuffer.append("... ");
            stringBuffer.append("{u11|6|5|" + (m / 10) + "|" + (m / 10 + 1) + "}");
            stringBuffer.append("\n");
          } else if (i1 + 3 <= i2) {
            stringBuffer.append("{u11|6|5|0|<} ");
            for (int i3 = i1 - 1; i3 < i1 + 2; i3++) {
              if (i1 != i3) {
                stringBuffer.append("{u11|6|5|" + i3 + "|" + (i3 + 1) + "}  ");
              } else {
                stringBuffer.append((i3 + 1) + " ");
              } 
            } 
            stringBuffer.append("... ");
            stringBuffer.append("{u11|6|5|" + (m / 10) + "|" + (m / 10 + 1) + "}  ");
            stringBuffer.append("\n");
          } else if (i1 + 2 >= i2) {
            stringBuffer.append("{u11|6|5|0|<} ");
            for (int i3 = i2 - 3; i3 <= i2; i3++) {
              if (i1 != i3) {
                stringBuffer.append("{u11|6|5|");
                stringBuffer.append(i3 + "|" + (i3 + 1) + "}  ");
              } else {
                stringBuffer.append((i3 + 1) + " ");
              } 
            } 
          } 
          if (m > n) {
            str = stringBuffer.toString();
            m1.a(str);
            arrayOfN[b] = new n[1];
            arrayOfN[b++][0] = m1;
          } 
          break;
        case 5:
          try {
            m = 0;
            i1 = (int)g.c(arrayOfByte1, 0);
            m += 4;
            String str1 = null;
            if (this.G != 2) {
              n = g.b(arrayOfByte1, 4);
              str1 = g.b(arrayOfByte1, 6, n);
              m = n + 6;
            } 
            n = g.b(arrayOfByte1, m);
            m += 2;
            String str2 = g.b(arrayOfByte1, m, n);
            m += n;
            n = g.b(arrayOfByte1, m);
            m += 2;
            String str3 = g.b(arrayOfByte1, m, n);
            m += n;
            m = g.b(arrayOfByte1, m);
            m m2;
            (m2 = new m()).a(str2);
            (m2 = new m()).a(str3);
            m2.g(2);
            t t = new t();
            if (this.G != 2) {
              t t1;
              if (this.G != 1) {
                String str4 = "От : " + str1;
                (t1 = t).b(str4);
              } else {
                String str4 = "Кому : " + t1;
                (t1 = t).b(str4);
              } 
              t.g(0);
            } 
            m m3 = new m();
            if (m == 0) {
              if (this.G != 2) {
                m3.a("{i419} {u11|6|1|" + i1 + "|" + str2 + "}");
              } else {
                m3.a("{i420} {u11|6|1|" + i1 + "|" + str2 + "}");
              } 
            } else {
              m3.a("{u11|6|1|" + i1 + "|" + str2 + "}");
            } 
            arrayOfN[b] = new n[1];
            arrayOfN[b][0] = m3;
            b++;
            if (this.G != 2) {
              arrayOfN[b] = new n[2];
              arrayOfN[b][0] = t;
              arrayOfN[b][1] = m2;
            } else {
              arrayOfN[b] = new n[1];
              arrayOfN[b][0] = m2;
            } 
            arrayOfN[++b] = new n[1];
            j j3;
            (j3 = new j()).e(1);
            arrayOfN[b][0] = j3;
            b++;
          } catch (Exception exception) {
            System.err.println("e - > " + exception);
          } 
          break;
        case 6:
          System.out.println("Subject List have a Scrolling!!!!");
          break;
        default:
          System.out.println("Error in getNeighbourhoodMap");
          break;
      } 
      i += ab.a + arrayOfByte1.length;
    } 
    if (str != null) {
      arrayOfN[b] = new n[1];
      m m;
      (m = new m()).a(str);
      arrayOfN[b][0] = m;
    } 
    q q = new q();
    System.currentTimeMillis();
    System.currentTimeMillis();
    q.a((String)null, arrayOfN);
    System.currentTimeMillis();
    if (this.O != null) {
      this.O.removeAllElements();
      this.O = null;
    } 
    b.a().a(q);
  }
  
  private void h(d paramd) {
    System.out.println("Answer to msg!!!");
    int i = 0;
    byte[] arrayOfByte;
    int j = (arrayOfByte = paramd.c()).length;
    while (i < j) {
      t t2;
      v v2;
      t t1;
      v v1;
      h h;
      q q;
      int m;
      String str1;
      n[][] arrayOfN;
      j j1;
      t t3;
      int[] arrayOfInt1;
      String str2;
      int[] arrayOfInt2;
      String str3;
      byte[] arrayOfByte1;
      if ((arrayOfByte1 = ab.b(arrayOfByte, i)) == null)
        return; 
      int i1;
      switch (i1 = ab.a(arrayOfByte, i)) {
        case 1:
          i = g.a(arrayOfByte1, 0);
          str2 = g.b(arrayOfByte1, 1, i);
          m = i + 1;
          i = g.a(arrayOfByte1, m);
          str1 = g.b(arrayOfByte1, ++m, i);
          a(str2, str1);
          return;
        case 2:
          i = g.a(arrayOfByte1, 0);
          str2 = g.b(arrayOfByte1, 1, i);
          (arrayOfN = new n[6][])[0] = new n[1];
          (j1 = new j()).e(0);
          if (this.G != 2) {
            j1.a("Сообщениe");
          } else {
            j1.a("Отчет");
          } 
          arrayOfN[0][0] = j1;
          arrayOfN[1] = new n[1];
          str3 = "Кому:";
          (t3 = t2 = new t()).b(str3);
          g(0);
          arrayOfN[1][0] = this;
          arrayOfN[2] = new n[1];
          (v2 = new v(5, 20)).i(1);
          arrayOfN[2][0] = this;
          arrayOfN[3] = new n[1];
          str3 = "Тема:";
          (t3 = t1 = new t()).b(str3);
          g(0);
          arrayOfN[3][0] = this;
          arrayOfN[4] = new n[1];
          (v1 = new v(4, 20)).a(str2);
          i(2);
          arrayOfN[4][0] = this;
          arrayOfN[5] = new n[1];
          (h = new h()).f(22);
          b("Переслать");
          g(1);
          arrayOfInt1 = new int[] { 11, 7, 1 };
          arrayOfInt2 = new int[] { 1, 2 };
          a(arrayOfInt1, 0);
          a(arrayOfInt2);
          arrayOfN[5][0] = this;
          (q = new q()).a((String)null, arrayOfN);
          b.a().a(this);
          return;
      } 
      int n = arrayOfInt1 + ab.a + str3.length;
    } 
  }
  
  public final void a(String paramString1, String paramString2) {
    n[][] arrayOfN = new n[8][];
    j j = new j();
    this[0] = new n[1];
    this[0][0] = j;
    j.a("Сообщение");
    String str = "Кому:";
    t t3;
    t t4;
    (t4 = t3 = new t()).b(str);
    t3.g(0);
    this[1] = new n[1];
    this[1][0] = t3;
    v v2;
    (v2 = new v(5, 20)).i(1);
    v2.a(paramString1);
    this[2] = new n[1];
    this[2][0] = v2;
    str = "Тема:";
    t t2;
    (t4 = t2 = new t()).b(str);
    t2.g(0);
    this[3] = new n[1];
    this[3][0] = t2;
    v v1;
    (v1 = new v(4, 20)).i(3);
    v1.a(paramString2);
    this[4] = new n[1];
    this[4][0] = v1;
    str = "Текст:";
    t t1;
    (t4 = t1 = new t()).b(str);
    t1.g(0);
    this[5] = new n[1];
    this[5][0] = t1;
    af af;
    (af = new af()).i(4);
    af.b(true);
    this[6] = new n[1];
    this[6][0] = af;
    int[] arrayOfInt1 = { 11, 5, 0 };
    int[] arrayOfInt2 = { 1, 3, 4 };
    h h;
    (h = new h()).f(22);
    h.b("Отправить");
    h.a(arrayOfInt2);
    h.a(arrayOfInt1, 0);
    this[7] = new n[1];
    this[7][0] = h;
    q q1;
    (q1 = new q()).a((String)null, this);
    boolean bool = true;
    q q2;
    (q2 = q1).b = bool;
    b.a().a(q1);
  }
  
  public final void c(int paramInt) {
    this.G = paramInt;
    byte[] arrayOfByte = g.a(paramInt);
    a(11, 6, 0, this);
  }
  
  private void i(d paramd) {
    byte[] arrayOfByte = paramd.c();
    int i = 0;
    int j = arrayOfByte.length;
    int m = 0;
    String str1 = null;
    String str2 = null;
    String str3 = null;
    String str4 = null;
    while (i < j) {
      byte[] arrayOfByte1;
      if ((arrayOfByte1 = ab.b(arrayOfByte, i)) == null)
        return; 
      int n;
      switch (n = ab.a(arrayOfByte, i)) {
        case 1:
          str1 = g.b(arrayOfByte1, 0, arrayOfByte1.length);
          break;
        case 2:
          str2 = g.b(arrayOfByte1, 0, arrayOfByte1.length);
          break;
        case 3:
          str3 = g.b(arrayOfByte1, 0, arrayOfByte1.length);
          break;
        case 4:
          str4 = g.b(arrayOfByte1, 0, arrayOfByte1.length);
          break;
        case 5:
          break;
        case 6:
          m = (int)g.c(arrayOfByte1, 0);
          break;
        default:
          System.out.println("Error in getOneFullMessage");
          break;
      } 
      i += ab.a + arrayOfByte1.length;
    } 
    try {
      byte b2 = 0;
      n[][] arrayOfN;
      (arrayOfN = new n[(this.G != 2) ? 6 : 5][])[0] = new n[1];
      j j1;
      (j1 = new j()).e(0);
      if (this.G != 2) {
        j1.a("Сообщениe");
      } else {
        j1.a("Отчет");
      } 
      b2++;
      arrayOfN[0][0] = j1;
      if (this.G != 2) {
        arrayOfN[1] = new n[1];
        m m2;
        (m2 = new m()).a("От : {u11|15|0|" + m + "|" + str1 + "}");
        b2++;
        arrayOfN[1][0] = m2;
      } 
      arrayOfN[b2] = new n[1];
      m m1;
      (m1 = new m()).a("Тема : " + str2);
      arrayOfN[b2++][0] = m1;
      arrayOfN[b2] = new n[1];
      (m1 = new m()).a(str4);
      arrayOfN[b2++][0] = m1;
      arrayOfN[b2] = new n[1];
      (m1 = new m()).a("\n" + str3);
      arrayOfN[b2++][0] = m1;
      byte b1 = 0;
      if (this.G != 2) {
        arrayOfN[b2] = new n[4];
        h h1;
        (h1 = new h()).f(22);
        h1.b("Ответить");
        int[] arrayOfInt1 = { 11, 6, 6 };
        h1.a(arrayOfInt1, 1);
        b1++;
        arrayOfN[b2][0] = h1;
        (h1 = new h()).f(22);
        h1.b("Переписка");
        arrayOfInt1 = new int[] { 11, 6, 10 };
        h1.a(arrayOfInt1, 2);
        h1.i(m);
        arrayOfN[b2][(arrayOfN[b2]).length - 1] = h1;
      } else {
        arrayOfN[b2] = new n[2];
      } 
      h h;
      (h = new h()).f(22);
      h.b("Удалить");
      int[] arrayOfInt = { 11, 6, 2 };
      h.a(arrayOfInt, 1);
      arrayOfN[b2][b1++] = h;
      (h = new h()).f(22);
      h.b("Переслать");
      arrayOfInt = new int[] { 11, 6, 7 };
      h.a(arrayOfInt, 1);
      arrayOfN[b2][b1] = h;
      if (this.O == null)
        this.O = new Vector(); 
      this.O.addElement((q)b.a().b());
      System.out.println(" Back screen = " + b.a().b().toString());
      q q1;
      (q1 = new q()).a((String)null, arrayOfN);
      boolean bool = true;
      q q2;
      (q2 = this).b = bool;
      b.a().a(this);
      return;
    } catch (Exception exception) {
      System.err.println("getOneFullMessage : " + exception);
      return;
    } 
  }
  
  private void j(d paramd) {
    byte[] arrayOfByte = paramd.c();
    int i = 0;
    int j = arrayOfByte.length;
    while (i < j) {
      byte[] arrayOfByte1;
      if ((arrayOfByte1 = ab.b(arrayOfByte, i)) == null)
        return; 
      int m;
      switch (m = ab.a(arrayOfByte, i)) {
        case 0:
          this.H = g.b(arrayOfByte1, 0);
          this.I = new int[this.H][4];
          break;
        case 1:
          this.I[m - 1][0] = g.b(arrayOfByte1, 0);
          this.I[m - 1][1] = g.b(arrayOfByte1, 2);
          this.I[m - 1][2] = g.b(arrayOfByte1, 4);
          this.I[m - 1][3] = g.b(arrayOfByte1, 6);
          this.J = this.I[m - 1][2];
          break;
        case 2:
          this.I[m - 1][0] = g.b(arrayOfByte1, 0);
          this.I[m - 1][1] = g.b(arrayOfByte1, 2);
          this.I[m - 1][2] = g.b(arrayOfByte1, 4);
          this.I[m - 1][3] = g.b(arrayOfByte1, 6);
          break;
        case 3:
          this.I[m - 1][0] = g.b(arrayOfByte1, 0);
          this.I[m - 1][1] = g.b(arrayOfByte1, 2);
          this.I[m - 1][2] = g.b(arrayOfByte1, 4);
          this.I[m - 1][3] = g.b(arrayOfByte1, 6);
          break;
        case 4:
          this.I[m - 1][0] = g.b(arrayOfByte1, 0);
          this.I[m - 1][1] = g.b(arrayOfByte1, 2);
          this.I[m - 1][2] = g.b(arrayOfByte1, 4);
          this.I[m - 1][3] = g.b(arrayOfByte1, 6);
          break;
        case 5:
          this.I[m - 1][0] = g.b(arrayOfByte1, 0);
          this.I[m - 1][1] = g.b(arrayOfByte1, 2);
          this.I[m - 1][2] = g.b(arrayOfByte1, 4);
          this.I[m - 1][3] = g.b(arrayOfByte1, 6);
          break;
        case 6:
          this.I[m - 1][0] = g.b(arrayOfByte1, 0);
          this.I[m - 1][1] = g.b(arrayOfByte1, 2);
          this.I[m - 1][2] = g.b(arrayOfByte1, 4);
          this.I[m - 1][3] = g.b(arrayOfByte1, 6);
          break;
        default:
          if (m < 0 || m > this.H) {
            System.out.println("Error in getOneFullMessage");
            break;
          } 
          this.I[m - 1][0] = g.b(arrayOfByte1, 0);
          this.I[m - 1][1] = g.b(arrayOfByte1, 2);
          this.I[m - 1][2] = g.b(arrayOfByte1, 4);
          this.I[m - 1][3] = g.b(arrayOfByte1, 6);
          break;
      } 
      i += ab.a + arrayOfByte1.length;
    } 
  }
  
  private void k(d paramd) {
    byte[] arrayOfByte = paramd.c();
    int i = 0;
    int j = arrayOfByte.length;
    System.out.println("!!!!!!!!!!!!!!!tchangeTimeZone");
    while (i < j) {
      byte[] arrayOfByte1;
      if ((arrayOfByte1 = ab.b(arrayOfByte, i)) == null)
        return; 
      int m = ab.a(arrayOfByte, i);
      System.out.println("tlvType -> " + m);
      switch (m) {
        case 0:
          System.out.println("!!!!!!!!!!!!!!!timeZone = " + this.M);
          this.M = g.b(arrayOfByte1, 0, arrayOfByte1.length);
          System.out.println("timeZone = " + this.M);
          break;
      } 
      i += ab.a + arrayOfByte1.length;
    } 
  }
  
  private void l(d paramd) {
    byte[] arrayOfByte1;
    b = true;
    byte[] arrayOfByte2 = paramd.c();
    int i = 0;
    int j = arrayOfByte2.length;
    boolean bool = false;
    Vector vector = new Vector();
    Vector vector1 = new Vector();
    int m = 0;
    int n = 0;
    byte b1 = 100;
    byte b2 = 100;
    int i1 = 2;
    while (i < j) {
      String str1;
      String str2;
      int i4;
      int i5;
      e e;
      int i6;
      String str3;
      int i7;
      String str4;
      byte[] arrayOfByte;
      if ((arrayOfByte = ab.b(arrayOfByte2, i)) == null)
        return; 
      int i3;
      switch (i3 = ab.a(arrayOfByte2, i)) {
        case 4:
          g.b(arrayOfByte, 0, arrayOfByte.length);
          break;
        case 5:
        case 12:
          try {
            if (i3 == 12) {
              i3 = g.a(arrayOfByte, 0);
              j j1 = new j();
              if (i3 == 0) {
                String str = g.b(arrayOfByte, 1, arrayOfByte.length - 1);
                j1.a(str);
              } 
              j1.e(i3);
              vector.addElement(j1);
            } 
            if (vector.size() == 0)
              continue; 
            n[] arrayOfN1 = new n[vector.size()];
            for (byte b = 0; b < vector.size(); b++)
              arrayOfN1[b] = vector.elementAt(b); 
            vector1.addElement(arrayOfN1);
            vector.removeAllElements();
          } catch (Exception exception) {
            System.err.println("ERROR windowConstructParser.NextBlock : " + exception);
          } 
          break;
        case 6:
          try {
            t t;
            byte b = 0;
            int i8 = g.a(arrayOfByte, 0);
            b++;
            int i9 = g.a(arrayOfByte, 1);
            b++;
            i3 = g.b(arrayOfByte, 2);
            b += 2;
            if (i3 > 0) {
              m = g.b(arrayOfByte, 4);
              b += 2;
              n = g.b(arrayOfByte, 6);
              b += 2;
            } 
            String str = g.b(arrayOfByte, b, arrayOfByte.length - b);
            if (i3 > 0) {
              t = new t(str, i3, m, n);
            } else {
              str = str;
              t t1;
              (t1 = t = new t()).b(str);
            } 
            t.g(i8);
            t.h(i9);
            vector.addElement(t);
          } catch (Exception exception) {
            System.err.println("windowConstructParser.Label with URL: " + exception);
          } 
          break;
        case 7:
          try {
            int i8 = g.a(arrayOfByte, 0);
            int i9 = g.a(arrayOfByte, 1);
            i3 = g.b(arrayOfByte, 2);
            m m1 = new m();
            if (arrayOfByte.length > 4) {
              String str = g.b(arrayOfByte, 4, arrayOfByte.length - 4);
              m1.a(str);
            } else {
              String str = r.a().a(i3);
              m1.a(str);
            } 
            m1.g(i8);
            m1.h(i9);
            vector.addElement(m1);
          } catch (Exception exception) {
            System.err.println("windowConstructParser.TextBox: " + exception);
          } 
          break;
        case 8:
          try {
            int i8 = g.a(arrayOfByte, 0);
            int i9 = g.a(arrayOfByte, 1);
            i3 = g.a(arrayOfByte, 2);
            int i10 = g.b(arrayOfByte, 3);
            af af;
            (af = new af()).i(i10);
            af.g(i8);
            af.h(i9);
            af.b((i3 == 0));
            if (arrayOfByte.length > 5) {
              String str = g.b(arrayOfByte, 5, arrayOfByte.length - 5);
              af.a(str);
            } 
            vector.addElement(af);
          } catch (Exception exception) {
            System.err.println("windowConstructParser.TextBox: " + exception);
          } 
          break;
        case 9:
          try {
            int i8 = g.a(arrayOfByte, 0);
            int i9 = g.a(arrayOfByte, 1);
            i3 = g.a(arrayOfByte, 2);
            int i10 = g.b(arrayOfByte, 3);
            int i11 = g.a(arrayOfByte, 5);
            v v;
            (v = new v(i3, i11)).i(i10);
            v.g(i8);
            v.h(i9);
            if (arrayOfByte.length > 6) {
              String str = g.b(arrayOfByte, 6, arrayOfByte.length - 6);
              v.a(str);
            } 
            vector.addElement(v);
          } catch (Exception exception) {
            System.err.println("windowConstructParser.TextBox: " + exception);
          } 
          break;
        case 10:
          try {
            byte b = 0;
            int i10 = 22;
            h h = new h();
            int i8 = g.a(arrayOfByte, 0);
            b++;
            int i9 = g.a(arrayOfByte, 1);
            b++;
            int i11 = g.a(arrayOfByte, 2);
            b++;
            if (i11 == 3) {
              i10 = g.b(arrayOfByte, 3);
              b += 2;
              b1 = 70;
              b2 = 50;
              bool = true;
            } else if (i11 == 2) {
              int[] arrayOfInt;
              (arrayOfInt = new int[3])[0] = g.b(arrayOfByte, 3);
              b += 2;
              arrayOfInt[1] = g.b(arrayOfByte, 5);
              b += 2;
              arrayOfInt[2] = g.b(arrayOfByte, 7);
              b += 2;
              h.a(arrayOfInt, 2);
              h.i((int)g.c(arrayOfByte, 9));
              b += 4;
            } else if (i11 == 1) {
              int[] arrayOfInt;
              (arrayOfInt = new int[3])[0] = g.b(arrayOfByte, 3);
              b += 2;
              arrayOfInt[1] = g.b(arrayOfByte, 5);
              b += 2;
              arrayOfInt[2] = g.b(arrayOfByte, 7);
              b += 2;
              h.a(arrayOfInt, 1);
            } else if (i11 == 0) {
              int[] arrayOfInt1;
              (arrayOfInt1 = new int[3])[0] = g.b(arrayOfByte, 3);
              b += 2;
              arrayOfInt1[1] = g.b(arrayOfByte, 5);
              b += 2;
              arrayOfInt1[2] = g.b(arrayOfByte, 7);
              b += 2;
              int i12 = g.a(arrayOfByte, 9);
              b++;
              int[] arrayOfInt2 = new int[i12];
              for (i11 = 0; i11 < arrayOfInt2.length; i11++) {
                arrayOfInt2[i11] = g.b(arrayOfByte, b);
                b += 2;
              } 
              h.a(arrayOfInt1, 0);
              h.a(arrayOfInt2);
            } 
            h.g(i8);
            h.h(i9);
            String str = g.b(arrayOfByte, b, arrayOfByte.length - b);
            h.f(i10);
            h.b(str);
            vector.addElement(h);
          } catch (Exception exception) {
            System.err.println("windowConstructParser.CollectButton: " + exception);
          } 
          break;
        case 11:
          try {
            z z = new z();
            int i8 = g.a(arrayOfByte, 0);
            int i9 = g.a(arrayOfByte, 1);
            z.g(i8);
            z.h(i9);
            int i10 = g.b(arrayOfByte, 2);
            if (arrayOfByte.length <= 4)
              z.e(i10); 
            vector.addElement(z);
          } catch (Exception exception) {
            System.err.println("windowConstructParser.ImageElement: " + exception);
          } 
          break;
        case 14:
          try {
            int i8 = g.a(arrayOfByte, 0);
            int i9 = g.a(arrayOfByte, 1);
            i3 = g.b(arrayOfByte, 2);
            a a1;
            (a1 = new a()).i(i3);
            a1.g(i8);
            a1.h(i9);
            if (arrayOfByte.length > 4) {
              String str = g.b(arrayOfByte, 4, arrayOfByte.length - 4);
              a1.b(str);
              a1.a(str);
            } 
            vector.addElement(a1);
          } catch (Exception exception) {
            System.err.println("windowConstructParser.TextBox: " + exception);
          } 
          break;
        case 15:
          try {
            int i10 = 0;
            int i9 = g.a(arrayOfByte, 0);
            i10++;
            int i8 = g.a(arrayOfByte, 1);
            i10++;
            i3 = g.b(arrayOfByte, 2);
            i10 += 2;
            int i11 = g.a(arrayOfByte, 4);
            i10++;
            aa aa;
            (aa = new aa()).g(i8);
            aa.h(i9);
            aa.i(i3);
            String[] arrayOfString = new String[i11];
            for (byte b = 0; b < i11; b++) {
              int i12 = g.a(arrayOfByte, i10);
              arrayOfString[b] = g.b(arrayOfByte, ++i10, i12);
              i10 += i12;
            } 
            if (arrayOfByte.length > i10) {
              int[] arrayOfInt = new int[i11];
              for (byte b4 = 0; b4 < i11; b4++) {
                arrayOfInt[b4] = (int)g.c(arrayOfByte, i10);
                i10 += 4;
              } 
              aa.a(arrayOfInt);
            } 
            aa.a(arrayOfString);
            vector.addElement(aa);
          } catch (Exception exception) {
            System.err.println("windowConstructParser.ComboBox: " + exception);
          } 
          break;
        case 16:
          i1 = g.b(arrayOfByte, 0);
          break;
        case 18:
          i4 = g.a(arrayOfByte, 0);
          i5 = g.a(arrayOfByte, 1);
          i3 = g.b(arrayOfByte, 2);
          (e = new e()).g(i4);
          e.h(i5);
          e.i(i3);
          str3 = g.b(arrayOfByte, 4, arrayOfByte.length - 4);
          e.b(str3);
          vector.addElement(e);
          break;
        case 20:
          try {
            int i8 = 0;
            i3 = g.b(arrayOfByte, 0);
            i8 += true;
            int[] arrayOfInt = new int[i3];
            String[] arrayOfString = new String[i3];
            byte b5;
            for (b5 = 0; b5 < i3; b5++) {
              arrayOfInt[b5] = g.b(arrayOfByte, i8);
              i8 += true;
            } 
            for (b5 = 0; b5 < i3; b5++) {
              int i9 = g.a(arrayOfByte, i8);
              arrayOfString[b5] = g.b(arrayOfByte, ++i8, i9);
              i8 += i9;
            } 
            if (this.O == null) {
              b.a().a(a());
              return;
            } 
            q q;
            n[][] arrayOfN1 = (q = this.O.elementAt(this.O.size() - 1)).a;
            byte b6 = 0;
            byte b4 = 0;
            while (b4 < arrayOfN1.length) {
              for (byte b = 0; b < (arrayOfN1[0]).length; b++) {
                if (arrayOfN1[b4][b].q() == arrayOfInt[b6] && arrayOfN1[b4][b] instanceof v) {
                  arrayOfN1[b4][b].b(arrayOfString[b6]);
                  ((v)arrayOfN1[b4][b]).a(arrayOfString[b6]);
                  b6++;
                } 
              } 
              if (b6 < i3)
                b4++; 
            } 
            d(1);
            b = false;
            return;
          } catch (Exception exception) {
            System.err.println("windowConstructParser.ComboBox: " + exception);
            return;
          } 
        case 22:
          i6 = g.a(arrayOfByte, 0);
          i7 = (int)g.c(arrayOfByte, 1);
          str4 = g.b(arrayOfByte, 5, arrayOfByte.length - 5);
          b = false;
          j = i7;
          i = i6;
          str1 = str4;
          (this = this).c.addElement(str1);
          this.c.addElement(new int[] { i, j });
          return;
        case 13:
          i = g.a(arrayOfByte1 = arrayOfByte, 0);
          str2 = g.b(this, 1, this.length - 1);
          i.a().a(str2, 0);
          switch (i) {
            case 0:
              i.a().a(b.a().b());
              break;
            case 1:
              i.a().a(a());
              break;
            case 2:
              i.a().a(o.a());
              break;
          } 
          i.a().b();
          b = false;
          return;
      } 
      i += ab.a + arrayOfByte.length;
    } 
    n[][] arrayOfN = new n[vector1.size()][];
    for (byte b3 = 0; b3 < vector1.size(); b3++)
      arrayOfN[b3] = vector1.elementAt(b3); 
    switch (i1) {
      case 0:
        if (((k)super).O != null) {
          ((k)super).O.removeAllElements();
          ((k)super).O = null;
        } 
        break;
      case 1:
        if (b.a().b() instanceof q) {
          if (((k)super).O == null)
            ((k)super).O = new Vector(); 
          ((k)super).O.addElement((q)b.a().b());
          break;
        } 
        i1 = 2;
        break;
      case 10:
        if (((k)super).O == null || ((k)super).O.size() == 0) {
          ((k)super).O = null;
          ((k)super).O = new Vector();
          ((k)super).O.addElement((q)b.a().b());
        } 
        break;
    } 
    q q2;
    (q2 = new q()).a(b1, b2);
    q2.a((String)null, arrayOfN);
    if (bool)
      q2.b(); 
    int i2 = i1;
    q q1;
    (q1 = q2).b = i2;
    b = false;
    b.a().a(q2);
  }
  
  public final void d(int paramInt) {
    b b;
    q q;
    g g;
    switch (paramInt) {
      case 5:
        return;
      case 10:
        this.W = false;
        if (this.O == null) {
          b.a().a(a());
          return;
        } 
        q = this.O.elementAt(0);
        b.a().a(q);
        if (this.O != null)
          this.O = null; 
        return;
      case 1:
        this.W = false;
        if (this.O == null) {
          b.a().a(a());
          return;
        } 
        q = this.O.elementAt(this.O.size() - 1);
        this.O.removeElementAt(this.O.size() - 1);
        b.a().a(q);
        return;
      case 0:
      case 2:
        this.W = false;
        if (this.O != null)
          this.O = null; 
        b.a().a(a());
        return;
      case 3:
        b = b.a();
        (g = g.a()).b();
        a((f)g);
        i.a().repaint();
        i.a().serviceRepaints();
        i.a();
        i.a(500L);
        g.a();
        g.c();
        break;
    } 
  }
  
  public final void c() {
    a(10, 22, 0, null);
  }
  
  public final void d() {
    a(10, 24, 0, null);
  }
  
  public final void e() {
    if (this.W == true) {
      d(1);
      return;
    } 
    this.W = true;
    n[][] arrayOfN;
    (arrayOfN = new n[12][])[0] = new n[1];
    arrayOfN[1] = new n[1];
    arrayOfN[2] = new n[1];
    arrayOfN[3] = new n[1];
    arrayOfN[4] = new n[1];
    arrayOfN[5] = new n[1];
    arrayOfN[6] = new n[1];
    arrayOfN[7] = new n[1];
    arrayOfN[8] = new n[1];
    arrayOfN[9] = new n[1];
    arrayOfN[10] = new n[1];
    arrayOfN[11] = new n[1];
    arrayOfN[0][0] = new j();
    ((j)arrayOfN[0][0]).e(0);
    ((j)arrayOfN[0][0]).a("Ресурсы");
    arrayOfN[1][0] = new m();
    ((m)arrayOfN[1][0]).a("{i0} " + Integer.toString(this.p) + " / " + Integer.toString(this.z));
    arrayOfN[1][0].g(1);
    arrayOfN[1][0].h(1);
    arrayOfN[2][0] = new m();
    ((m)arrayOfN[2][0]).a("{i1} " + Integer.toString(this.q) + " / " + Integer.toString(this.A));
    arrayOfN[2][0].g(1);
    arrayOfN[2][0].h(1);
    arrayOfN[3][0] = new m();
    ((m)arrayOfN[3][0]).a("{i2} " + Integer.toString(this.r) + " / " + Integer.toString(this.B));
    arrayOfN[3][0].g(1);
    arrayOfN[3][0].h(1);
    arrayOfN[4][0] = new m();
    ((m)arrayOfN[4][0]).a("{i3} " + Integer.toString(this.s) + " / " + Integer.toString(this.C));
    arrayOfN[4][0].g(1);
    arrayOfN[4][0].h(1);
    arrayOfN[5][0] = new m();
    ((m)arrayOfN[5][0]).a("{i4} " + Integer.toString(this.t) + " / " + Integer.toString(this.D));
    arrayOfN[5][0].g(1);
    arrayOfN[5][0].h(1);
    arrayOfN[6][0] = new j();
    ((j)arrayOfN[6][0]).e(0);
    ((j)arrayOfN[6][0]).a("Добыча");
    arrayOfN[7][0] = new m();
    ((m)arrayOfN[7][0]).a("{i0} " + Integer.toString(this.u) + " ед/час");
    arrayOfN[7][0].g(1);
    arrayOfN[7][0].h(1);
    arrayOfN[8][0] = new m();
    ((m)arrayOfN[8][0]).a("{i1} " + Integer.toString(this.v) + " ед/час");
    arrayOfN[8][0].g(1);
    arrayOfN[8][0].h(1);
    arrayOfN[9][0] = new m();
    ((m)arrayOfN[9][0]).a("{i2} " + Integer.toString(this.w) + " ед/час");
    arrayOfN[9][0].g(1);
    arrayOfN[9][0].h(1);
    arrayOfN[10][0] = new m();
    ((m)arrayOfN[10][0]).a("{i3} " + Integer.toString(this.x) + " ед/час");
    arrayOfN[10][0].g(1);
    arrayOfN[10][0].h(1);
    arrayOfN[11][0] = new m();
    ((m)arrayOfN[11][0]).a("{i4} " + Integer.toString(this.y) + " чел/час");
    arrayOfN[11][0].g(1);
    arrayOfN[11][0].h(1);
    q q2;
    (q2 = new q()).a(70, 70);
    q2.a((String)null, arrayOfN);
    boolean bool = true;
    q q1;
    (q1 = q2).b = bool;
    if (b.a().b() instanceof q && this.O == null)
      this.O = new Vector(); 
    if (b.a().b() instanceof q)
      this.O.addElement((q)b.a().b()); 
    b.a().a(q2);
  }
  
  public final void a(Graphics paramGraphics) {
    s s1;
    Graphics graphics;
    k k1;
    (k1 = this).Q += System.currentTimeMillis() - k1.P;
    if (k1.Q > 1000L) {
      long l = k1.Q / 1000L;
      k1.Q %= 1000L;
      k1.p += (int)(l * k1.u / 3600L + k1.R / 3600L);
      k1.R = k1.R % 3600L + l * k1.u % 3600L;
      if (k1.p > k1.z)
        k1.p = k1.z; 
      k1.q += (int)(l * k1.v / 3600L + k1.S / 3600L);
      k1.S = k1.S % 3600L + l * k1.v % 3600L;
      k1.r += (int)(l * k1.w / 3600L + k1.T / 3600L);
      k1.T = k1.T % 3600L + l * k1.w % 3600L;
      k1.s += (int)(l * k1.x / 3600L + k1.U / 3600L);
      k1.U = k1.U % 3600L + l * k1.x % 3600L;
      k1.t += (int)(l * k1.y / 86400L + k1.V / 86400L);
      k1.V = k1.V % 86400L + l * k1.y % 86400L;
      if (k1.p > k1.z)
        k1.p = k1.z; 
      if (k1.q > k1.A)
        k1.q = k1.A; 
      if (k1.r > k1.B)
        k1.r = k1.B; 
      if (k1.s > k1.C)
        k1.s = k1.C; 
      if (k1.t > k1.D)
        k1.t = k1.D; 
    } 
    k1.P = System.currentTimeMillis();
    paramGraphics.setColor(16777215);
    paramGraphics.fillRect(0, 0, i.a, i.b);
    byte b = 0;
    if (a == true)
      b = 1; 
    if (b == true)
      b = 2; 
    switch (this.h) {
      default:
        graphics = paramGraphics;
        (s1 = this.e).a(graphics, true);
        this.e.f(paramGraphics);
        if (this.F)
          this.e.g(paramGraphics); 
        this.e.d(paramGraphics);
        if (this.F)
          this.e.h(paramGraphics); 
        this.e.a(paramGraphics, b);
        d(paramGraphics);
        c(paramGraphics);
        return;
      case 1:
        graphics = paramGraphics;
        (s1 = this.f).a(graphics, true);
        this.f.c(paramGraphics);
        this.f.e(paramGraphics);
        this.f.a(paramGraphics, b);
        d(paramGraphics);
        c(paramGraphics);
        return;
      case 2:
        break;
    } 
    this.g.a(paramGraphics);
    this.g.a(paramGraphics, false);
    this.g.b(paramGraphics);
    d(paramGraphics);
    this.g.i(paramGraphics);
    this.g.a(paramGraphics, b);
    c(paramGraphics);
  }
  
  private void c(Graphics paramGraphics) {
    int i = this.X;
    paramGraphics.getClipX();
    paramGraphics.getClipY();
    paramGraphics.getClipWidth();
    paramGraphics.getClipHeight();
    int j = c.k.getHeight();
    int m = c.k.getWidth();
    int n = this.X / j + 1;
    int i1 = i.a / m + 1;
    int i2;
    for (i2 = 0; i2 < n; i2++) {
      for (byte b1 = 0; b1 < i1; b1++)
        paramGraphics.drawImage(c.k, b1 * m, i.b + i2 * j - i, 0); 
    } 
    if (this.I == null)
      return; 
    i2 = 0;
    byte b = 0;
    for (i = 0; i < this.I.length; i++) {
      if (this.I[i][2] > 0) {
        i2 += c.a(this.I[i][0]).getWidth();
        b = (b > c.a(this.I[i][0]).getHeight()) ? b : c.a(this.I[i][0]).getHeight();
        if (this.I[i][3] == 1) {
          i2 += paramGraphics.getFont().stringWidth(Integer.toString(this.I[i][2])) + 3;
          b = (b > paramGraphics.getFont().getHeight()) ? b : paramGraphics.getFont().getHeight();
        } else {
          i2 += 3;
        } 
      } else if (this.I[i][1] > 0) {
        i2 += c.a(this.I[i][1]).getWidth() + 3;
        b = (b > c.a(this.I[i][1]).getHeight()) ? b : c.a(this.I[i][1]).getHeight();
      } 
    } 
    i = i2 / c.b[9].getWidth() + 1;
    for (j = 0; j < i; j++)
      paramGraphics.drawImage(c.b[9], i.a / 2 - i2 / 2 + j * c.b[9].getWidth(), i.b - c.b[9].getHeight(), 0); 
    paramGraphics.drawImage(c.a(705), 5, i.b - c.b[8].getHeight() / 2 - c.a(705).getHeight() / 2, 0);
    paramGraphics.drawImage(c.a(706), i.a - 5 - c.a(706).getWidth(), i.b - c.b[8].getHeight() / 2 - c.a(706).getHeight() / 2, 0);
    paramGraphics.drawImage(c.b[8], i.a / 2 - i2 / 2 - c.b[8].getWidth(), i.b - c.b[8].getHeight(), 0);
    paramGraphics.drawImage(c.b[10], i.a / 2 - i2 / 2 + i * c.b[9].getWidth(), i.b - c.b[10].getHeight(), 0);
    j = i.a / 2 - i2 / 2 + 1;
    i = i.b - this.X / 2 - b / 2;
    paramGraphics.setFont(h.d);
    paramGraphics.setColor(16777215);
    for (m = 0; m < this.I.length; m++) {
      if (this.I[m][2] > 0) {
        if (c.a(this.I[m][0]).getHeight() == b) {
          paramGraphics.drawImage(c.a(this.I[m][0]), j, i, 20);
        } else {
          paramGraphics.drawImage(c.a(this.I[m][0]), j, i + c.a(this.I[m][0]).getHeight() / 2, 20);
        } 
        j += c.a(this.I[m][0]).getWidth();
        if (this.I[m][3] == 1) {
          paramGraphics.drawString(Integer.toString(this.I[m][2]), j, i, 20);
          j += paramGraphics.getFont().stringWidth(Integer.toString(this.I[m][2])) + 3;
        } else {
          j += 3;
        } 
      } else if (this.I[m][1] > 0) {
        paramGraphics.drawImage(c.a(this.I[m][1]), j, i, 20);
        j += c.a(this.I[m][1]).getWidth() + 3;
      } 
    } 
  }
  
  private void d(Graphics paramGraphics) {
    paramGraphics.setColor(13421721);
    int m = i.a / c.b[11].getWidth() + 1;
    int n;
    for (n = 0; n < m; n++)
      paramGraphics.drawImage(c.b[11], n * c.b[11].getWidth(), c.b[4].getHeight(), 0); 
    m = i.a / c.b[4].getWidth() + 1;
    for (n = 0; n < m; n++) {
      paramGraphics.drawImage(c.b[4], n * c.b[4].getWidth(), 0, 0);
      paramGraphics.drawImage(c.b[5], n * c.b[4].getWidth(), i.b - c.b[5].getHeight() - this.X, 0);
    } 
    n = i.b / c.b[4].getHeight() + 1;
    for (m = 0; m < n; m++) {
      paramGraphics.drawImage(c.b[6], 0, m * c.b[6].getWidth(), 0);
      paramGraphics.drawImage(c.b[7], i.a - c.b[7].getWidth(), m * c.b[7].getWidth(), 0);
    } 
    paramGraphics.drawImage(c.b[0], 0, 0, 0);
    paramGraphics.drawImage(c.b[1], i.a - c.b[1].getWidth(), 0, 0);
    paramGraphics.drawImage(c.b[2], 0, i.b - c.b[2].getHeight() - this.X, 0);
    paramGraphics.drawImage(c.b[3], i.a - c.b[3].getWidth(), i.b - c.b[2].getHeight() - this.X, 0);
    Calendar calendar;
    TimeZone timeZone;
    int j = (calendar = Calendar.getInstance(timeZone = TimeZone.getTimeZone(this.M))).get(11);
    n = get(12);
    int i = get(13);
    String str = "";
    if (j < 10)
      str = str + "0"; 
    str = str + Integer.toString(j);
    if (n < 10) {
      str = str + ":0";
    } else {
      str = str + ":";
    } 
    str = str + Integer.toString(n);
    if (i < 10) {
      str = str + ":0";
    } else {
      str = str + ":";
    } 
    str = str + Integer.toString(i);
    paramGraphics.drawString(str, i.a / 2 - paramGraphics.getFont().stringWidth(str) / 2, c.b[4].getHeight() + c.b[11].getHeight() / 2 - paramGraphics.getFont().getHeight() / 2, 0);
    paramGraphics.setColor(16777215);
  }
  
  public final void b(Graphics paramGraphics) {
    int[] arrayOfInt = this.c.elementAt(1);
    int i = -1;
    if (this.L < arrayOfInt[0]) {
      String str = this.c.elementAt(0);
      paramGraphics.setColor(8406570);
      if (str.indexOf("{i") >= 0) {
        i = Integer.parseInt(str.substring(str.indexOf("{i") + 2, str.indexOf("}")));
        int j = i.a / c.b[11].getWidth() + 1;
        byte b;
        for (b = 0; b < j; b++)
          paramGraphics.drawImage(c.b[11], b * c.b[11].getWidth(), c.b[4].getHeight(), 0); 
        j = i.a / c.b[4].getWidth() + 1;
        for (b = 0; b < j; b++)
          paramGraphics.drawImage(c.b[4], b * c.b[4].getWidth(), 0, 0); 
        paramGraphics.drawImage(c.a(i), i.a - this.K, c.b[4].getHeight() + c.b[11].getHeight() / 2 - paramGraphics.getFont().getHeight() / 2, 0);
        str = str.substring(str.indexOf("}") + 1, str.length());
        if (this.J == 0 && i == 419) {
          this.c.removeElementAt(0);
          this.c.removeElementAt(0);
          this.K = 0;
          this.L = 0;
          return;
        } 
      } else {
        int j = i.a / c.b[11].getWidth() + 1;
        for (byte b = 0; b < j; b++)
          paramGraphics.drawImage(c.b[11], b * c.b[11].getWidth(), c.b[4].getHeight(), 0); 
        paramGraphics.drawImage(c.b[0], 0, 0, 0);
        paramGraphics.drawImage(c.b[1], i.a - c.b[1].getWidth(), 0, 0);
      } 
      paramGraphics.setColor(arrayOfInt[1]);
      if (i == -1) {
        paramGraphics.drawString(str, i.a - this.K, c.b[4].getHeight() + c.b[11].getHeight() / 2 - paramGraphics.getFont().getHeight() / 2, 0);
      } else {
        paramGraphics.drawString(str, i.a - this.K + c.a(i).getWidth(), c.b[4].getHeight() + c.b[11].getHeight() / 2 - paramGraphics.getFont().getHeight() / 2, 0);
      } 
      paramGraphics.drawImage(c.b[0], 0, 0, 0);
      paramGraphics.drawImage(c.b[1], i.a - c.b[1].getWidth(), 0, 0);
      this.K += 2;
      if (this.K > i.a + paramGraphics.getFont().stringWidth(str)) {
        this.K = 0;
        this.L += 2;
      } 
      return;
    } 
    this.L = 0;
    this.c.removeElementAt(0);
    this.c.removeElementAt(0);
  }
  
  public static String[] b(int paramInt1, int paramInt2) {
    u u = u.a(paramInt1, paramInt2);
    String[] arrayOfString;
    (arrayOfString = new String[4])[0] = u.f;
    arrayOfString[1] = u.g;
    arrayOfString[2] = u.h;
    arrayOfString[3] = "Рейтинг:" + Integer.toString(u.j);
    return arrayOfString;
  }
}


/* Location:              C:\Users\sora\Desktop\Third_World_War_of_Kings_2D.jar!\k.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */