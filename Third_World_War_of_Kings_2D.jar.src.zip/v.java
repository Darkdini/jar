import com.fenix.main.Main;
import com.fenix.main.h;
import javax.microedition.lcdui.Font;
import javax.microedition.lcdui.Graphics;

public final class v extends n {
  private static final String[] c = new String[] { " 0", ".1,-?!'@:;/()", "ABC2АБВГ", "DEF3ДЕЖЗ", "GHI4ИЙКЛ", "JKL5МНОП", "MNO6РСТУ", "PQRS7ФХЦЧ", "TUV8ШЩЪЫ", "WXYZ9ЬЭЮЯ" };
  
  private static final String[] d = new String[] { " 0", ".1,-_?!'@:;/()", "abc2РСТУ", "def3ФХЦЧ", "ghi4ШЩЪЫ", "jkl5ЬЭЮЯ", "mno6абвг", "pqrs7дежз", "tuv8ийкл", "wxyz9мноп" };
  
  private static final String[] e = new String[] { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9" };
  
  private static final String[] f = new String[] { " 0", ".1-_", "ABC2", "DEF3", "GHI4", "JKL5", "MNO6", "PQRS7", "TUV8", "WXYZ9" };
  
  private static final String[] g = new String[] { " 0", ".1-_", "abc2", "def3", "ghi4", "jkl5", "mno6", "pqrs7", "tuv8", "wxyz9" };
  
  private static final String[] h = new String[] { " 0", ".1,-?!'@:;/()", "АБВГ2ABC", "ДЕЖЗ3DEF", "ИЙКЛ4GHI", "МНОП5JKL", "РСТУ6MNO", "ФХЦЧ7PQRS", "ШЩЪЫ8TUV", "ЬЭЮЯ9WXYZ" };
  
  private static final String[] i = new String[] { " 0", ".1,-_?!'@:;/()", "абвг2abc", "дежз3def", "ийкл4ghi", "мноп5jkl", "рсту6mno", "фхцч7pqrs", "шщъы8tuv", "ьэюя9wxyz" };
  
  private static final String[] j = new String[] { " 0", ".1,-?!'@:;/()", "ABC2", "DEF3", "GHI4", "JKL5", "MNO6", "PQRS7", "TUV8", "WXYZ9" };
  
  private static final String[] k = new String[] { " 0", ".1,-_?!'@:;/()", "abc2", "def3", "ghi4", "jkl5", "mno6", "pqrs7", "tuv8", "wxyz9" };
  
  public int a = 0;
  
  public int b = 0;
  
  private int l = 0;
  
  private StringBuffer m = null;
  
  private int n = 0;
  
  private int o = -1;
  
  private int p = -1;
  
  private boolean q = true;
  
  private long r = 0L;
  
  private long s = 0L;
  
  private int t = 0;
  
  private int u;
  
  private Font v = h.d;
  
  private int w = 0;
  
  public v() {
    b("");
    c(true);
    this.b = 0;
    this.m = new StringBuffer(5);
    this.n = 5;
  }
  
  public v(int paramInt1, int paramInt2) {
    b("");
    c(true);
    this.b = paramInt1;
    this.m = new StringBuffer(paramInt2);
    this.n = paramInt2;
  }
  
  public final int a() {
    return this.n;
  }
  
  public final void a(String paramString) {
    if (paramString == null || paramString.length() <= 0) {
      this.m.setLength(0);
      this.t = 0;
      return;
    } 
    this.m = new StringBuffer(paramString);
    this.t = paramString.length();
  }
  
  public final String b() {
    return (this.m == null || this.m.length() <= 0) ? "" : this.m.toString();
  }
  
  public final void a(Graphics paramGraphics) {
    if (!g())
      return; 
    int i = k();
    int j = l();
    int k = m();
    int m = n();
    if (System.currentTimeMillis() > this.r + 1000L) {
      v v1 = this;
      char c1 = Character.MIN_VALUE;
      if (v1.o >= 0 && v1.p >= 0) {
        if (v1.m.length() < v1.n) {
          switch (v1.b) {
            case 0:
              c1 = c[v1.o].charAt(v1.p);
              break;
            case 3:
              c1 = f[v1.o].charAt(v1.p);
              break;
            case 1:
              c1 = e[v1.o].charAt(v1.p);
              break;
            case 4:
              c1 = h[v1.o].charAt(v1.p);
              break;
            case 2:
            case 5:
              c1 = j[v1.o].charAt(v1.p);
              break;
          } 
          v1.m.insert(v1.t++, c1);
          v1.u += v1.v.charWidth(c1);
          String str;
          if ((str = v1.m.toString()) == null || str.length() <= 0)
            str = ""; 
          if (v1.v.stringWidth(str.substring(0, v1.t)) - v1.w > v1.m() - 7)
            v1.w = v1.v.stringWidth(str.substring(0, v1.t)) - v1.m() + 7; 
        } 
        v1.o = -1;
        v1.p = -1;
      } 
      this.r = System.currentTimeMillis();
    } 
    if (System.currentTimeMillis() > this.s + 250L) {
      this.s = System.currentTimeMillis();
      this.q = !this.q;
    } 
    if (i()) {
      paramGraphics.setColor(8986913);
    } else {
      paramGraphics.setColor(6684672);
    } 
    paramGraphics.fillRect(i, j, k, m);
    paramGraphics.setColor(0);
    paramGraphics.drawRect(i - 1, j - 1, k + 2, m + 2);
    if (i()) {
      paramGraphics.setColor(16777164);
      paramGraphics.drawRect(i, j, k, m);
    } else {
      paramGraphics.setColor(9735534);
      paramGraphics.drawRect(i, j, k, m);
    } 
    String str1 = this.m.toString();
    int i1 = 16777215;
    if (str1 == null || str1.length() <= 0)
      str1 = ""; 
    String str2 = "";
    String str3 = "";
    char c = Character.MIN_VALUE;
    if (this.b == 2) {
      str1 = "";
      for (byte b = 0; b < this.m.length(); b++)
        str1 = str1 + '*'; 
    } 
    if ((this.a & 0x1) != 0 && this.o >= 0 && this.p >= 0) {
      if (this.t >= 0)
        str2 = str1.substring(0, this.t); 
      if (this.t < str1.length())
        str3 = str1.substring(this.t); 
      switch (this.b) {
        case 0:
          c = c[this.o].charAt(this.p);
          break;
        case 3:
          c = f[this.o].charAt(this.p);
          break;
        case 1:
          c = e[this.o].charAt(this.p);
          break;
        case 4:
          c = h[this.o].charAt(this.p);
          break;
        case 2:
        case 5:
          c = j[this.o].charAt(this.p);
          break;
      } 
      str1 = str2 + c + str3;
    } 
    paramGraphics.setFont(this.v);
    int i2;
    if ((i2 = this.w) == this.v.stringWidth(str1.substring(0, this.t)) - m() + 7 && this.o >= 0 && this.p >= 0)
      i2 += this.v.stringWidth("" + c); 
    paramGraphics.getClipX();
    paramGraphics.getClipY();
    paramGraphics.getClipWidth();
    paramGraphics.getClipHeight();
    paramGraphics.setColor(i1);
    paramGraphics.drawString(str1, i + 5 - i2, j + m / 2 - this.v.getHeight() / 2 + 1, 0);
  }
  
  public final void e(int paramInt) {
    switch (paramInt) {
      case 32:
      case 524288:
        Main.a(b());
        Main.a(this);
        if (this.b == 0 || this.b == 4) {
          Main.a().b(this.n);
          return;
        } 
        if (this.b == 1) {
          Main.a().c(this.n);
          return;
        } 
        if (this.b == 5) {
          Main.a().a(this.n);
          return;
        } 
        break;
      case 65536:
      case 131072:
        if ((this.a & 0x1) == 0) {
          this.a |= 0x1;
          return;
        } 
        this.a &= 0xFFFFFFFE;
        break;
    } 
  }
}


/* Location:              C:\Users\sora\Desktop\Third_World_War_of_Kings_2D.jar!\v.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */