import com.fenix.main.c;
import com.fenix.main.e;
import com.fenix.main.h;
import com.fenix.main.i;
import javax.microedition.lcdui.Graphics;

public final class s {
  private int[][] a;
  
  private int[][] b;
  
  private int[][] c;
  
  private int[][] d;
  
  private int e;
  
  private int f;
  
  private int g;
  
  private int h;
  
  private int i;
  
  private int j;
  
  private int k;
  
  private int l;
  
  private int m;
  
  private int n;
  
  private int[] o;
  
  private long p = 0L;
  
  private long q = 0L;
  
  public final void a(int paramInt1, int paramInt2) {
    this.m = paramInt1;
    this.n = paramInt2;
  }
  
  public final void a(int[][] paramArrayOfint) {
    this.a = paramArrayOfint;
  }
  
  public final void b(int[][] paramArrayOfint) {
    this.c = paramArrayOfint;
  }
  
  public final void c(int[][] paramArrayOfint) {
    this.d = paramArrayOfint;
  }
  
  public final void d(int[][] paramArrayOfint) {
    this.b = paramArrayOfint;
  }
  
  public final void b(int paramInt1, int paramInt2) {
    this.e = paramInt1;
    this.f = paramInt2;
  }
  
  public final void a(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this.g = paramInt1;
    this.h = paramInt2;
    this.i = paramInt3;
    this.j = paramInt4;
  }
  
  public final void c(int paramInt1, int paramInt2) {
    this.k = paramInt1;
    this.l = paramInt2;
  }
  
  public final void a(byte[] paramArrayOfbyte) {
    int i = paramArrayOfbyte.length / 11;
    this.o = null;
    if (paramArrayOfbyte.length > 0) {
      this.o = new int[paramArrayOfbyte.length / 2 + i];
    } else {
      return;
    } 
    for (byte b = 0; b < i; b++) {
      this.o[b * 6] = g.b(paramArrayOfbyte, b * 11 + 1);
      this.o[b * 6 + 1] = g.b(paramArrayOfbyte, b * 11 + 3);
      this.o[b * 6 + 2] = g.b(paramArrayOfbyte, b * 11 + 5);
      this.o[b * 6 + 3] = g.b(paramArrayOfbyte, b * 11 + 7);
      this.o[b * 6 + 4] = g.b(paramArrayOfbyte, b * 11 + 9);
      this.o[b * 6 + 5] = g.a(paramArrayOfbyte, b * 11);
    } 
    this.p = System.currentTimeMillis();
    this.q = 0L;
  }
  
  public final void a() {
    if (this.f > this.h) {
      this.f--;
      this.l += 16;
      this.k += 31;
    } 
  }
  
  public final void b() {
    if (this.f < this.j) {
      this.f++;
      this.l -= 16;
      this.k -= 31;
    } 
  }
  
  public final void c() {
    if (this.e < this.i) {
      this.e++;
      this.k -= 31;
      this.l += 16;
    } 
  }
  
  public final void d() {
    if (this.e > this.g) {
      this.e--;
      this.k += 31;
      this.l -= 16;
    } 
  }
  
  public final void e() {
    if (this.f > this.h) {
      this.f--;
      this.l += 16;
      this.k += 31;
      return;
    } 
    k.a().a(this.m, this.n - 4);
    this.f += 4;
    this.l -= 64;
    this.k -= 124;
  }
  
  public final void f() {
    if (this.f < this.j) {
      this.f++;
      this.l -= 16;
      this.k -= 31;
      return;
    } 
    System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!Press down " + this.m + ":" + this.n);
    k.a().a(this.m, this.n + 4);
    this.f -= 4;
    this.l += 64;
    this.k += 124;
  }
  
  public final void g() {
    if (this.e < this.i) {
      this.e++;
      this.k -= 31;
      this.l += 16;
      return;
    } 
    k.a().a(this.m + 4, this.n);
    this.e -= 4;
    this.k += 124;
    this.l -= 64;
  }
  
  public final void h() {
    if (this.e > this.g) {
      this.e--;
      this.k += 31;
      this.l -= 16;
      return;
    } 
    k.a().a(this.m - 4, this.n);
    this.e += 4;
    this.k -= 124;
    this.l += 64;
  }
  
  private int d(int paramInt1, int paramInt2) {
    return this.k + paramInt1 * 31 + paramInt2 * 31;
  }
  
  private int e(int paramInt1, int paramInt2) {
    return this.l + (paramInt2 << 4) - (paramInt1 << 4);
  }
  
  public final int i() {
    return this.e - this.g;
  }
  
  public final int j() {
    return this.f - this.h;
  }
  
  private static void a(Graphics paramGraphics, int paramInt1, int paramInt2, boolean paramBoolean, int paramInt3) {
    paramGraphics.setColor(e.d);
    paramGraphics.fillRect(paramInt1, paramInt2, e.b, e.b);
    if (!paramBoolean)
      return; 
    if (paramInt3 == 1) {
      paramGraphics.setColor(e.f);
    } else if (paramInt3 == 0) {
      paramGraphics.setColor(e.e);
    } else if (paramInt3 == 2) {
      paramGraphics.setColor(e.g);
    } 
    paramGraphics.fillRect(paramInt1 + e.c, paramInt2 + e.c, e.b - 2 * e.c, e.b - 2 * e.c);
  }
  
  public final void a(Graphics paramGraphics, boolean paramBoolean) {
    s s1;
    if ((s1 = this).o != null) {
      s1.q += System.currentTimeMillis() - s1.p;
      if (s1.q > 1000L) {
        s1.q -= 1000L;
        for (byte b = 0; b < s1.o.length / 6; b++)
          s1.o[b * 6 + 4] = s1.o[b * 6 + 4] + 1; 
      } 
      s1.p = System.currentTimeMillis();
    } 
    byte b1 = 0;
    if (paramBoolean)
      b1 = 5; 
    for (byte b2 = -b1; b2 < this.a.length + b1; b2++) {
      for (int i = (this.a[0]).length + b1 - 1; i >= -b1; i--) {
        int j = d(i, b2);
        int k = e(i, b2);
        if (j >= -62 && j <= i.a && k >= -32 && j <= i.b)
          if (b2 >= 0 && b2 < this.a.length && i >= 0 && i < (this.a[0]).length) {
            paramGraphics.drawImage(c.a(601 + this.a[b2][i]), j, k - c.a(601 + this.a[b2][i]).getHeight() - 32, 0);
          } else {
            paramGraphics.drawImage(c.a[11], j, k - c.a[11].getHeight() - 32, 0);
          }  
      } 
    } 
  }
  
  public final void a(Graphics paramGraphics) {
    int i = d((this.a[0]).length / 2, -1);
    int j = e((this.a[0]).length / 2, -1);
    paramGraphics.drawImage(c.a[12], i, j - c.a[12].getHeight() - 32, 0);
    i = d((this.a[0]).length, this.a.length / 2);
    j = e((this.a[0]).length, this.a.length / 2);
    paramGraphics.drawImage(c.a[13], i, j - c.a[13].getHeight() - 32, 0);
  }
  
  public final void b(Graphics paramGraphics) {
    int i = d((this.a[0]).length / 2, this.a.length);
    int j = e((this.a[0]).length / 2, this.a.length);
    paramGraphics.drawImage(c.a[14], i, j - c.a[14].getHeight() - 32, 0);
    i = d(-1, this.a.length / 2);
    j = e(-1, this.a.length / 2);
    paramGraphics.drawImage(c.a[15], i, j - c.a[15].getHeight() - 32, 0);
  }
  
  public final void c(Graphics paramGraphics) {
    for (byte b = 0; b < this.d.length; b++) {
      for (byte b1 = 0; b1 < (this.d[0]).length; b1++) {
        if (this.d[b][b1] >= 0) {
          int i = d(b1, b);
          int j = e(b1, b);
          if (i >= -62 && i <= i.a && j >= -32 && i <= i.b)
            paramGraphics.drawImage(c.e[this.d[b][b1]], i, j, 0); 
        } 
      } 
    } 
  }
  
  public final void d(Graphics paramGraphics) {
    for (byte b = 0; b < this.b.length; b++) {
      for (int i = (this.b[0]).length - 1; i >= 0; i--) {
        int j = d(this.g + i, this.h + b);
        int k = e(this.g + i, this.h + b);
        if (this.b[b][i] == -2)
          paramGraphics.drawImage(c.a(110), j + 31 - c.a(110).getWidth() / 2, k - c.a(110).getHeight() - 32, 0); 
        if (this.o != null)
          for (byte b1 = 0; b1 < this.o.length / 6; b1++) {
            if (this.o[1 + b1 * 6] == i && this.o[2 + b1 * 6] == b)
              for (byte b2 = 0; b2 < 10; b2++) {
                if (this.o[4 + b1 * 6] * 100 / this.o[3 + b1 * 6] > b2 * 10) {
                  a(paramGraphics, j, k + 16 - e.b * b2, true, this.o[5 + b1 * 6]);
                } else {
                  a(paramGraphics, j, k + 16 - e.b * b2, false, this.o[5 + b1 * 6]);
                } 
              }  
          }  
        if (this.b[b][i] > -1) {
          j = d(this.g + i, this.h + b);
          k = e(this.g + i, this.h + b);
          paramGraphics.drawImage(c.a(100 + this.b[b][i]), j + 31 - c.a(100 + this.b[b][i]).getWidth() / 2, k - c.a(100 + this.b[b][i]).getHeight() - 32, 0);
        } 
      } 
    } 
  }
  
  public final void e(Graphics paramGraphics) {
    for (byte b = 0; b < this.c.length; b++) {
      for (int i = (this.c[0]).length - 1; i >= 0; i--) {
        if (this.c[b][i] > -1 && this.b[b][i] == -1) {
          byte b1 = 0;
          int j = d(this.g + i, this.h + b);
          int k = e(this.g + i, this.h + b);
          if (this.c[b][i] == 1)
            b1 = 3; 
          if (this.c[b][i] == 2)
            b1 = -2; 
          paramGraphics.drawImage(c.d[this.c[b][i]], j + 31 - c.d[this.c[b][i]].getWidth() / 2, k - c.d[this.c[b][i]].getHeight() - 32 + b1, 0);
        } 
        if (this.b[b][i] > -1) {
          int j = d(this.g + i, this.h + b);
          int k = e(this.g + i, this.h + b);
          paramGraphics.drawImage(c.a(this.b[b][i] + 100), j + 31 - c.a(this.b[b][i] + 100).getWidth() / 2, k - c.a(this.b[b][i] + 100).getHeight() - 32, 0);
          if (this.o != null)
            for (byte b1 = 0; b1 < this.o.length / 6; b1++) {
              if (this.o[1 + b1 * 6] == i && this.o[2 + b1 * 6] == b)
                for (byte b2 = 0; b2 < 10; b2++) {
                  if (this.o[4 + b1 * 6] * 100 / this.o[3 + b1 * 6] > b2 * 10) {
                    a(paramGraphics, j, k + 16 - e.b * b2, true, this.o[5 + b1 * 6]);
                  } else {
                    a(paramGraphics, j, k + 16 - e.b * b2, false, this.o[5 + b1 * 6]);
                  } 
                }  
            }  
        } 
        if (this.b[b][i] == -2) {
          int j = d(this.g + i, this.h + b);
          int k = e(this.g + i, this.h + b);
          paramGraphics.drawImage(c.c[10], j + 31 - c.c[10].getWidth() / 2, k - c.c[10].getHeight() - 32, 0);
          if (this.o != null)
            for (byte b1 = 0; b1 < this.o.length / 6; b1++) {
              if (this.o[1 + b1 * 6] == i && this.o[2 + b1 * 6] == b)
                for (byte b2 = 0; b2 < 10; b2++) {
                  if (this.o[4 + b1 * 6] * 100 / this.o[3 + b1 * 6] > b2 * 10) {
                    a(paramGraphics, j, k + 16 - e.b * b2, true, this.o[5 + b1 * 6]);
                  } else {
                    a(paramGraphics, j, k + 16 - e.b * b2, false, this.o[5 + b1 * 6]);
                  } 
                }  
            }  
        } 
      } 
    } 
  }
  
  private void a(Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3) {
    for (byte b = -1; b < paramInt2; b++) {
      paramInt1 = d(this.g + paramInt3, this.h + b);
      int i = e(this.g + paramInt3, this.h + b);
      paramGraphics.drawImage(c.a[16], paramInt1 + 31 + 5, i - 15, 0);
    } 
  }
  
  private void b(Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3) {
    for (byte b = -1; b < paramInt2; b++) {
      paramInt1 = d(this.g + b, this.h + paramInt3);
      int i = e(this.g + b, this.h + paramInt3);
      paramGraphics.drawImage(c.a[19], paramInt1 - 10, i - c.a[19].getHeight() + 5, 0);
    } 
  }
  
  private void c(Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3) {
    for (int i = paramInt1; i < paramInt2; i++) {
      paramInt1 = d(this.g + paramInt3, this.h + i);
      int j = e(this.g + paramInt3, this.h + i);
      paramGraphics.drawImage(c.f[0], paramInt1 + 31 - 4 - 2, j - 25, 0);
    } 
  }
  
  private void d(Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3) {
    for (int i = paramInt1; i < paramInt2; i++) {
      paramInt1 = d(this.g + i, this.h);
      paramInt3 = e(this.g + i, this.h);
      paramGraphics.drawImage(c.f[2], paramInt1 - 5, paramInt3 - 31 + 5, 0);
    } 
  }
  
  public final void f(Graphics paramGraphics) {
    b(paramGraphics, -1, this.b.length, 0);
    paramGraphics.drawImage(c.a[23], d(this.g + 2, this.h), e(this.g + 2, this.h) - 32, 0);
    a(paramGraphics, -1, this.b.length, 6);
    paramGraphics.drawImage(c.a[20], d(this.g + 7, this.h - 1) + 1, e(this.g + 7, this.h - 1) - 1, 0);
    a(paramGraphics, -1, this.b.length, -2);
    b(paramGraphics, -1, this.b.length, 8);
    paramGraphics.drawImage(c.a[21], d(this.g + 6, this.h + 6) + 62 + 1, e(this.g + 5, this.h + 4) + 16 - 1, 0);
    paramGraphics.drawImage(c.a[22], d(this.g - 1, this.h + 6) + 31 + 1, e(this.g - 1, this.h + 6) + 16 - 1, 0);
    paramGraphics.drawImage(c.a[17], d(this.g - 1, this.h + 2) + 31 + 1, e(this.g - 1, this.h + 3) - 1, 0);
    paramGraphics.drawImage(c.a[18], d(this.g - 2, this.h - 2) + 62 + 1, e(this.g - 2, this.h - 2) - 1, 0);
  }
  
  public final void g(Graphics paramGraphics) {
    d(paramGraphics, 0, this.b.length / 2, 0);
    d(paramGraphics, this.b.length / 2 + 1, this.b.length, 0);
    c(paramGraphics, 0, this.b.length, 6);
    paramGraphics.drawImage(c.f[3], d(this.g + 6, this.h - 1) + 62 - 9, e(this.g + 6, this.h - 1) + 3 - c.f[3].getHeight() + 16, 0);
    paramGraphics.drawImage(c.f[4], d(this.g + 3, this.h) + 5 - 5, e(this.g + 3, this.h) - 20, 0);
  }
  
  public final void h(Graphics paramGraphics) {
    c(paramGraphics, 0, this.b.length / 2, -1);
    c(paramGraphics, this.b.length / 2 + 1, this.b.length, -1);
    byte b1 = 2;
    b1 = 7;
    int i = (this.b[0]).length;
    b1 = 0;
    Graphics graphics = paramGraphics;
    s s1 = this;
    for (byte b2 = 0; b2 < i; b2++) {
      int j = s1.d(s1.g + b2, s1.h + 7);
      int k = s1.e(s1.g + b2, s1.h + 7);
      graphics.drawImage(c.f[2], j - 5 + 2, k - 31 + 5 + 2, 0);
    } 
    paramGraphics.drawImage(c.f[3], d(this.g - 1, this.h - 1) + 62 - 9 - 1, e(this.g - 1, this.h - 1) + 3 - c.f[3].getHeight() + 16 - 1, 0);
    paramGraphics.drawImage(c.f[3], d(this.g - 1, this.h + 6) + 62 - 7, e(this.g - 1, this.h + 6) + 5 - c.f[3].getHeight() + 16, 0);
    paramGraphics.drawImage(c.f[3], d(this.g + 6, this.h + 6) + 62 - 7 - 1, e(this.g + 6, this.h + 6) + 5 - c.f[3].getHeight() + 16 - 1, 0);
    paramGraphics.drawImage(c.f[1], d(this.g - 1, this.h + 3) + 31 - 6, e(this.g - 1, this.h + 3) - 25, 0);
  }
  
  public final void a(Graphics paramGraphics, int paramInt) {
    if (paramInt <= 0)
      paramGraphics.drawImage(c.h, this.k + this.e * 31 + this.f * 31, this.l + (this.f << 4) - (this.e << 4), 0); 
    if (paramInt == 1)
      paramGraphics.drawImage(c.i, this.k + this.e * 31 + this.f * 31, this.l + (this.f << 4) - (this.e << 4), 0); 
    if (paramInt == 2)
      paramGraphics.drawImage(c.j, this.k + this.e * 31 + this.f * 31, this.l + (this.f << 4) - (this.e << 4), 0); 
  }
  
  public final void i(Graphics paramGraphics) {
    paramGraphics.setFont(h.d);
    int i = paramGraphics.getFont().stringWidth("Игрок: WWWWWWWW");
    int j = 1;
    if (this.a[this.f][this.e] > 0)
      j = 5; 
    j = paramGraphics.getFont().getHeight() * j + 10;
    int k = i.a - i;
    int m = c.b[11].getHeight() + c.b[4].getHeight();
    int n = k + 5;
    int i1 = m + 5;
    paramGraphics.setColor(2233600);
    paramGraphics.fillRect(k, m, i, j);
    paramGraphics.setColor(11642239);
    paramGraphics.drawRect(k + 1, m + 1, i - 3, j - 3);
    paramGraphics.setColor(14793067);
    paramGraphics.drawRect(k + 3, m + 3, i - 7, j - 7);
    paramGraphics.setColor(0);
    paramGraphics.drawRect(k + 4, m + 4, i - 9, j - 9);
    paramGraphics.setColor(16777215);
    paramGraphics.drawString("X:" + Integer.toString(this.m - 3 + this.e) + " Y:" + Integer.toString(this.n - 3 + this.f), n, i1, 20);
    if (this.a[this.f][this.e] > 0) {
      k.a();
      String[] arrayOfString;
      String str1 = (arrayOfString = k.b(this.e, this.f))[0];
      String str2 = arrayOfString[1];
      String str3 = arrayOfString[2];
      String str4 = arrayOfString[3];
      String str5 = this;
      if (paramGraphics.getFont().stringWidth(str5) < i - 9) {
        paramGraphics.drawString(str5, n, i1 + paramGraphics.getFont().getHeight(), 20);
      } else {
        r.a();
        paramGraphics.drawString(r.a(paramGraphics, "", this, i - 9), n, i1 + paramGraphics.getFont().getHeight(), 20);
      } 
      str5 = str2;
      if (paramGraphics.getFont().stringWidth(str5) < i - 9) {
        paramGraphics.drawString(str5, n, i1 + (paramGraphics.getFont().getHeight() << 1), 20);
      } else {
        r.a();
        paramGraphics.drawString(r.a(paramGraphics, "", str2, i - 9), n, i1 + (paramGraphics.getFont().getHeight() << 1), 20);
      } 
      str5 = str3;
      if (paramGraphics.getFont().stringWidth(str5) < i - 9) {
        paramGraphics.drawString(str5, n, i1 + paramGraphics.getFont().getHeight() * 3, 20);
      } else {
        r.a();
        paramGraphics.drawString(r.a(paramGraphics, "", str3, i - 9), n, i1 + paramGraphics.getFont().getHeight() * 3, 20);
      } 
      if (str4 != null)
        paramGraphics.drawString(str4, n, i1 + (paramGraphics.getFont().getHeight() << 2), 20); 
    } 
  }
}


/* Location:              C:\Users\sora\Desktop\Third_World_War_of_Kings_2D.jar!\s.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */