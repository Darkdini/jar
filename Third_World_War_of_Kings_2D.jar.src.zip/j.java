import com.fenix.main.c;
import com.fenix.main.h;
import javax.microedition.lcdui.Graphics;

public final class j extends n {
  private int a;
  
  private String b;
  
  public j() {
    c(false);
  }
  
  public final void e(int paramInt) {
    this.a = paramInt;
  }
  
  public final int a() {
    return this.a;
  }
  
  public final void a(String paramString) {
    this.b = paramString;
  }
  
  public final void a(Graphics paramGraphics) {
    int i;
    int k;
    int m;
    int i1;
    int i2;
    int i3;
    int i4;
    int i5;
    int i6;
    int i7;
    int i8;
    int i9;
    int i10;
    if (!g())
      return; 
    switch (this.a) {
      case 0:
        paramGraphics = paramGraphics;
        i = (this = this).k();
        k = l();
        m = m();
        i1 = n();
        i2 = c.n.getHeight();
        i3 = c.n.getWidth();
        i4 = i1 / i2;
        i5 = (m + 10) / i3;
        i6 = (m + 10) % i3;
        paramGraphics.setColor(3604480);
        paramGraphics.fillRect(i - 5, k, m + 10, i1);
        m = paramGraphics.getClipX();
        i1 = paramGraphics.getClipY();
        i7 = paramGraphics.getClipWidth();
        i8 = paramGraphics.getClipHeight();
        i9 = k;
        if (k - i1 < 0)
          i9 = i1; 
        i10 = i2;
        if (k + i2 > i1 + i8)
          i10 = i2 - k + i2 - i1 - i8; 
        paramGraphics.setClip(i - 5 + i5 * i3, i9, i6, i10);
        paramGraphics.drawImage(c.n, paramGraphics.getClipX(), k, 0);
        paramGraphics.setClip(m, i1, i7, i8);
        for (m = 0; m < i4 + 1; m++) {
          if (m < i4)
            for (i1 = 0; i1 < i5; i1++)
              paramGraphics.drawImage(c.n, i - 5 + i1 * i3, k + m * i2, 0);  
        } 
        paramGraphics.setColor(2233600);
        paramGraphics.drawLine(k() - 5, l() + n() - 2, k() + m() + 10, l() + n() - 2);
        paramGraphics.drawLine(k() - 5, l() + 2, k() + m() + 10, l() + 2);
        paramGraphics.setColor(11642239);
        paramGraphics.drawLine(k() - 5, l() + n() - 1, k() + m() + 10, l() + n() - 1);
        paramGraphics.drawLine(k() - 5, l() + 1, k() + m() + 10, l() + 1);
        paramGraphics.setColor(0);
        paramGraphics.drawLine(k() - 5, l() + n(), k() + m() + 10, l() + n());
        paramGraphics.drawLine(k() - 5, l(), k() + m() + 10, l());
        paramGraphics.setColor(16777215);
        paramGraphics.setFont(h.d);
        paramGraphics.drawString(this.b, k() + m() / 2 - paramGraphics.getFont().stringWidth(this.b) / 2, l() + n() / 2 - paramGraphics.getFont().getHeight() / 2, 0);
        return;
      case 1:
        paramGraphics = paramGraphics;
        this = this;
        paramGraphics.setColor(0);
        paramGraphics.drawLine(k(), l() + n() / 2 - 1, k() + m(), l() + n() / 2 - 1);
        paramGraphics.drawLine(k(), l() + n() / 2 + 1, k() + m(), l() + n() / 2 + 1);
        paramGraphics.setColor(11642239);
        paramGraphics.drawLine(k(), l() + n() / 2, k() + m(), l() + n() / 2);
        break;
    } 
  }
}


/* Location:              C:\Users\sora\Desktop\Third_World_War_of_Kings_2D.jar!\j.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */