import com.fenix.main.g;
import java.io.ByteArrayOutputStream;

public class g {
  private int a;
  
  private ag b;
  
  private static g c;
  
  public g(ag paramag) {
    this.a = 0;
    c = this;
    this.b = paramag;
  }
  
  public static g a() {
    return c;
  }
  
  protected final void b() {
    (this = this).a = 0;
  }
  
  public final int c() {
    return this.a;
  }
  
  public final void a(d paramd) {
    // Byte code:
    //   0: aload_1
    //   1: dup
    //   2: astore_2
    //   3: invokevirtual a : ()I
    //   6: dup
    //   7: istore_2
    //   8: lookupswitch default -> 337, 1 -> 36, 4 -> 198
    //   36: aload_0
    //   37: aload_1
    //   38: astore_1
    //   39: astore_0
    //   40: aload_1
    //   41: invokevirtual b : ()I
    //   44: dup
    //   45: istore_2
    //   46: lookupswitch default -> 197, 0 -> 64
    //   64: ldc '28092009x3'
    //   66: dup
    //   67: astore_1
    //   68: invokevirtual getBytes : ()[B
    //   71: astore_2
    //   72: bipush #10
    //   74: invokestatic a : (I)Ljavax/microedition/lcdui/Image;
    //   77: ifnonnull -> 140
    //   80: iconst_4
    //   81: newarray byte
    //   83: dup
    //   84: astore_1
    //   85: iconst_0
    //   86: getstatic com/fenix/main/i.a : I
    //   89: istore #5
    //   91: istore #4
    //   93: dup
    //   94: astore_3
    //   95: iload #4
    //   97: iload #5
    //   99: iconst_1
    //   100: invokestatic a : ([BIIZ)V
    //   103: aload_1
    //   104: iconst_2
    //   105: getstatic com/fenix/main/i.b : I
    //   108: istore #5
    //   110: istore #4
    //   112: dup
    //   113: astore_3
    //   114: iload #4
    //   116: iload #5
    //   118: iconst_1
    //   119: invokestatic a : ([BIIZ)V
    //   122: aload_0
    //   123: getfield b : Lag;
    //   126: new d
    //   129: dup
    //   130: iconst_1
    //   131: iconst_1
    //   132: iconst_1
    //   133: aload_1
    //   134: invokespecial <init> : (III[B)V
    //   137: invokevirtual a : (Lx;)V
    //   140: invokestatic b : ()I
    //   143: dup
    //   144: istore_1
    //   145: iconst_m1
    //   146: if_icmpeq -> 179
    //   149: iconst_4
    //   150: newarray byte
    //   152: dup
    //   153: astore_3
    //   154: iconst_0
    //   155: iload_1
    //   156: i2l
    //   157: invokestatic a : ([BIJ)V
    //   160: aload_0
    //   161: getfield b : Lag;
    //   164: new d
    //   167: dup
    //   168: iconst_1
    //   169: iconst_4
    //   170: bipush #12
    //   172: aload_3
    //   173: invokespecial <init> : (III[B)V
    //   176: invokevirtual a : (Lx;)V
    //   179: aload_0
    //   180: getfield b : Lag;
    //   183: new d
    //   186: dup
    //   187: iconst_1
    //   188: iconst_1
    //   189: iconst_0
    //   190: aload_2
    //   191: invokespecial <init> : (III[B)V
    //   194: invokevirtual a : (Lx;)V
    //   197: return
    //   198: aload_0
    //   199: aload_1
    //   200: astore_1
    //   201: astore_0
    //   202: aload_1
    //   203: invokevirtual b : ()I
    //   206: dup
    //   207: istore_2
    //   208: tableswitch default -> 337, 0 -> 256, 1 -> 337, 2 -> 337, 3 -> 337, 4 -> 337, 5 -> 303, 6 -> 333, 7 -> 337
    //   256: invokestatic a : ()Lcom/fenix/main/b;
    //   259: astore_1
    //   260: invokestatic a : ()Lcom/fenix/main/g;
    //   263: dup
    //   264: astore_2
    //   265: invokevirtual b : ()V
    //   268: aload_1
    //   269: aload_2
    //   270: invokevirtual a : (Lcom/fenix/main/f;)V
    //   273: invokestatic a : ()Lcom/fenix/main/i;
    //   276: invokevirtual repaint : ()V
    //   279: invokestatic a : ()Lcom/fenix/main/i;
    //   282: invokevirtual serviceRepaints : ()V
    //   285: invokestatic a : ()Lcom/fenix/main/i;
    //   288: pop
    //   289: ldc2_w 100
    //   292: invokestatic a : (J)V
    //   295: invokestatic a : ()Lcom/fenix/main/g;
    //   298: pop
    //   299: invokestatic c : ()V
    //   302: return
    //   303: aload_1
    //   304: invokevirtual c : ()[B
    //   307: arraylength
    //   308: ifle -> 327
    //   311: aload_1
    //   312: invokevirtual c : ()[B
    //   315: dup
    //   316: astore_1
    //   317: iconst_0
    //   318: invokestatic c : ([BI)J
    //   321: l2i
    //   322: dup
    //   323: istore_3
    //   324: invokestatic b : (I)V
    //   327: aload_0
    //   328: iconst_3
    //   329: putfield a : I
    //   332: return
    //   333: invokestatic a : ()Ly;
    //   336: pop
    //   337: return
  }
  
  public final void d() {
    try {
      ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
      String str1 = g.a;
      String str2 = g.b;
      str1 = str1.toLowerCase();
      str2 = str2.toLowerCase();
      ab.a(1, byteArrayOutputStream, a(str1));
      ab.a(2, byteArrayOutputStream, a(str2));
      if (!str1.toUpperCase().equals("LOGIN") || !str2.toUpperCase().equals("PASSWORD"))
        r.a(str1, str2); 
      this.b.a(new d(1, 4, 5, byteArrayOutputStream.toByteArray()));
      return;
    } catch (Exception exception) {
      System.err.println("login()->" + exception);
      return;
    } 
  }
  
  public g() {}
  
  public static void a(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
    paramArrayOfbyte[paramInt1] = (byte)paramInt2;
  }
  
  public static void a(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, boolean paramBoolean) {
    paramArrayOfbyte[paramInt1] = (byte)(paramInt2 >> 8);
    paramArrayOfbyte[++paramInt1] = (byte)paramInt2;
  }
  
  public static byte[] a(int paramInt) {
    int i = paramInt;
    boolean bool = false;
    byte[] arrayOfByte1;
    byte[] arrayOfByte2;
    a(arrayOfByte1 = arrayOfByte2 = new byte[2], bool, i, true);
    return arrayOfByte2;
  }
  
  public static int a(byte[] paramArrayOfbyte, int paramInt) {
    int i;
    return i = paramArrayOfbyte[paramInt] & 0xFF;
  }
  
  public static int b(byte[] paramArrayOfbyte, int paramInt) {
    boolean bool = true;
    paramInt = paramInt;
    byte[] arrayOfByte;
    int i;
    return i = (i = (arrayOfByte = paramArrayOfbyte)[paramInt] << 8 & 0xFF00) | arrayOfByte[++paramInt] & 0xFF;
  }
  
  public static void a(ByteArrayOutputStream paramByteArrayOutputStream, int paramInt, boolean paramBoolean) {
    paramByteArrayOutputStream.write(paramInt >> 8 & 0xFF & 0xFF);
    paramByteArrayOutputStream.write(paramInt & 0xFF);
  }
  
  public static long c(byte[] paramArrayOfbyte, int paramInt) {
    boolean bool = true;
    paramInt = paramInt;
    byte[] arrayOfByte;
    long l;
    return l = (l = (l = (l = (arrayOfByte = paramArrayOfbyte)[paramInt] << 24L & 0xFFFFFFFFFF000000L) | arrayOfByte[++paramInt] << 16L & 0xFF0000L) | arrayOfByte[++paramInt] << 8L & 0xFF00L) | arrayOfByte[++paramInt] & 0xFFL;
  }
  
  public static void a(byte[] paramArrayOfbyte, int paramInt, long paramLong) {
    boolean bool = true;
    long l = paramLong;
    paramInt = 0;
    byte[] arrayOfByte;
    (arrayOfByte = paramArrayOfbyte)[paramInt] = (byte)(int)(l >> 24L & 0xFFL);
    arrayOfByte[++paramInt] = (byte)(int)(l >> 16L & 0xFFL);
    arrayOfByte[++paramInt] = (byte)(int)(l >> 8L & 0xFFL);
    arrayOfByte[++paramInt] = (byte)(int)(l & 0xFFL);
  }
  
  public static byte[] a(String paramString) {
    byte[] arrayOfByte = paramString.getBytes();
    for (byte b = 0; b < paramString.length(); b++) {
      char c;
      switch (c = paramString.charAt(b)) {
        case 'Ё':
          arrayOfByte[b] = -88;
          break;
        case 'ё':
          arrayOfByte[b] = -72;
          break;
        case 'Ґ':
          arrayOfByte[b] = -91;
          break;
        case 'Є':
          arrayOfByte[b] = -86;
          break;
        case 'Ї':
          arrayOfByte[b] = -81;
          break;
        case 'І':
          arrayOfByte[b] = -78;
          break;
        case 'і':
          arrayOfByte[b] = -77;
          break;
        case 'ґ':
          arrayOfByte[b] = -76;
          break;
        case 'є':
          arrayOfByte[b] = -70;
          break;
        case 'ї':
          arrayOfByte[b] = -65;
          break;
        default:
          if ((c = c) >= 'А' && c <= 'я')
            arrayOfByte[b] = (byte)(c - 1040 + 192); 
          break;
      } 
    } 
    return arrayOfByte;
  }
  
  public static String b(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
    String str = new String(paramArrayOfbyte, paramInt1, paramInt2);
    StringBuffer stringBuffer = new StringBuffer(paramInt2);
    for (byte b = 0; b < paramInt2; b++) {
      int i;
      switch (i = paramArrayOfbyte[b + paramInt1] & 0xFF) {
        case 168:
          stringBuffer.append('Ё');
          break;
        case 184:
          stringBuffer.append('ё');
          break;
        case 165:
          stringBuffer.append('Ґ');
          break;
        case 170:
          stringBuffer.append('Є');
          break;
        case 175:
          stringBuffer.append('Ї');
          break;
        case 178:
          stringBuffer.append('І');
          break;
        case 179:
          stringBuffer.append('і');
          break;
        case 180:
          stringBuffer.append('ґ');
          break;
        case 186:
          stringBuffer.append('є');
          break;
        case 191:
          stringBuffer.append('ї');
          break;
        default:
          if (i >= 192 && i <= 255) {
            stringBuffer.append((char)(i + 1040 - 192));
            break;
          } 
          stringBuffer.append(str.charAt(b));
          break;
      } 
    } 
    return stringBuffer.toString();
  }
}


/* Location:              C:\Users\sora\Desktop\Third_World_War_of_Kings_2D.jar!\g.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */