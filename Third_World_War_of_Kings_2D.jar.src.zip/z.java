import com.fenix.main.c;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;

public final class z extends n {
  private Image a = null;
  
  private int b;
  
  public z() {
    c(false);
  }
  
  public final void e(int paramInt) {
    this.a = c.a(paramInt);
    this.b = paramInt;
    if (this.a == null) {
      int[] arrayOfInt;
      (arrayOfInt = new int[1])[0] = paramInt;
      k.a();
      k.a(this);
    } 
  }
  
  public final int a() {
    return (this.a != null) ? this.a.getWidth() : 0;
  }
  
  public final int b() {
    return (this.a != null) ? this.a.getHeight() : 0;
  }
  
  public final void a(Graphics paramGraphics) {
    if (!g())
      return; 
    if (this.a != null && this.a != c.q) {
      paramGraphics.drawImage(this.a, k(), l(), 0);
      return;
    } 
    paramGraphics.drawImage(c.q, k(), l(), 0);
    this.a = c.a(this.b);
  }
}


/* Location:              C:\Users\sora\Desktop\Third_World_War_of_Kings_2D.jar!\z.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */