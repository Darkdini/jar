import java.io.ByteArrayOutputStream;

public final class f extends x {
  public final byte[] d() {
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    f f1 = this;
    ab.a(1, byteArrayOutputStream, null.getBytes());
    f1 = this;
    ab.a(2, byteArrayOutputStream, null.getBytes());
    f1 = this;
    ab.a(4, byteArrayOutputStream, null.getBytes());
    int i = 0;
    byte b = 0;
    byte[] arrayOfByte1;
    byte[] arrayOfByte2;
    g.a(arrayOfByte2 = arrayOfByte1 = new byte[2], b, i, true);
    ab.a(8, byteArrayOutputStream, this);
    g.a(arrayOfByte1 = new byte[byteArrayOutputStream.size() + 6], 0, 42);
    g.a(this, 1, 1);
    i = 50;
    b = 2;
    g.a(arrayOfByte2 = this, b, i, true);
    i = this.length - 6;
    b = 4;
    g.a(arrayOfByte2 = this, b, i, true);
    System.arraycopy(byteArrayOutputStream.toByteArray(), 0, this, 6, byteArrayOutputStream.size());
    return this;
  }
  
  public static x a(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
    if (paramArrayOfbyte.length < 4)
      throw new ac(2, 2); 
    int i = g.b(paramArrayOfbyte, paramInt1);
    int j = g.b(paramArrayOfbyte, paramInt1 + 2);
    byte[] arrayOfByte = new byte[paramInt2 - 4];
    System.arraycopy(paramArrayOfbyte, paramInt1 + 4, arrayOfByte, 0, paramInt2 - 4);
    return new d(1, i, j, arrayOfByte);
  }
}


/* Location:              C:\Users\sora\Desktop\Third_World_War_of_Kings_2D.jar!\f.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */