import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.util.Vector;
import javax.microedition.lcdui.Graphics;
import javax.microedition.rms.RecordStore;

public final class r {
  private static String d = "Login";
  
  private static String e = "UIN";
  
  private static r f = null;
  
  private static int g = 0;
  
  public static final int[] a = new int[] { g++, g++, g++, g++, g++, g++, g++, g++ };
  
  public static final int[] b = new int[] { g++, g++, g++, g++ };
  
  public static final int[] c = new int[] { g++, g++, g++ };
  
  private String[] h = null;
  
  public static r a() {
    if (f == null)
      f = new r(); 
    return f;
  }
  
  private r() {
    String[] arrayOfString = a("/texts/strings.txt");
    this.h = arrayOfString;
  }
  
  private String[] a(String paramString) {
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    String[] arrayOfString = null;
    try {
      InputStream inputStream = getClass().getResourceAsStream(paramString);
      Vector vector = new Vector();
      while (true) {
        String str;
        int i;
        switch (i = read()) {
          case -1:
          case 10:
          case 13:
            if (byteArrayOutputStream.size() > 0 && !(str = new String(byteArrayOutputStream.toByteArray(), "UTF-8")).startsWith("//"))
              vector.addElement(str); 
            byteArrayOutputStream.reset();
            break;
          default:
            byteArrayOutputStream.write(i);
            break;
        } 
        if (i == -1) {
          if (vector.size() > 0) {
            arrayOfString = new String[vector.size()];
            for (byte b = 0; b < arrayOfString.length; b++)
              arrayOfString[b] = vector.elementAt(b); 
          } 
          return arrayOfString;
        } 
      } 
    } catch (Exception exception) {
      return null;
    } 
  }
  
  public final String a(int paramInt) {
    return this.h[paramInt];
  }
  
  public static void b(int paramInt) {
    RecordStore recordStore = null;
    try {
      if ((recordStore = RecordStore.openRecordStore(e, true)).getNumRecords() > 0)
        try {
          return;
        } catch (Exception exception) {
          System.out.println("Error on loadImageToRms");
          return;
        }  
      ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
      DataOutputStream dataOutputStream;
      (dataOutputStream = new DataOutputStream(byteArrayOutputStream)).writeInt(paramInt);
      dataOutputStream.flush();
      byte[] arrayOfByte = byteArrayOutputStream.toByteArray();
      recordStore.addRecord(arrayOfByte, 0, arrayOfByte.length);
      dataOutputStream.close();
    } catch (Exception exception2) {
      Exception exception1;
      (exception1 = null).printStackTrace();
    } finally {
      try {
        if (recordStore != null)
          recordStore.closeRecordStore(); 
      } catch (Exception exception) {
        System.out.println("Error on loadImageToRms");
        System.err.println(exception);
      } 
    } 
  }
  
  public static int b() {
    RecordStore recordStore = null;
    try {
      if ((recordStore = RecordStore.openRecordStore(e, true)).getNumRecords() > 0) {
        byte[] arrayOfByte = recordStore.getRecord(1);
        ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(arrayOfByte);
        DataInputStream dataInputStream;
        return (dataInputStream = new DataInputStream(byteArrayInputStream)).readInt();
      } 
    } catch (Exception exception2) {
      Exception exception1;
      (exception1 = null).printStackTrace();
    } finally {
      try {
        if (exception != null)
          exception.closeRecordStore(); 
      } catch (Exception exception1) {
        System.out.println("Error on getUnicalID");
        System.err.println(exception1);
      } 
    } 
    return -1;
  }
  
  public static void a(String paramString1, String paramString2) {
    RecordStore recordStore = null;
    try {
      String str = d;
      try {
        RecordStore.deleteRecordStore(str);
      } catch (Exception exception) {
        System.out.println("Error on clearRMS");
        exception.printStackTrace();
      } 
      recordStore = RecordStore.openRecordStore(d, true);
      byte[] arrayOfByte1 = paramString1.getBytes();
      byte[] arrayOfByte2 = paramString2.getBytes();
      byte[] arrayOfByte3;
      (arrayOfByte3 = new byte[arrayOfByte1.length + arrayOfByte2.length + 2])[0] = (byte)arrayOfByte1.length;
      arrayOfByte3[1] = (byte)arrayOfByte2.length;
      System.arraycopy(arrayOfByte1, 0, arrayOfByte3, 2, arrayOfByte1.length);
      System.arraycopy(arrayOfByte2, 0, arrayOfByte3, arrayOfByte1.length + 2, arrayOfByte2.length);
      recordStore.addRecord(arrayOfByte3, 0, arrayOfByte3.length);
    } catch (Exception exception) {
      (paramString1 = null).printStackTrace();
    } finally {
      try {
        if (recordStore != null)
          recordStore.closeRecordStore(); 
      } catch (Exception exception) {
        System.out.println("Error on SaveLoginInfo");
        System.err.println(exception);
      } 
    } 
  }
  
  public static String[] c() {
    RecordStore recordStore = null;
    try {
      if ((recordStore = RecordStore.openRecordStore(d, true)).getNumRecords() > 0) {
        byte[] arrayOfByte = recordStore.getRecord(1);
        String str2 = new String(arrayOfByte, 2, arrayOfByte[0]);
        String str1 = new String(arrayOfByte, 2 + arrayOfByte[0], arrayOfByte[1]);
        String[] arrayOfString;
        (arrayOfString = new String[2])[0] = str2;
        arrayOfString[1] = str1;
        return arrayOfString;
      } 
      return null;
    } catch (Exception exception2) {
      Exception exception1;
      (exception1 = null).printStackTrace();
    } finally {
      try {
        if (exception != null)
          exception.closeRecordStore(); 
      } catch (Exception exception1) {
        System.out.println("Error on loadImageFromRms");
        System.err.println(exception1);
      } 
    } 
    return null;
  }
  
  public static String a(Graphics paramGraphics, String paramString1, String paramString2, int paramInt) {
    paramInt = (paramInt -= paramGraphics.getFont().stringWidth(paramString1)) - paramGraphics.getFont().stringWidth("...");
    for (byte b = 1; b < paramString2.length(); b++) {
      int i = paramGraphics.getFont().stringWidth(paramString2.substring(b - 1, b));
      if (paramInt >= i) {
        paramInt -= i;
      } else {
        return paramString1 + paramString2.substring(0, b - 1) + "...";
      } 
    } 
    return paramString1 + paramString2 + "...";
  }
  
  static {
    (new int[46])[0] = g++;
    (new int[46])[1] = g++;
    (new int[46])[2] = g++;
    (new int[46])[3] = g++;
    (new int[46])[4] = g++;
    (new int[46])[5] = g++;
    (new int[46])[6] = g++;
    (new int[46])[7] = g++;
    (new int[46])[8] = g++;
    (new int[46])[9] = g++;
    (new int[46])[10] = g++;
    (new int[46])[11] = g++;
    (new int[46])[12] = g++;
    (new int[46])[13] = g++;
    (new int[46])[14] = g++;
    (new int[46])[15] = g++;
    (new int[46])[16] = g++;
    (new int[46])[17] = g++;
    (new int[46])[18] = g++;
    (new int[46])[19] = g++;
    (new int[46])[20] = g++;
    (new int[46])[21] = g++;
    (new int[46])[22] = g++;
    (new int[46])[23] = g++;
    (new int[46])[24] = g++;
    (new int[46])[25] = g++;
    (new int[46])[26] = g++;
    (new int[46])[27] = g++;
    (new int[46])[28] = g++;
    (new int[46])[29] = g++;
    (new int[46])[30] = g++;
    (new int[46])[31] = g++;
    (new int[46])[32] = g++;
    (new int[46])[33] = g++;
    (new int[46])[34] = g++;
    (new int[46])[35] = g++;
    (new int[46])[36] = g++;
    (new int[46])[37] = g++;
    (new int[46])[38] = g++;
    (new int[46])[39] = g++;
    (new int[46])[40] = g++;
    (new int[46])[41] = g++;
    (new int[46])[42] = g++;
    (new int[46])[43] = g++;
    (new int[46])[44] = g++;
    (new int[46])[45] = g++;
    (new int[46])[0] = g++;
    (new int[46])[1] = g++;
    (new int[46])[2] = g++;
    (new int[46])[3] = g++;
    (new int[46])[4] = g++;
    (new int[46])[5] = g++;
    (new int[46])[6] = g++;
    (new int[46])[7] = g++;
    (new int[46])[8] = g++;
    (new int[46])[9] = g++;
    (new int[46])[10] = g++;
    (new int[46])[11] = g++;
    (new int[46])[12] = g++;
    (new int[46])[13] = g++;
    (new int[46])[14] = g++;
    (new int[46])[15] = g++;
    (new int[46])[16] = g++;
    (new int[46])[17] = g++;
    (new int[46])[18] = g++;
    (new int[46])[19] = g++;
    (new int[46])[20] = g++;
    (new int[46])[21] = g++;
    (new int[46])[22] = g++;
    (new int[46])[23] = g++;
    (new int[46])[24] = g++;
    (new int[46])[25] = g++;
    (new int[46])[26] = g++;
    (new int[46])[27] = g++;
    (new int[46])[28] = g++;
    (new int[46])[29] = g++;
    (new int[46])[30] = g++;
    (new int[46])[31] = g++;
    (new int[46])[32] = g++;
    (new int[46])[33] = g++;
    (new int[46])[34] = g++;
    (new int[46])[35] = g++;
    (new int[46])[36] = g++;
    (new int[46])[37] = g++;
    (new int[46])[38] = g++;
    (new int[46])[39] = g++;
    (new int[46])[40] = g++;
    (new int[46])[41] = g++;
    (new int[46])[42] = g++;
    (new int[46])[43] = g++;
    (new int[46])[44] = g++;
    (new int[46])[45] = g++;
    (new int[21])[0] = g++;
    (new int[21])[1] = g++;
    (new int[21])[2] = g++;
    (new int[21])[3] = g++;
    (new int[21])[4] = g++;
    (new int[21])[5] = g++;
    (new int[21])[6] = g++;
    (new int[21])[7] = g++;
    (new int[21])[8] = g++;
    (new int[21])[9] = g++;
    (new int[21])[10] = g++;
    (new int[21])[11] = g++;
    (new int[21])[12] = g++;
    (new int[21])[13] = g++;
    (new int[21])[14] = g++;
    (new int[21])[15] = g++;
    (new int[21])[16] = g++;
    (new int[21])[17] = g++;
    (new int[21])[18] = g++;
    (new int[21])[19] = g++;
    (new int[21])[20] = g++;
  }
}


/* Location:              C:\Users\sora\Desktop\Third_World_War_of_Kings_2D.jar!\r.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */