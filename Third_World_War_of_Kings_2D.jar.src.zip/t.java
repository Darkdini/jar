import com.fenix.main.h;
import javax.microedition.lcdui.Graphics;

public final class t extends n {
  private int a;
  
  private int b;
  
  private int c;
  
  private boolean d = false;
  
  private boolean e = false;
  
  private boolean f = false;
  
  private boolean g = false;
  
  public t() {
    c(false);
    d(h.d.getHeight() - 4);
  }
  
  public t(String paramString, int paramInt1, int paramInt2, int paramInt3) {
    String str = paramString;
    t t1;
    (t1 = this).b(str);
    this.a = paramInt1;
    this.b = paramInt2;
    this.c = paramInt3;
    d(h.e.getHeight());
    this.d = true;
    c(true);
  }
  
  public final void i(int paramInt) {
    this.f = true;
    super.i(paramInt);
  }
  
  public final void e(int paramInt) {
    byte[] arrayOfByte;
    if (!this.d)
      return; 
    switch (paramInt) {
      case 32:
      case 524288:
        System.out.println("Button clicked");
        if (!(this = this).f) {
          k.a();
          k.a(this.a, this.b, this.c, null);
          return;
        } 
        g.a(arrayOfByte = new byte[4], 0, q());
        k.a();
        k.a(this.a, this.b, this.c, arrayOfByte);
        break;
    } 
  }
  
  public final void a(Graphics paramGraphics) {
    a(paramGraphics, k(), l());
  }
  
  public final void a(Graphics paramGraphics, int paramInt1, int paramInt2) {
    if (!g())
      return; 
    paramGraphics.setColor(16777215);
    if (!this.d) {
      paramGraphics.getClipX();
      paramGraphics.getClipY();
      paramGraphics.getClipWidth();
      paramGraphics.getClipHeight();
      paramGraphics.setFont(h.d);
      paramGraphics.drawString(j(), paramInt1, paramInt2, 0);
      return;
    } 
    if (i()) {
      c(paramGraphics.getFont().stringWidth(j()));
      paramGraphics.setColor(11642239);
      paramGraphics.fillRect(paramInt1, paramInt2, m(), n());
    } 
    paramGraphics.setColor(255, 255, 255);
    paramGraphics.setFont(h.e);
    paramGraphics.drawString(j(), paramInt1, paramInt2, 0);
  }
}


/* Location:              C:\Users\sora\Desktop\Third_World_War_of_Kings_2D.jar!\t.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */