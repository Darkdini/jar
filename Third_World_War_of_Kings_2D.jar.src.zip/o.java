import com.fenix.main.Main;
import com.fenix.main.a;
import com.fenix.main.b;
import com.fenix.main.c;
import com.fenix.main.e;
import com.fenix.main.f;
import com.fenix.main.h;
import com.fenix.main.i;
import javax.microedition.lcdui.Graphics;

public final class o extends f implements a {
  private static o a;
  
  private int b = 0;
  
  private int c = 0;
  
  private int d = 0;
  
  private int e = 0;
  
  private int f = -1;
  
  private int g;
  
  private int h;
  
  private int i;
  
  private int j;
  
  private n[] k;
  
  private int l = 0;
  
  private int m = 0;
  
  private boolean n = false;
  
  private int[] o = new int[] { 0, 0, 0, 0, 0 };
  
  private int[] p = new int[] { 0, 0, 0, 0, 0 };
  
  private int[] q = new int[] { 0, 0, 0, 0, 0 };
  
  private String r = "";
  
  private boolean s = false;
  
  private int t = 10;
  
  private int u = 5;
  
  public static o a() {
    if (a == null)
      a = new o(); 
    return a;
  }
  
  public o() {
    a(this);
    this.g = i.a / 20;
    this.h = i.b / 20;
    this.i = i.a - i.a / 10;
    this.j = i.b - i.b / 10;
  }
  
  private void b(int paramInt) {
    if (this.k != null) {
      for (byte b = 0; b < this.k.length; b++)
        this.k[b].a(false); 
      this.k[paramInt].a(true);
    } 
  }
  
  public final void a(int paramInt) {
    h h;
    this.c = 0;
    if (this.k[this.l] instanceof v && ((v)this.k[this.l]).a == 1) {
      ((v)this.k[this.l]).e(paramInt);
      return;
    } 
    if (this.k[this.l] instanceof af && ((af)this.k[this.l]).a == 1) {
      ((af)this.k[this.l]).e(paramInt);
      if (((af)this.k[this.l]).a != 2)
        return; 
    } 
    if (this.k[this.l] instanceof aa && ((aa)this.k[this.l]).a == 1) {
      ((aa)this.k[this.l]).e(paramInt);
      return;
    } 
    switch (paramInt) {
      case 4096:
        return;
      case 32:
      case 524288:
        if (this.k != null) {
          if (this.k[this.l] instanceof aa && ((aa)this.k[this.l]).a == 0) {
            ((aa)this.k[this.l]).a = 1;
            return;
          } 
          if (this.k[this.l] instanceof af) {
            if (((af)this.k[this.l]).a == 0) {
              ((af)this.k[this.l]).a = 1;
              return;
            } 
            if (((af)this.k[this.l]).a == 2) {
              Main.a(this.k[this.l]);
              Main.a().b();
              ((af)this.k[this.l]).a = 0;
              return;
            } 
            if (((af)this.k[this.l]).a == 2)
              return; 
            break;
          } 
          if (this.k[this.l] instanceof t) {
            System.out.println("it is Label");
            ((t)this.k[this.l]).e(paramInt);
            return;
          } 
          if (this.k[this.l] instanceof v) {
            ((v)this.k[this.l]).a = 1;
            return;
          } 
          if (this.k[this.l] instanceof h) {
            switch ((h = (h)this.k[this.l]).d()) {
              default:
                break;
              case 0:
                System.out.println("Cancel");
                b.a().a(k.a());
                break;
              case 7:
                k.a();
                k.a(10, 15, 0, null);
                System.out.println("TRAAAADEEE");
                break;
              case 23:
              case 26:
                System.out.println("cMR.lotID ");
                break;
              case 24:
                k.a();
                k.a(10, 11, 1, null);
                break;
              case 25:
                break;
            } 
            k.a();
            k.a(10, 11, 2, null);
            return;
          } 
        } 
        break;
      case 8192:
        b.a().a(k.a());
        return;
      case 8:
      case 65536:
        switch (((o)super).c) {
          case 12:
            return;
        } 
        ((o)super).l--;
        if (((o)super).l < 0)
          ((o)super).l = ((o)super).m; 
        while (!((o)super).k[((o)super).l].f()) {
          ((o)super).l--;
          if (((o)super).l < 0)
            ((o)super).l = ((o)super).m; 
        } 
        super.b(((o)super).l);
        if (((o)super).k[((o)super).l] instanceof v && ((v)((o)super).k[((o)super).l]).a != 1)
          ((v)((o)super).k[((o)super).l]).a = 1; 
        System.out.println("UUUPPP");
        return;
      case 16:
      case 131072:
        switch (((o)super).c) {
          case 12:
            return;
        } 
        ((o)super).l++;
        if (((o)super).l > ((o)super).m)
          ((o)super).l = 0; 
        while (!((o)super).k[((o)super).l].f()) {
          ((o)super).l++;
          if (((o)super).l > ((o)super).m)
            ((o)super).l = 0; 
        } 
        super.b(((o)super).l);
        if (((o)super).k[((o)super).l] instanceof v && ((v)((o)super).k[((o)super).l]).a != 1) {
          ((v)((o)super).k[((o)super).l]).a = 1;
          return;
        } 
        break;
      case 1024:
        ((o)super).d--;
        if (((o)super).d < 0) {
          ((o)super).d = 0;
          return;
        } 
        break;
      case 16384:
        ((o)super).d++;
        if (((o)super).d > 0)
          ((o)super).d = 0; 
        break;
    } 
  }
  
  public final void a(Graphics paramGraphics) {
    int i;
    int j;
    int k;
    int m;
    int i1;
    int i2;
    int i3;
    Graphics graphics = paramGraphics;
    o o1 = this;
    graphics.setColor(2233600);
    graphics.fillRect(o1.g - 5, o1.h - 5, o1.i + 10, o1.j + 10);
    graphics.setColor(11642239);
    graphics.drawRect(o1.g - 4, o1.h - 4, o1.i + 7, o1.j + 7);
    graphics.setColor(14793067);
    graphics.drawRect(o1.g - 2, o1.h - 2, o1.i + 3, o1.j + 3);
    graphics.setColor(0);
    graphics.drawRect(o1.g - 1, o1.h - 1, o1.i + 1, o1.j + 1);
    graphics = paramGraphics;
    o1 = this;
    graphics.setColor(7620648);
    graphics.fillRect(o1.g, o1.h, o1.i, o1.t);
    graphics.setColor(2233600);
    graphics.drawLine(o1.g - 3, o1.h + o1.t, o1.g - 5 + o1.i + 9 - 3, o1.h + o1.t);
    graphics.setColor(11642239);
    graphics.drawLine(o1.g - 3, o1.h + o1.t + 1, o1.g - 5 + o1.i + 9 - 3, o1.h + o1.t + 1);
    graphics.setColor(0);
    graphics.drawLine(o1.g, o1.h + o1.t + 2, o1.g - 5 + o1.i + 9 - 3, o1.h + o1.t + 2);
    graphics.setColor(16777215);
    graphics.setFont(h.d);
    graphics.drawString(e.a[0], o1.g + o1.i / 2 - graphics.getFont().stringWidth(e.a[0]) / 2, o1.h + o1.t / 2 - graphics.getFont().getHeight() / 2, 0);
    this.c = 0;
    if (this.d != this.f) {
      int i4 = this.c;
      if ((o1 = this).k != null) {
        for (byte b = 0; b < o1.k.length; b++)
          o1.k[b] = null; 
        o1.k = null;
      } 
      o1.l = 0;
      o1.m = 0;
      switch (i4) {
        case 9:
          o1.k = new n[1];
          o1.l = 0;
          o1.m = o1.k.length - 1;
          o1.k[0] = new h();
          ((h)o1.k[0]).f(0);
          o1.k[0].a(o1.g, o1.h + o1.j - 15, 50, 15);
          o1.k[0].a(true);
          break;
        case 12:
          o1.k = new n[5];
          o1.l = 0;
          o1.m = o1.k.length - 1;
          o1.k[0] = new h();
          ((h)o1.k[0]).f(0);
          o1.k[0].a(o1.g, o1.h + o1.j - 15, 50, 15);
          o1.k[0].a(true);
          o1.k[1] = new h();
          ((h)o1.k[1]).f(23);
          o1.k[1].a(o1.g + o1.i - 50, o1.h + o1.j - 15, 50, 15);
          o1.k[2] = new h();
          ((h)o1.k[2]).f(25);
          o1.k[2].a(o1.g, o1.h + o1.j - 15 - 20, 50, 15);
          o1.k[3] = new h();
          ((h)o1.k[3]).f(26);
          o1.k[3].a(o1.g + o1.i / 2 - 25, o1.h + o1.j - 15 - 20, 50, 15);
          o1.k[4] = new h();
          ((h)o1.k[4]).f(24);
          o1.k[4].a(o1.g + o1.i - 50, o1.h + o1.j - 15 - 20, 50, 15);
          break;
      } 
      this.f = this.d;
    } 
    switch (this.c) {
      case 9:
        i = this.g + 10;
        j = this.h + 30;
        k = this.i - 20;
        m = this.j - 70;
        i1 = i + h.d.stringWidth("Ресурс") + 2;
        i3 = (i2 = i + k - 55) - i1;
        paramGraphics.setColor(11642239);
        paramGraphics.drawRect(i, j, k, m);
        paramGraphics.drawLine(i, j + 15, i + k, j + 15);
        paramGraphics.drawLine(i1, j, i1, j + m);
        paramGraphics.drawLine(i2, j, i2, j + m);
        paramGraphics.setFont(h.d);
        paramGraphics.setColor(16777215);
        paramGraphics.drawString("Ресурс", i + 1, j + 7 - paramGraphics.getFont().getHeight() / 2, 0);
        paramGraphics.drawString("Добыча", i1 + i3 / 2 - paramGraphics.getFont().stringWidth("Добыча") / 2, j + 7 - paramGraphics.getFont().getHeight() / 2, 0);
        paramGraphics.drawString("Значение", i2 + 27 - paramGraphics.getFont().stringWidth("Значение") / 2, j + 7 - paramGraphics.getFont().getHeight() / 2, 0);
        for (k = 0; k < 5; k++) {
          paramGraphics.drawImage(c.g[k], i + (i1 - i) / 2 - c.g[k].getWidth() / 2, j + 15 * (k + 1) + 7 - c.g[k].getHeight() / 2, 0);
          paramGraphics.drawString(Integer.toString(this.p[k]), i1 + i3 / 2 - paramGraphics.getFont().stringWidth(Integer.toString(this.p[k])) / 2, j + 15 * (k + 1) + 7 - paramGraphics.getFont().getHeight() / 2, 0);
          paramGraphics.drawString(Integer.toString(this.o[k]) + "/" + Integer.toString(this.q[k]), i2 + 27 - paramGraphics.getFont().stringWidth(Integer.toString(this.o[k]) + "/" + Integer.toString(this.q[k])) / 2, j + 15 * (k + 1) + 7 - paramGraphics.getFont().getHeight() / 2, 0);
        } 
        break;
    } 
    if (this.k != null) {
      for (i = 0; i < this.k.length; i++)
        this.k[i].a(paramGraphics); 
      if (this.k[this.l] instanceof aa && ((aa)this.k[this.l]).a == 1)
        ((aa)this.k[this.l]).a(paramGraphics); 
    } 
  }
  
  public static void a(Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3) {
    if (paramInt3 == 0) {
      paramGraphics.drawLine(paramInt1 + 1, paramInt2 + 3, paramInt1 + 7, paramInt2 + 3);
      paramGraphics.drawLine(paramInt1 + 2, paramInt2 + 2, paramInt1 + 6, paramInt2 + 2);
      paramGraphics.drawLine(paramInt1 + 3, paramInt2 + 1, paramInt1 + 5, paramInt2 + 1);
      paramGraphics.drawLine(paramInt1 + 4, paramInt2, paramInt1 + 4, paramInt2);
    } 
    if (paramInt3 == 1) {
      paramGraphics.drawLine(paramInt1 + 1, paramInt2, paramInt1 + 7, paramInt2);
      paramGraphics.drawLine(paramInt1 + 2, paramInt2 + 1, paramInt1 + 6, paramInt2 + 1);
      paramGraphics.drawLine(paramInt1 + 3, paramInt2 + 2, paramInt1 + 5, paramInt2 + 2);
      paramGraphics.drawLine(paramInt1 + 4, paramInt2 + 3, paramInt1 + 4, paramInt2 + 3);
    } 
  }
  
  public static void a(Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7) {
    paramInt1--;
    paramGraphics.setColor(2230016);
    paramGraphics.fillRect(paramInt1, paramInt2, 11, paramInt4);
    paramInt3 = c.p.getHeight();
    int i = c.p.getWidth();
    int j = paramInt4 / paramInt3;
    int k;
    for (k = 0; k < j; k++)
      paramGraphics.drawImage(c.p, paramInt1 + 5 - i / 2, k * paramInt3 + paramInt2, 0); 
    k = paramInt4 % paramInt3;
    int m = paramGraphics.getClipX();
    int i1 = paramGraphics.getClipY();
    int i2 = paramGraphics.getClipWidth();
    int i3 = paramGraphics.getClipHeight();
    paramGraphics.setClip(paramInt1, paramInt2 + j * paramInt3, 11, k);
    paramGraphics.drawImage(c.p, paramInt1 + 5 - i / 2, j * paramInt3 + paramInt2, 0);
    paramGraphics.setClip(m, i1, i2, i3);
    paramGraphics.setColor(3215616);
    paramGraphics.fillRect(paramInt1 + 2, paramInt2 + 2, 7, 7);
    paramGraphics.fillRect(paramInt1 + 2, paramInt2 + paramInt4 + 2 - 11, 7, 7);
    paramGraphics.setColor(6037505);
    a(paramGraphics, paramInt1 + 1, paramInt2 + 5 - 2, 0);
    a(paramGraphics, paramInt1 + 1, paramInt2 + paramInt4 - 5 - 1, 1);
    paramInt3 = paramInt4 - 22;
    if (paramInt7 <= paramInt5) {
      paramInt4 = paramInt3;
      i = 0;
    } else {
      i = paramInt3 / paramInt7;
      paramInt4 = paramInt5 * paramInt3 / paramInt7;
      paramInt3 = paramInt3 - paramInt4 - (paramInt7 - paramInt5) * i;
      paramInt4 += paramInt3;
    } 
    paramGraphics.setColor(3671296);
    paramGraphics.fillRect(paramInt1, paramInt2 + 11 + paramInt6 * i, 10, paramInt4);
    paramInt3 = c.o.getHeight();
    c.o.getWidth();
    j = paramInt4 / paramInt3;
    for (paramInt5 = 0; paramInt5 < j; paramInt5++)
      paramGraphics.drawImage(c.o, paramInt1 + 1, paramInt5 * paramInt3 + paramInt2 + 11 + paramInt6 * i, 0); 
    k = paramInt4 % paramInt3;
    paramGraphics.setClip(paramInt1 + 1, paramInt2 + 11 + paramInt6 * i + j * paramInt3, 11, k);
    paramGraphics.drawImage(c.o, paramGraphics.getClipX(), paramGraphics.getClipY(), 0);
    paramGraphics.setClip(m, i1, i2, i3);
  }
  
  public static void a(Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    paramGraphics.setColor(8406570);
    paramGraphics.fillRect(paramInt1 + 1, paramInt2 + 1, paramInt3 - 2, paramInt4 - 2);
  }
}


/* Location:              C:\Users\sora\Desktop\Third_World_War_of_Kings_2D.jar!\o.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */