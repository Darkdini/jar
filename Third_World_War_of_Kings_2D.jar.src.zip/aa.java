import com.fenix.main.h;
import javax.microedition.lcdui.Graphics;

public final class aa extends n {
  private String[] b = null;
  
  private int c = -1;
  
  private int[] d = null;
  
  public int a = 0;
  
  private int e = 57;
  
  private boolean f = false;
  
  public final void a(String[] paramArrayOfString) {
    if (this.b != null)
      this.b = null; 
    this.b = paramArrayOfString;
    this.c = 0;
  }
  
  public final void a(int[] paramArrayOfint) {
    this.d = paramArrayOfint;
  }
  
  public final int a() {
    if (this.d != null) {
      System.out.println("uniqueItemsID getItemID() -> " + c());
      return c();
    } 
    System.out.println("simple getItemID() -> " + this.c);
    return this.c;
  }
  
  private int c() {
    return (this.d == null || this.c < 0 || this.c > this.d.length - 1) ? -1 : this.d[this.c];
  }
  
  public final int b() {
    int i = 0;
    for (byte b = 0; b < this.b.length; b++) {
      int j = h.d.stringWidth(this.b[b]);
      if (i < j)
        i = j; 
    } 
    return i + 20;
  }
  
  public final void a(Graphics paramGraphics) {
    if (!g())
      return; 
    int i = k();
    int j = l();
    int k = m();
    int m = n();
    if (i()) {
      paramGraphics.setColor(8986913);
    } else {
      paramGraphics.setColor(6684672);
    } 
    paramGraphics.fillRect(i, j, k, m);
    if (i()) {
      paramGraphics.setColor(16777164);
      paramGraphics.drawRect(i, j, k, m);
    } else {
      paramGraphics.setColor(9735534);
      paramGraphics.drawRect(i, j, k, m);
    } 
    paramGraphics.setColor(0);
    paramGraphics.drawRect(i - 1, j - 1, k + 2, m + 2);
    paramGraphics.setColor(3215616);
    paramGraphics.fillRect(i + k - m + 2, j + 2, m - 3, m - 3);
    paramGraphics.setColor(1114112);
    paramGraphics.drawLine(i + k - m + 1, j + m - 1, i + k - 1, j + m - 1);
    paramGraphics.drawLine(i + k - 1, j + m - 1, i + k - 1, j + 1);
    paramGraphics.setColor(6706500);
    paramGraphics.drawLine(i + k - m + 1, j + 1, i + k - 1, j + 1);
    paramGraphics.drawLine(i + k - m + 1, j + 1, i + k - m + 1, j + m - 1);
    paramGraphics.setColor(6037505);
    o.a(paramGraphics, i + k - m - 1 + (m - 4) / 2, j + 1 + (m - 2) / 2, 1);
    if (this.a == 0) {
      paramGraphics.setFont(h.d);
      paramGraphics.setColor(16777215);
      aa aa2;
      paramGraphics.drawString(((aa2 = this).b != null && aa2.c != -1 && aa2.c < aa2.b.length) ? aa2.b[aa2.c] : "", i + 5, j + m / 2 - paramGraphics.getFont().getHeight() / 2, 0);
    } 
    Graphics graphics = paramGraphics;
    aa aa1;
    if (this.a == 1 && (aa1 = this).g()) {
      int i1 = aa1.k();
      i = aa1.l();
      j = aa1.m();
      m = aa1.n();
      if (aa1.f) {
        i = i + m + 1;
      } else {
        i = i - m - 1;
      } 
      m = h.d.getHeight() + 2;
      int i2 = aa1.e / m;
      if (aa1.f) {
        setColor(6684672);
        fillRect(i1, i, j, aa1.e);
        setColor(16777164);
        drawRect(i1, i, j, aa1.e);
      } else {
        setColor(6684672);
        fillRect(i1, i - aa1.e + m + 1, j, aa1.e);
        setColor(16777164);
        drawRect(i1, i - aa1.e + m + 1, j, aa1.e);
      } 
      setFont(h.d);
      setColor(16777215);
      if (aa1.b != null) {
        for (byte b = 0; b < aa1.b.length; b++) {
          int i3;
          if (aa1.c < i2 / 2 || aa1.b.length <= i2) {
            i3 = b;
          } else if (aa1.c >= aa1.b.length - i2 / 2) {
            i3 = b - aa1.c + i2 / 2 + i2 / 2 - aa1.b.length - aa1.c + 1;
            if (i2 % 2 == 0)
              i3--; 
          } else {
            i3 = b - aa1.c + i2 / 2;
            if (i2 % 2 == 0)
              i3--; 
          } 
          if (i3 >= 0 && i3 <= i2 - 1) {
            if (b == aa1.c) {
              setColor(8986913);
              if (aa1.f) {
                fillRect(i1 + 1, i + m * i3 + 1, j - 1, m);
              } else {
                fillRect(i1 + 1, i - m * i3 + 1, j - 1, m);
              } 
              setColor(16777215);
            } 
            if (aa1.f) {
              drawString(aa1.b[b], i1 + 2, i + m / 2 - h.d.getHeight() / 2 + m * i3 + 1, 0);
            } else {
              drawString(aa1.b[b], i1 + 2, i - m / 2 + h.d.getHeight() / 2 - m * i3 + 1, 0);
            } 
          } 
        } 
        if (aa1.f) {
          o.a(this, i1 + j - 10, i, 10, aa1.e, i2, aa1.c, aa1.b.length + i2 - 1);
          return;
        } 
        o.a(this, i1 + j - 10, i - aa1.e + m + 1, 10, aa1.e, i2, aa1.b.length - 1 - aa1.c, aa1.b.length + i2 - 1);
      } 
    } 
  }
  
  public final void a(int paramInt1, int paramInt2) {
    this.f = true;
    if (l() + n() + this.e > paramInt1 + paramInt2)
      this.f = false; 
  }
  
  public final void e(int paramInt) {
    if (this.b == null) {
      if (this.a == 1)
        this.a = 0; 
      return;
    } 
    switch (paramInt) {
      case 8:
      case 65536:
        if (this.f) {
          this.c--;
          if (this.c < 0) {
            this.c = 0;
            return;
          } 
          break;
        } 
        this.c++;
        if (this.c >= this.b.length - 1) {
          this.c = this.b.length - 1;
          return;
        } 
        break;
      case 16:
      case 131072:
        if (!this.f) {
          this.c--;
          if (this.c < 0) {
            this.c = 0;
            return;
          } 
          break;
        } 
        this.c++;
        if (this.c >= this.b.length - 1) {
          this.c = this.b.length - 1;
          return;
        } 
        break;
      case 32:
      case 4096:
      case 524288:
        this.a = 0;
        break;
    } 
  }
}


/* Location:              C:\Users\sora\Desktop\Third_World_War_of_Kings_2D.jar!\aa.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */