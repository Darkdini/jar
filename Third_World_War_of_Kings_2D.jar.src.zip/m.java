import com.fenix.main.c;
import com.fenix.main.h;
import javax.microedition.lcdui.Font;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;

public final class m extends n {
  private String[] a;
  
  private StringBuffer b = null;
  
  private boolean c = false;
  
  private boolean d = false;
  
  private int[] e;
  
  private t[] f;
  
  private int[] g = null;
  
  private boolean h = false;
  
  private int i = 0;
  
  public m() {
    c(false);
    this.b = new StringBuffer("");
  }
  
  public final void a(String paramString) {
    if (this.b != null)
      this.b = null; 
    if (paramString == null || paramString.length() <= 0) {
      this.b = new StringBuffer();
      this.b.setLength(0);
      return;
    } 
    this.b = new StringBuffer(paramString);
  }
  
  public final void b(boolean paramBoolean) {
    this.d = true;
  }
  
  public final boolean a(int paramInt1, int paramInt2) {
    boolean bool = false;
    int i = l();
    if (this.a != null)
      for (byte b = 0; b < this.a.length; b++) {
        if (this.a[b].indexOf("{") >= 0 && i > paramInt1 && i + this.e[b] < paramInt1 + paramInt2) {
          bool = true;
          break;
        } 
        i += this.e[b];
      }  
    return bool;
  }
  
  public final void a() {
    try {
      if (this.b != null) {
        System.currentTimeMillis();
        this.a = l.a().a(this.b.toString(), h.d, m() - 5, true);
        this.g = new int[this.a.length];
        for (byte b1 = 0; b1 < this.g.length; b1++)
          this.g[b1] = l.a().a(this.a[b1], h.d); 
        Font font = h.d;
        String[] arrayOfString = this.a;
        l l = l.a();
        int[] arrayOfInt = new int[arrayOfString.length];
        byte b3;
        for (b3 = 0; b3 < arrayOfString.length; b3++)
          arrayOfInt[b3] = l.b(arrayOfString[b3], font); 
        this.e = arrayOfInt;
        System.currentTimeMillis();
        String str = this.b.toString();
        m m1 = this;
        try {
          int j = 0;
          b3 = 0;
          int k;
          while ((k = str.indexOf("{u", j)) > -1) {
            b3++;
            j = k + 2;
          } 
          if (b3 == 0) {
            m1.c(false);
          } else {
            m1.c(true);
            m1.f = new t[b3];
            byte b4 = 0;
            for (byte b5 = 0; b5 < m1.a.length; b5++) {
              j = 0;
              String str1 = "";
              while ((k = m1.a[b5].indexOf("{u", j)) > -1) {
                str = m1.a[b5].substring(k + 2, m1.a[b5].indexOf("}", k));
                int i1 = 0;
                byte b = 0;
                while ((i1 = str.indexOf("|", i1)) != -1) {
                  b++;
                  i1++;
                } 
                i1 = Integer.parseInt(str.substring(0, str.indexOf("|")));
                int i2 = Integer.parseInt((str = str.substring(str.indexOf("|") + 1)).substring(0, str.indexOf("|")));
                int i3 = Integer.parseInt((str = str.substring(str.indexOf("|") + 1)).substring(0, str.indexOf("|")));
                str = str.substring(str.indexOf("|") + 1);
                int i4 = -1;
                if (b == 4) {
                  i4 = Integer.parseInt(str.substring(0, str.indexOf("|")));
                  str = str.substring(str.indexOf("|") + 1);
                } 
                str = str.substring(str.indexOf("|") + 1);
                m1.f[b4] = new t(str, i1, i2, i3);
                m1.f[b4].c(h.d.stringWidth(str));
                m1.f[b4].d(h.d.getHeight());
                m1.f[b4].a(false);
                if (b == 4)
                  m1.f[b4].i(i4); 
                str1 = str1 + m1.a[b5].substring(j, k) + "{u" + b4 + "}";
                b4++;
                j = m1.a[b5].indexOf("}", k) + 1;
              } 
              str1 = str1 + m1.a[b5].substring(j);
              m1.a[b5] = str1;
            } 
            m1.i = 0;
          } 
        } catch (Exception exception) {
          System.err.println("Error in  TextElement.getLinkLables " + exception);
        } 
        int i = 0;
        for (byte b2 = 0; b2 < this.e.length; b2++)
          i += this.e[b2]; 
        d(i);
      } else {
        d(0);
        return;
      } 
    } catch (Exception exception) {
      System.err.println("Error in  TextElement.getLinkLables " + this);
    } 
  }
  
  public final void a(int paramInt1, int paramInt2, int paramInt3) {
    byte b;
    switch (paramInt1) {
      case 4:
      case 16:
      case 32768:
      case 131072:
        paramInt2 = paramInt3;
        paramInt1 = paramInt2;
        paramInt3 = (this = this).i;
        for (b = 0; b < this.f.length; b++)
          this.f[b].a(false); 
        if (++paramInt3 >= this.f.length) {
          this.h = true;
          break;
        } 
        if (b(paramInt3, paramInt1, paramInt2)) {
          this.i = paramInt3;
        } else {
          this.h = true;
        } 
        this.f[this.i].a(true);
        return;
      case 2:
      case 8:
      case 65536:
      case 262144:
        paramInt2 = paramInt3;
        paramInt1 = paramInt2;
        paramInt3 = (this = this).i;
        for (b = 0; b < this.f.length; b++)
          this.f[b].a(false); 
        if (--paramInt3 < 0) {
          this.h = true;
          break;
        } 
        if (b(paramInt3, paramInt1, paramInt2)) {
          this.i = paramInt3;
        } else {
          this.h = true;
        } 
        this.f[this.i].a(true);
        return;
      case 32:
      case 524288:
        if (this.f != null && this.f[this.i].i())
          this.f[this.i].e(paramInt1); 
        break;
    } 
  }
  
  public final void a(Graphics paramGraphics) {
    try {
      if (!g())
        return; 
      int i = l();
      if (this.a != null) {
        paramGraphics.setFont(h.d);
        paramGraphics.setColor(16777215);
        for (byte b = 0; b < this.a.length; b++) {
          int j = 0;
          if (o() == 0 || o() == 2) {
            j = 0;
          } else if (o() == 1) {
            j = m() / 2 - this.g[b] / 2;
          } 
          if (this.a[b].indexOf("{") < 0) {
            if (this.d)
              paramGraphics.setFont(h.g); 
            paramGraphics.drawString(this.a[b], j + k(), i, 0);
          } else {
            int i1 = 0;
            int k;
            String str;
            for (str = this.a[b]; (k = str.indexOf("{")) >= 0; str = str.substring(str.indexOf("}") + 1)) {
              Image image2;
              int i3;
              Image image1;
              String str2;
              int i2;
              String str1;
              String str3 = str.substring(0, k);
              paramGraphics.drawString(str3, j + k() + i1, i + this.e[b] / 2 - paramGraphics.getFont().getHeight() / 2, 0);
              i1 += h.d.stringWidth(str3);
              switch (str.charAt(k + 1)) {
                case 'i':
                  image2 = c.a(Integer.parseInt(str.substring(k + 2, str.indexOf("}"))));
                  paramGraphics.drawImage(image2, j + k() + i1, i + this.e[b] / 2 - image2.getHeight() / 2, 0);
                  i1 += image2.getWidth();
                  break;
                case 'u':
                  i3 = Integer.parseInt(str.substring(image2 + 2, str.indexOf("}")));
                  this.f[i3].a(paramGraphics, j + k() + i1, i + this.e[b] / 2 - this.f[i3].n() / 2);
                  i1 += this.f[i3].m();
                  paramGraphics.setFont(h.d);
                  break;
                case 's':
                  image1 = c.a(1000 + Integer.parseInt(str.substring(i3 + 2, str.indexOf("}"))));
                  paramGraphics.drawImage(image1, j + k() + i1, i + this.e[b] / 2 - image1.getHeight() / 2, 0);
                  i1 += image1.getWidth();
                  break;
                case 'b':
                  paramGraphics.setFont(h.g);
                  str2 = str.substring(image1 + 2, str.indexOf("}"));
                  paramGraphics.drawString(str2, j + k() + i1, i, 0);
                  i1 += paramGraphics.getFont().stringWidth(str2);
                  paramGraphics.setFont(h.d);
                  break;
                case 'k':
                  paramGraphics.setFont(h.f);
                  paramGraphics.setColor(13421772);
                  str2 = str.substring(str2 + 2, str.indexOf("}"));
                  paramGraphics.drawString(str2, j + k() + i1, i, 0);
                  i1 += paramGraphics.getFont().stringWidth(str2);
                  paramGraphics.setFont(h.d);
                  paramGraphics.setColor(16777215);
                  break;
                case 'c':
                  i2 = Integer.parseInt(str.substring(str2 + 2, str.indexOf("#")));
                  paramGraphics.setColor(i2);
                  str1 = str.substring(str.indexOf("#") + 1, str.indexOf("}"));
                  paramGraphics.drawString(str1, j + k() + i1, i, 0);
                  i1 += paramGraphics.getFont().stringWidth(str1);
                  paramGraphics.setFont(h.d);
                  paramGraphics.setColor(16777215);
                  break;
              } 
            } 
            paramGraphics.drawString(str, j + k() + i1, i + this.e[b] / 2 - paramGraphics.getFont().getHeight() / 2, 0);
          } 
          i += this.e[b];
        } 
      } 
      return;
    } catch (Exception exception) {
      System.err.println("Error in  TextElement.paint " + exception);
      exception.printStackTrace();
      return;
    } 
  }
  
  public final void a(boolean paramBoolean) {
    super.a(paramBoolean);
    if (paramBoolean) {
      this.f[this.i].a(true);
      this.h = false;
    } 
  }
  
  private boolean b(int paramInt1, int paramInt2, int paramInt3) {
    boolean bool = false;
    int i = l();
    for (byte b = 0; b < this.a.length; b++) {
      int j;
      if ((j = this.a[b].indexOf("{u" + Integer.toString(paramInt1) + "}")) >= 0) {
        if (i > paramInt2 && i + this.e[b] < paramInt2 + paramInt3)
          bool = true; 
        break;
      } 
      i += this.e[b];
    } 
    return bool;
  }
  
  public final boolean b() {
    return this.h;
  }
}


/* Location:              C:\Users\sora\Desktop\Third_World_War_of_Kings_2D.jar!\m.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */