import java.io.ByteArrayOutputStream;

public final class ab {
  public static int a = 4;
  
  public static int a(byte[] paramArrayOfbyte, int paramInt) {
    return g.b(paramArrayOfbyte, paramInt);
  }
  
  public static byte[] b(byte[] paramArrayOfbyte, int paramInt) {
    if (paramInt + 4 > paramArrayOfbyte.length)
      return null; 
    int i = g.b(paramArrayOfbyte, paramInt + 2);
    if (paramInt + 4 + i > paramArrayOfbyte.length)
      return null; 
    byte[] arrayOfByte = new byte[i];
    System.arraycopy(paramArrayOfbyte, paramInt + 4, arrayOfByte, 0, i);
    return arrayOfByte;
  }
  
  public static void a(int paramInt, ByteArrayOutputStream paramByteArrayOutputStream, byte[] paramArrayOfbyte) {
    g.a(paramByteArrayOutputStream, paramInt, true);
    g.a(paramByteArrayOutputStream, paramArrayOfbyte.length, true);
    paramByteArrayOutputStream.write(paramArrayOfbyte, 0, paramArrayOfbyte.length);
  }
  
  public static void a(int paramInt, byte[] paramArrayOfbyte) {
    g.a(paramArrayOfbyte, 0, paramInt, true);
    g.a(paramArrayOfbyte, 2, 0, true);
  }
}


/* Location:              C:\Users\sora\Desktop\Third_World_War_of_Kings_2D.jar!\ab.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */